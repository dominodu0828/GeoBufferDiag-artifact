Source for GeoBufferDiag PVLDB 2027 manuscript. Compile main.tex using Tectonic or a compatible LaTeX toolchain.
