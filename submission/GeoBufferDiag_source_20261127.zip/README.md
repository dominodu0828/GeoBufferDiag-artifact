# GeoBufferDiag manuscript source

This archive contains the LaTeX source and figures for the manuscript PDF in the parent directory. The data-provenance paragraph reflects the authors' confirmation of public-release permissions for the evaluated Baidu Maps-derived and So2Sat-derived records. The availability URL is intentionally left empty until a public artifact URL exists.

Compile `main.tex` with Tectonic 0.17.0 or XeLaTeX from this directory. Bibliography database: `references.bib`.
