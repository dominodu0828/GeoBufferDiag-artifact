# -*- coding: utf-8 -*-
"""E2: fixed-sample, single-factor radius response (plan 09 sec. 3, E2).

Design (frozen into ``design.json`` BEFORE any engine is timed):

  * data blocks = 5 seeds x 2 geometries; each block generates coordinates,
    labels, sampling keys and folds ONCE and reuses them for every radius and
    every method, so the manipulated factor is radius only;
  * frozen constants inside a block: n = 10,000, pos_ratio = 0.5,
    k_blocks = 5, n_repeats = 5 (same values as the historical D3 design, so
    the mechanism numbers are comparable);
  * three radius levels per block, taken as the p10 / p50 / p90 quantiles of
    the baseline nearest-test-distance distribution of one designated fold
    (repeat 0, first scattered fold).  Quantiles are computed and written to
    ``design.json`` before any method runs, so the levels cannot be chosen
    after seeing method times.  The realised radius in metres therefore
    differs across blocks; the frozen quantity is the quantile level;
  * methods B1 (``kd``) and Full (``c``); cold state, ``matched`` output,
    production streaming writer (``splitbench.writers.write_outputs``);
  * one discarded warm-up per (block, radius, method), then 7 recorded
    repetitions -> 5 x 2 x 3 x 2 x 7 = 420 formal rows.

Timing boundary is the same as E1: engine, payload write and status write are
timed separately and total spans engine start to status completion.  City
generation, quantile computation and correctness checks are outside the timer.

Correctness (outside the timer, registered as separate oracles):
  A. brute force: ``B0Engine`` on a small independent city (n = 800, same two
     geometries) at the same three quantile levels -> full comparison of
     matched arms, audit pools, quotas and status against B1 and Full;
  B. cross-engine agreement on the timed cities: B1 and Full must emit
     identical selected identities, quotas and feasibility for every
     (radius, repeat, fold);
  C. internal invariants per row: selected ids disjoint from the test fold, no
     duplicate ids, label-consistent class membership, length equal to the
     common quota.

Usage:
    python -B work/final_20261123/e2_radius_controlled.py \
        --run runs/e2-radius-20261123-a
"""
from __future__ import annotations

import argparse
import csv
import ctypes
import hashlib
import json
import os
import platform
import shutil
import statistics
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np                                   # noqa: E402
from threadpoolctl import threadpool_limits           # noqa: E402

from splitbench.baseline_b1 import B1Engine           # noqa: E402
from splitbench.candidate import CandidateEngine      # noqa: E402
from splitbench.gate_d import make_city               # noqa: E402
from splitbench.ref_b0 import B0Engine                # noqa: E402
from splitbench.settings import load_config           # noqa: E402
from splitbench.writers import fmt_radius, write_outputs, write_status  # noqa: E402

SEEDS = (20261121, 20261122, 20261123, 20261124, 20261125)
GEOMETRIES = ("uniform", "cluster")
N_ROWS = 10000
POS_RATIO = 0.5
K_BLOCKS = 5
N_REPEATS = 5
LEVELS = ("p10", "p50", "p90")
METHODS = (("kd", "B1"), ("c", "Full"))
FORMAL_REPS = 7
WARMUP_ROUNDS = 1
ORACLE_N = 800
OUTPUT = "matched"
VARIANT = "cold"
MAX_SECONDS = 7200.0

COLS = [
    "seq", "block_id", "seed", "geometry", "n_rows", "radius_level",
    "radius_m", "method", "engine", "rep", "round", "formal", "order_pos",
    "utc_start", "utc_end", "feasible", "note",
    "ms_engine", "ms_index", "ms_exact", "ms_quota", "ms_select",
    "ms_payload", "ms_status", "ms_total",
    "rows_out", "gz_bytes", "dec_bytes", "dec_sha256",
    "quota_pos", "quota_neg", "quota_json",
    "n_rows_queried", "n_rows_exact", "n_query_batches",
    "n_block_center_queries", "n_blocks_uncertain",
    "n_scan_rows_examined", "n_scan_batches", "n_fallbacks",
    "n_masks", "n_masks_reused",
    "deletion_rate", "deletion_rate_min", "deletion_rate_max",
    "pool_pos", "pool_neg",
    "sig_sha256", "inv_ok", "inv_detail", "counters_json",
    "cpu_busy_pct", "proc_cpu_s", "ts",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def rel(p: Path) -> str:
    try:
        return str(p.resolve().relative_to(ROOT)).replace("\\", "/")
    except ValueError:
        return str(p).replace("\\", "/")


class SysCpu:
    """Machine-wide busy fraction from GetSystemTimes (win32); None elsewhere."""

    def __init__(self):
        self.ok = sys.platform == "win32"
        self.kt = ctypes.windll.kernel32 if self.ok else None
        if self.ok:
            class FT(ctypes.Structure):
                _fields_ = [("lo", ctypes.c_ulong), ("hi", ctypes.c_ulong)]

            self.FT = FT

    def _ft(self, kind):
        a, b, c = self.FT(), self.FT(), self.FT()
        self.kt.GetSystemTimes(ctypes.byref(a), ctypes.byref(b), ctypes.byref(c))
        return tuple((x.hi << 32) | x.lo for x in (a, b, c))

    def sample(self):
        if not self.ok:
            return None
        idle, kern, user = self._ft(0)
        return (idle, kern + user)

    def busy_pct(self, s0, s1):
        if not s0 or not s1:
            return ""
        di = s1[0] - s0[0]
        dt = s1[1] - s0[1]
        if dt <= 0:
            return ""
        return round(max(0.0, min(100.0, 100.0 * (1.0 - di / dt))), 2)


def build_city(seed: int, geometry: str, n: int = N_ROWS):
    rng = np.random.default_rng(seed)
    return make_city(n, geometry, rng, k_blocks=K_BLOCKS,
                     n_repeats=N_REPEATS, pos_ratio=POS_RATIO)


def designated_fold(folds):
    """The frozen reference fold: repeat 0, scattered fold k=0.

    A contiguous (x-band) fold is deliberately not used: its candidates are
    spatially disjoint from the test band, so the nearest-test distances are
    kilometres rather than buffer radii.
    """
    for geom, k, te in folds.repeat_folds(0):
        if int(geom) == 1 and int(k) == 0:
            return (geom, k, te)
    raise RuntimeError("no scattered fold in repeat 0")


def baseline_distances(ct, folds):
    """Nearest-test distances of the designated fold."""
    from scipy.spatial import cKDTree
    geom, k, te = designated_fold(folds)
    cand = np.flatnonzero(~te)
    d = cKDTree(ct.xy[te]).query(ct.xy[cand], k=1)[0]
    return d, cand, (geom, k, te)


def level_radii(ct, folds) -> dict:
    d, _cand, _key = baseline_distances(ct, folds)
    return {lvl: float(np.quantile(d, q)) for lvl, q in
            zip(LEVELS, (0.10, 0.50, 0.90))}


def fold_counts(ct, folds, radius: float) -> dict:
    """Deletion rate and class pools at a radius, over an independent fold set.

    Measured on all five scattered folds of repeat 0, NOT on the designated
    fold used to define the quantile: on that fold the deletion rate would be
    the quantile level by construction and would carry no information.
    """
    from scipy.spatial import cKDTree
    y = ct.label
    rates, pool_pos, pool_neg = [], 0, 0
    n_folds = 0
    for geom, k, te in folds.repeat_folds(0):
        if int(geom) != 1:
            continue
        cand = np.flatnonzero(~te)
        d = cKDTree(ct.xy[te]).query(ct.xy[cand], k=1)[0]
        kept = cand[d > radius] if radius > 0 else cand
        rates.append(1.0 - len(kept) / len(cand))
        pool_pos += int(np.count_nonzero(y[kept] == 1))
        pool_neg += int(np.count_nonzero(y[kept] == 0))
        n_folds += 1
    return {"deletion_rate": round(float(np.mean(rates)), 6),
            "deletion_rate_min": round(float(np.min(rates)), 6),
            "deletion_rate_max": round(float(np.max(rates)), 6),
            "pool_pos": pool_pos, "pool_neg": pool_neg,
            "fold_set": "rep0/scatter 0-4 (n=%d)" % n_folds}


def test_folds_in_order(folds):
    """Test masks in the canonical comparison order used by the engines."""
    return [te for rep in range(folds.n_repeats)
            for _g, _k, te in folds.repeat_folds(rep)]


def invariants(ct, folds, res, radii) -> tuple[bool, str, str]:
    """Per-row internal invariants plus an order-insensitive identity digest."""
    detail = []
    ok = True
    h = hashlib.sha256()
    y = ct.label
    te_list = test_folds_in_order(folds)
    for r in radii:
        comps = res.matched.get(r) or []
        if len(comps) != len(te_list):
            ok = False
            detail.append("r=%s: %d comparisons != %d"
                          % (r, len(comps), len(te_list)))
        for idx, comp in enumerate(comps):
            te = te_list[idx] if idx < len(te_list) else None
            te_idx = np.flatnonzero(te) if te is not None else None
            if te_idx is not None:
                h.update(np.ascontiguousarray(np.sort(te_idx)).tobytes())
            for key in ("unbuf_pos", "unbuf_neg", "buf_pos", "buf_neg"):
                ids = np.asarray(comp.get(key))
                h.update(key.encode())
                h.update(np.ascontiguousarray(np.sort(ids), dtype=np.int64)
                         .tobytes())
                if ids.size == 0:
                    continue
                if te_idx is not None and np.intersect1d(ids, te_idx).size:
                    ok = False
                    detail.append("r=%s %s contains test ids" % (r, key))
                if np.unique(ids).size != ids.size:
                    ok = False
                    detail.append("r=%s %s has duplicates" % (r, key))
                cls = 1 if key.endswith("pos") else 0
                if np.any(y[ids] != cls):
                    ok = False
                    detail.append("r=%s %s label mismatch" % (r, key))
            q = comp.get("quota")
            if q and q[0] is not None:
                for key, qq in (("buf_pos", q[0]), ("buf_neg", q[1])):
                    if int(qq) >= 0 and len(comp.get(key, [])) != int(qq):
                        ok = False
                        detail.append("r=%s %s len != quota %s"
                                      % (r, key, qq))
    return ok, "; ".join(detail[:6]), h.hexdigest()


def run_oracle(cfg, ec, side, margin, batch_rows, floor) -> dict:
    """Oracle A: brute force vs B1 vs Full on a small independent city."""
    out = {"cases": [], "all_pass": True}
    for geometry in GEOMETRIES:
        seed = SEEDS[0] + 90000
        ct, folds = build_city(seed, geometry, ORACLE_N)
        radii = level_radii(ct, folds)
        rlist = [radii[l] for l in LEVELS]
        res_by = {}
        for mkey, _label in (("b0", "B0"), ("kd", "B1"), ("c", "Full")):
            if mkey == "b0":
                eng = B0Engine()
            elif mkey == "kd":
                eng = B1Engine()
            else:
                eng = CandidateEngine(arm="c", side=side, margin=margin,
                                      batch_rows=batch_rows, policy="priority")
            res, _st = eng.run_city(ct, folds, rlist, OUTPUT, state=None,
                                    floor=floor)
            res_by[mkey] = res
        for lvl, r in zip(LEVELS, rlist):
            ref = res_by["b0"]
            for mkey in ("kd", "c"):
                got = res_by[mkey]
                cmp_ok = True
                notes = []
                q_ref = ref.quota.get(r)
                q_got = got.quota.get(r)
                if (q_ref is None) != (q_got is None):
                    cmp_ok = False
                    notes.append("quota presence")
                elif q_ref is not None and [tuple(map(int, x)) for x in q_ref] \
                        != [tuple(map(int, x)) for x in q_got]:
                    cmp_ok = False
                    notes.append("quota values")
                c_ref = ref.matched.get(r) or []
                c_got = got.matched.get(r) or []
                if len(c_ref) != len(c_got):
                    cmp_ok = False
                    notes.append("comparison count %d != %d"
                                 % (len(c_ref), len(c_got)))
                else:
                    for a, b in zip(c_ref, c_got):
                        for key in ("unbuf_pos", "unbuf_neg", "buf_pos",
                                    "buf_neg"):
                            if not np.array_equal(np.asarray(a.get(key)),
                                                 np.asarray(b.get(key))):
                                cmp_ok = False
                                notes.append("%s differs" % key)
                                break
                for rr in rlist:
                    s_a = ref.status.get(rr) or {}
                    s_b = got.status.get(rr) or {}
                    if bool(s_a.get("feasible")) != bool(s_b.get("feasible")):
                        cmp_ok = False
                        notes.append("feasibility r=%s" % rr)
                out["cases"].append({
                    "geometry": geometry, "radius_level": lvl,
                    "radius_m": round(r, 4), "n": ORACLE_N,
                    "method": mkey, "match_against_b0": bool(cmp_ok),
                    "detail": "; ".join(notes[:4])})
                out["all_pass"] = out["all_pass"] and cmp_ok
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="runs/e2-radius-20261123-a")
    ap.add_argument("--reps", type=int, default=FORMAL_REPS)
    ap.add_argument("--warmup", type=int, default=WARMUP_ROUNDS)
    ap.add_argument("--max-seconds", type=float, default=MAX_SECONDS)
    ap.add_argument("--only", default=None,
                    help="substring filter on block_id (smoke tests only)")
    ap.add_argument("--skip-oracle", action="store_true")
    args = ap.parse_args()

    run_dir = Path(args.run)
    if not run_dir.is_absolute():
        run_dir = ROOT / run_dir
    if run_dir.exists() and any(run_dir.iterdir()):
        sys.exit("refusing to write into non-empty %s" % run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    tmp_root = run_dir / "tmp"
    tmp_root.mkdir(exist_ok=True)

    cfg = load_config(ROOT / "configs" / "paper_primary.yaml")
    ec = dict(cfg["engine"])
    side = float(ec["block_grid_side_m"])
    margin = float(ec["block_float_margin_m"])
    batch_rows = int(ec["scan_batch_rows"])
    floor = int(cfg["run"]["quota_floor"])
    threads = int(cfg["run"]["threads"])

    started_utc = utc_now()
    t_start = time.perf_counter()

    # ---- stage 1: data blocks, radius levels, design freeze (no engine yet)
    blocks = {}
    design_blocks = []
    for seed in SEEDS:
        for geometry in GEOMETRIES:
            bid = "%d/%s" % (seed, geometry)
            if args.only and args.only not in bid:
                continue
            t0 = time.perf_counter()
            ct, folds = build_city(seed, geometry)
            gen_s = time.perf_counter() - t0
            radii = level_radii(ct, folds)
            props = {lvl: fold_counts(ct, folds, radii[lvl]) for lvl in LEVELS}
            blocks[bid] = {"ct": ct, "folds": folds, "radii": radii,
                           "props": props}
            design_blocks.append({
                "block_id": bid, "seed": seed, "geometry": geometry,
                "n_rows": N_ROWS, "generation_seconds": round(gen_s, 3),
                "radius_m": {k: round(v, 6) for k, v in radii.items()},
                "radius_rule": ("p10/p50/p90 of the nearest-test-distance "
                                "distribution of rep0/scatter-fold-0 "
                                "candidates; quantile level is the frozen "
                                "factor, metres are realised per block"),
                "data_properties_at_level": props,
                "frozen_constants": {"pos_ratio": POS_RATIO,
                                     "k_blocks": K_BLOCKS,
                                     "n_repeats": N_REPEATS},
            })
            print("block %-22s radii p10/p50/p90 = %s"
                  % (bid, ["%.1f" % radii[l] for l in LEVELS]), flush=True)

    code_paths = sorted((ROOT / "splitbench").glob("*.py")) + [
        Path(__file__).resolve(), ROOT / "configs" / "paper_primary.yaml"]
    design = {
        "run_id": run_dir.name,
        "created_utc": started_utc,
        "plan": "09_修订后收尾方案_20261123.md E2",
        "stage": "D3 fixed-sample controlled single-factor (radius)",
        "seeds": list(SEEDS), "geometries": list(GEOMETRIES),
        "blocks": design_blocks,
        "methods": [{"method": m, "label": l} for m, l in METHODS],
        "radius_levels": list(LEVELS),
        "repetitions_formal": args.reps,
        "warmup_rounds_discarded": args.warmup,
        "expected_formal_rows": (len(SEEDS) * len(GEOMETRIES) * len(LEVELS)
                                 * len(METHODS) * args.reps),
        "output": OUTPUT, "variant": VARIANT,
        "writer": ("splitbench.writers.write_outputs (production streaming "
                   "gzip); the buffered profile writer is not used"),
        "timing_boundaries": [
            "engine: engine.run_city() timed alone (cold state, state=None)",
            "payload: write_outputs() streaming gzip, timed alone",
            "status: write_status() timed alone",
            "total: engine start -> status complete",
            "city generation, quantile computation, invariant checks and the "
            "B0 oracle are outside the timer"],
        "arm_order_rule": ("within a block and radius the two methods run "
                           "back-to-back; order flips with "
                           "(radius_index + rep) % 2 so no method runs as a "
                           "block"),
        "threads": threads, "quota_floor": floor,
        "engine_params": {"block_grid_side_m": side,
                          "block_float_margin_m": margin,
                          "scan_batch_rows": batch_rows},
        "not_claimable": [
            "the 7 repetitions of one block are repeated timings of one fixed "
            "city, not independent data samples; seed variation is summarised "
            "separately from timing variation",
            "no crossover claim is made unless the per-block ratios support "
            "one; a null result is reported as such"],
        "budget": {"max_seconds_timed_part": args.max_seconds},
        "code_sha256": {rel(p): sha256_file_now(p) for p in code_paths},
    }
    (run_dir / "design.json").write_text(
        json.dumps(design, indent=1, ensure_ascii=False), encoding="utf-8")
    design_sha = hashlib.sha256((run_dir / "design.json").read_bytes()).hexdigest()

    # ---- stage 2: oracle (outside the timer, before timing)
    oracle = ({"cases": [], "all_pass": True, "skipped": True}
              if args.skip_oracle else
              run_oracle(cfg, ec, side, margin, batch_rows, floor))
    (run_dir / "oracle_b0.json").write_text(
        json.dumps(oracle, indent=1, ensure_ascii=False), encoding="utf-8")
    print("oracle A (B0 brute force, n=%d): all_pass=%s"
          % (ORACLE_N, oracle["all_pass"]), flush=True)

    # ---- stage 3: timed repetitions
    rows_path = run_dir / "e2_rows.csv"
    fh = open(rows_path, "w", newline="", encoding="utf-8")
    writer = csv.DictWriter(fh, fieldnames=COLS)
    writer.writeheader()
    fh.flush()
    cpu = SysCpu()
    state = {"seq": 0, "aborted": False, "reason": ""}

    def one_row(bid, seed, geometry, lvl, idx_r, method, mlabel, rep, formal,
                pos, order):
        b = blocks[bid]
        ct, folds, radii = b["ct"], b["folds"], b["radii"]
        r = radii[lvl]
        seq = state["seq"] = state["seq"] + 1
        row_dir = tmp_root / ("seq%05d" % seq)
        cpu0 = cpu.sample()
        proc0 = time.process_time()
        utc0 = utc_now()
        eng = (B1Engine() if method == "kd" else
               CandidateEngine(arm="c", side=side, margin=margin,
                               batch_rows=batch_rows, policy="priority"))
        with threadpool_limits(limits=threads):
            t = time.perf_counter()
            res, _st = eng.run_city(ct, folds, [r], OUTPUT, state=None,
                                    floor=floor)
            ms_engine = (time.perf_counter() - t) * 1000.0
            t = time.perf_counter()
            rows_out, gz_bytes, _dt = write_outputs(row_dir, eng.name, ct,
                                                   folds, res, OUTPUT)
            ms_payload = (time.perf_counter() - t) * 1000.0
            t = time.perf_counter()
            write_status(row_dir, eng.name, ct, folds, res, [r], OUTPUT)
            ms_status = (time.perf_counter() - t) * 1000.0
        ms_total = ms_engine + ms_payload + ms_status
        proc_cpu = time.process_time() - proc0
        cpu1 = cpu.sample()

        inv_ok, inv_detail, sig = invariants(ct, folds, res, [r])
        payload_path = row_dir / "out" / eng.name / (
            "%s__%s__matched.csv.gz" % (ct.dataset, ct.city))
        dec_bytes, dec_sha = 0, ""
        if payload_path.exists():
            import gzip
            raw = gzip.decompress(payload_path.read_bytes())
            dec_bytes, dec_sha = len(raw), sha256_bytes(raw)
        shutil.rmtree(row_dir, ignore_errors=True)

        ph = res.phases
        q = (res.quota.get(r) or [(None, None)])[0]
        st = res.status.get(r) or {}
        c = res.counters
        pr = b["props"][lvl]
        row = {
            "seq": seq, "block_id": bid, "seed": seed, "geometry": geometry,
            "n_rows": N_ROWS, "radius_level": lvl, "radius_m": round(r, 6),
            "method": method, "engine": eng.name, "rep": rep,
            "round": ("warmup" if not formal else rep), "formal": int(formal),
            "order_pos": pos, "utc_start": utc0, "utc_end": utc_now(),
            "feasible": str(bool(st.get("feasible"))),
            "note": st.get("note") or "",
            "ms_engine": round(ms_engine, 3),
            "ms_index": round(ph.index * 1000.0, 3),
            "ms_exact": round(ph.exact * 1000.0, 3),
            "ms_quota": round(ph.quota * 1000.0, 3),
            "ms_select": round(ph.select * 1000.0, 3),
            "ms_payload": round(ms_payload, 3),
            "ms_status": round(ms_status, 3),
            "ms_total": round(ms_total, 3),
            "rows_out": rows_out, "gz_bytes": gz_bytes,
            "dec_bytes": dec_bytes, "dec_sha256": dec_sha,
            "quota_pos": "" if q[0] is None else int(q[0]),
            "quota_neg": "" if q[1] is None else int(q[1]),
            "quota_json": json.dumps(res.quota.get(r) or []),
            "n_rows_queried": c.get("n_rows_queried", ""),
            "n_rows_exact": c.get("n_rows_exact", ""),
            "n_query_batches": c.get("n_query_batches", ""),
            "n_blocks_uncertain": c.get("n_blocks_uncertain", ""),
            "n_block_center_queries": c.get("n_block_center_queries", ""),
            "n_scan_rows_examined": c.get("n_scan_rows_examined", ""),
            "n_scan_batches": c.get("n_scan_batches", ""),
            "n_fallbacks": c.get("n_fallbacks", ""),
            "n_masks": c.get("n_masks", ""),
            "n_masks_reused": c.get("n_masks_reused", ""),
            "deletion_rate": pr["deletion_rate"],
            "deletion_rate_min": pr["deletion_rate_min"],
            "deletion_rate_max": pr["deletion_rate_max"],
            "pool_pos": pr["pool_pos"],
            "pool_neg": pr["pool_neg"],
            "sig_sha256": sig, "inv_ok": str(inv_ok),
            "inv_detail": inv_detail,
            "counters_json": json.dumps(c, sort_keys=True),
            "cpu_busy_pct": cpu.busy_pct(cpu0, cpu1),
            "proc_cpu_s": round(proc_cpu, 3), "ts": utc_now(),
        }
        writer.writerow(row)
        fh.flush()
        print("  [%3d] %-20s %-4s %-3s %-4s rep%s total=%8.1fms payload=%7.1fms"
              % (seq, bid, lvl, mlabel, method, ("W" if not formal else rep),
                 ms_total, ms_payload), flush=True)
        return row

    total_rounds = args.warmup + args.reps
    block_items = list(blocks.items())
    for rnd in range(total_rounds):
        formal = rnd >= args.warmup
        rep = rnd - args.warmup + 1 if formal else 0
        print("== round %d/%d (%s)" % (rnd + 1, total_rounds,
                                       "rep %d" % rep if formal else "warmup"),
              flush=True)
        for bid, b in block_items:
            seed, geometry = bid.split("/")
            for idx_r, lvl in enumerate(LEVELS):
                if time.perf_counter() - t_start > args.max_seconds:
                    state["aborted"] = True
                    state["reason"] = ("time budget %.0fs exceeded before "
                                       "round %d %s %s" % (args.max_seconds,
                                                           rnd + 1, bid, lvl))
                    break
                order = METHODS if (idx_r + rep) % 2 == 0 else METHODS[::-1]
                for pos, (mkey, mlabel) in enumerate(order):
                    one_row(bid, int(seed), geometry, lvl, idx_r, mkey, mlabel,
                            rep, formal, pos + 1,
                            ">".join(l for _k, l in order))
            if state["aborted"]:
                break
        if state["aborted"]:
            break
    fh.close()

    # ---- stage 4: summary (seed variation separated from timing variation)
    rows = list(csv.DictReader(open(rows_path, encoding="utf-8")))
    formal_rows = [r for r in rows if r["formal"] == "1"]

    cells = {}
    for r in formal_rows:
        key = (r["block_id"], r["radius_level"], r["method"])
        cells.setdefault(key, []).append(float(r["ms_total"]))

    per_cell = []
    for bid in blocks:
        for lvl in LEVELS:
            u = cells.get((bid, lvl, "kd"), [])
            i = cells.get((bid, lvl, "c"), [])
            if not u or not i:
                continue
            mu, mi = statistics.median(u), statistics.median(i)
            per_cell.append({
                "block_id": bid, "radius_level": lvl,
                "radius_m": round(blocks[bid]["radii"][lvl], 6),
                "deletion_rate": blocks[bid]["props"][lvl]["deletion_rate"],
                "B1_med": round(mu, 3), "Full_med": round(mi, 3),
                "ratio": round(mi / mu, 4), "n": len(u)})

    by_level = {}
    for lvl in LEVELS:
        rs = [c["ratio"] for c in per_cell if c["radius_level"] == lvl]
        if rs:
            by_level[lvl] = {"n_blocks": len(rs),
                             "median_ratio": round(statistics.median(rs), 4),
                             "min": round(min(rs), 4),
                             "max": round(max(rs), 4),
                             "all_above_one": all(x > 1.0 for x in rs)}
    # data-seed spread vs timing spread (kept apart on purpose)
    timing_cv = {}
    for (bid, lvl, m), v in cells.items():
        if len(v) > 1 and statistics.median(v) > 0:
            timing_cv.setdefault(m, []).append(
                statistics.pstdev(v) / statistics.median(v) * 100.0)
    cross_engine = {}
    for bid in blocks:
        for lvl in LEVELS:
            sigs = {}
            for r in formal_rows:
                if r["block_id"] == bid and r["radius_level"] == lvl:
                    sigs.setdefault(r["sig_sha256"], set()).add(r["method"])
            cross_engine["%s|%s" % (bid, lvl)] = (len(sigs) == 1)
    inv_fail = [r for r in rows if r["inv_ok"] == "False"]

    summary = {
        "run_id": run_dir.name, "design_sha256": design_sha,
        "formal_rows": len(formal_rows), "rows_total": len(rows),
        "expected_formal_rows": len(SEEDS) * len(GEOMETRIES) * len(LEVELS)
        * len(METHODS) * args.reps,
        "aborted": state["aborted"], "abort_reason": state["reason"],
        "oracle_b0_all_pass": oracle["all_pass"],
        "cross_engine_signature_agreement": cross_engine,
        "invariant_failures": len(inv_fail),
        "per_cell": per_cell, "by_radius_level": by_level,
        "timing_cv_pct_by_method": {
            k: {"n_cells": len(v), "median_cv_pct": round(statistics.median(v), 2),
                "max_cv_pct": round(max(v), 2)} for k, v in timing_cv.items()},
        "wall_seconds": round(time.perf_counter() - t_start, 1),
    }
    (run_dir / "e2_summary.json").write_text(
        json.dumps(summary, indent=1, ensure_ascii=False), encoding="utf-8")

    with open(run_dir / "e2_cells.csv", "w", newline="",
              encoding="utf-8") as sf:
        w = csv.DictWriter(sf, fieldnames=list(per_cell[0].keys())
                           if per_cell else ["block_id"])
        w.writeheader()
        for c in per_cell:
            w.writerow(c)

    shutil.rmtree(tmp_root, ignore_errors=True)
    print("done: %s formal=%d oracle=%s inv_fail=%d"
          % (run_dir, len(formal_rows), oracle["all_pass"], len(inv_fail)),
          flush=True)
    return 0


def sha256_file_now(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


if __name__ == "__main__":
    sys.exit(main())
