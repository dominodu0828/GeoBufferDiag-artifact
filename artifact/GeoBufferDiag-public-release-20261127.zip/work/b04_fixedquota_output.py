# -*- coding: utf-8 -*-
"""B04 quota/output controlled diagnosis. Historical E1/E2 files are read-only."""
from __future__ import annotations

import argparse
import ctypes
import csv
import gzip
import hashlib
import json
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
from threadpoolctl import threadpool_limits
from splitbench.baseline_b1 import B1Engine
from splitbench.candidate import CandidateEngine
from splitbench.gate_d import make_city
from splitbench.settings import load_config
from splitbench.writers import _payload_lines, write_outputs

SEEDS = (20261121, 20261122, 20261123)
GEOMETRIES = ("uniform", "cluster")
LEVELS = ("p10", "p50", "p90")
METHODS = (("kd", "B1"), ("c", "Full"))
QUOTA_MODES = ("natural_shared", "fixed_common_min")
OUTPUT_PATHS = ("production_gzip", "serialized_count_digest_sink")
DEFAULT_RUN = "runs/b04-fixedquota-output-20261125-rerun01"
REPS = 7
WARMUPS = 1
N = 10000
FLOOR = 5
K_BLOCKS = 5
N_REPEATS = 5

COLS = ["seq", "block_id", "seed", "geometry", "radius_level", "radius_m",
        "method", "engine", "quota_mode", "output_path", "rep", "round",
        "formal", "order_pos", "method_order", "utc_start", "utc_end",
        "perf_start", "perf_end", "proc_cpu_s", "machine_busy_pct",
        "thread_count", "feasible", "quota_json", "pool_counts_json",
        "rows_out", "serialized_bytes", "serialized_sha256", "gzip_bytes",
        "ordered_outputs_sha256", "ordered_outputs_match", "digest_match",
        "ms_engine", "ms_index", "ms_exact", "ms_quota", "ms_select",
        "ms_payload", "ms_status", "ms_total", "ms_phase_exclusive_sum",
        "n_rows_exact", "n_rows_exact_quota", "n_rows_exact_select",
        "n_block_center_queries", "n_scan_rows_examined", "n_scan_batches",
        "counters_json", "status", "error"]


def utc():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


class MachineBusy:
    def __init__(self):
        self.ok = sys.platform == "win32"
        if self.ok:
            class FT(ctypes.Structure):
                _fields_ = [("lo", ctypes.c_uint32), ("hi", ctypes.c_uint32)]
            self.FT = FT
            self.k32 = ctypes.windll.kernel32

    def sample(self):
        if not self.ok:
            return None
        idle, kern, user = self.FT(), self.FT(), self.FT()
        if not self.k32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kern), ctypes.byref(user)):
            return None
        val = lambda x: (x.hi << 32) | x.lo
        return val(idle), val(kern) + val(user)

    @staticmethod
    def pct(a, b):
        if a is None or b is None:
            return ""
        di, dt = b[0] - a[0], b[1] - a[1]
        return round(100.0 * (1 - di / dt), 2) if dt > 0 else ""


def build(seed, geometry):
    return make_city(N, geometry, np.random.default_rng(seed),
                     k_blocks=K_BLOCKS, n_repeats=N_REPEATS, pos_ratio=0.5)


def radius_values(ct, folds):
    from scipy.spatial import cKDTree
    te = next(te for g, k, te in folds.repeat_folds(0) if g == 1 and k == 0)
    cand = np.flatnonzero(~te)
    d = cKDTree(ct.xy[te]).query(ct.xy[cand], k=1)[0]
    return {key: float(np.quantile(d, q)) for key, q in zip(LEVELS, (0.1, 0.5, 0.9))}


def per_fold_counts(ct, folds, radius):
    from scipy.spatial import cKDTree
    out = {}
    for rep in range(folds.n_repeats):
        rows = []
        for geom, k, te in folds.repeat_folds(rep):
            cand = np.flatnonzero(~te)
            if radius == 0:
                keep = np.ones(len(cand), dtype=bool)
            else:
                d = cKDTree(ct.xy[te]).query(ct.xy[cand], k=1)[0]
                keep = d > radius
            labels = ct.label[cand[keep]]
            rows.append((int((labels == 1).sum()), int((labels == 0).sum())))
        out[rep] = rows
    return out


def frozen_quota(block):
    by_r = {l: block["counts"][l] for l in LEVELS}
    quota = []
    for level in LEVELS:
        for rep in range(N_REPEATS):
            q_pos = min(pair[0] for pair in by_r[level][rep])
            q_neg = min(pair[1] for pair in by_r[level][rep])
            quota.append((q_pos, q_neg))
    # Return one repeat-indexed quota vector for each radius. The fixed
    # diagnostic quota is the component-wise common minimum across radii.
    fixed = []
    for rep in range(N_REPEATS):
        fixed.append((
            min(by_r[level][rep][fold][0]
                for level in LEVELS
                for fold in range(len(by_r[level][rep]))),
            min(by_r[level][rep][fold][1]
                for level in LEVELS
                for fold in range(len(by_r[level][rep])))))
    return {"by_radius": {level: [
                (min(pair[0] for pair in by_r[level][rep]),
                 min(pair[1] for pair in by_r[level][rep]))
                for rep in range(N_REPEATS)] for level in LEVELS},
            "common_min": fixed}


def _ordered_payload_digest(res):
    h = hashlib.sha256()
    for r in sorted(res.matched):
        for c in res.matched[r]:
            h.update(json.dumps([r, c["rep"], c["geom"], c["fold"],
                                 list(map(int, c["quota"])),
                                 np.asarray(c["unbuf_pos"], dtype=np.int64).tolist(),
                                 np.asarray(c["unbuf_neg"], dtype=np.int64).tolist(),
                                 np.asarray(c["buf_pos"], dtype=np.int64).tolist(),
                                 np.asarray(c["buf_neg"], dtype=np.int64).tolist()],
                                separators=(",", ":")).encode())
            h.update(b"\n")
    return h.hexdigest()


def serialized_bytes(ct, folds, res):
    raw = "".join(_payload_lines(ct, folds, res, "matched")).encode("utf-8")
    return raw, len(raw.splitlines()), sha(raw)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default=DEFAULT_RUN)
    ap.add_argument("--reps", type=int, default=REPS)
    ap.add_argument("--warmups", type=int, default=WARMUPS)
    args = ap.parse_args()
    run_dir = Path(args.run)
    if not run_dir.is_absolute():
        run_dir = ROOT / run_dir
    if run_dir.exists():
        raise FileExistsError("refusing to overwrite existing run path: %s" % run_dir)
    run_dir.mkdir(parents=True)

    cfg = load_config(ROOT / "configs" / "paper_primary.yaml")
    ec = cfg["engine"]
    side, margin, batch = float(ec["block_grid_side_m"]), float(ec["block_float_margin_m"]), int(ec["scan_batch_rows"])
    floor, threads = int(cfg["run"]["quota_floor"]), int(cfg["run"]["threads"])
    blocks = {}
    design_blocks = []
    for seed in SEEDS:
        for geom in GEOMETRIES:
            bid = "%s/%s" % (seed, geom)
            ct, folds = build(seed, geom)
            radii = radius_values(ct, folds)
            counts = {lev: per_fold_counts(ct, folds, radii[lev]) for lev in LEVELS}
            blocks[bid] = {"ct": ct, "folds": folds, "radii": radii,
                           "counts": counts, "fixed": None}
            blocks[bid]["fixed"] = frozen_quota(blocks[bid])
            design_blocks.append({"block_id": bid, "seed": seed, "geometry": geom,
                                  "n_rows": N, "radii_m": radii,
                                  "radius_definition": "p10/p50/p90 nearest-test distance, rep0 scattered fold0",
                                  "natural_shared_by_radius_repeat": blocks[bid]["fixed"]["by_radius"],
                                  "fixed_common_min_by_repeat": blocks[bid]["fixed"]["common_min"],
                                  "fixed_quota_pairs_by_repeat": [list(v) for v in blocks[bid]["fixed"]["common_min"]],
                                  "natural_pool_counts_by_radius_repeat_fold": counts,
                                  "coordinate_sha256": sha(np.asarray(ct.xy, dtype=np.float64).tobytes()),
                                  "labels_sha256": sha(np.asarray(ct.label, dtype=np.int8).tobytes()),
                                  "keys_sha256": sha(np.asarray(ct.keys, dtype=np.float64).tobytes()),
                                  "folds_sha256": sha(b"".join(np.packbits(te).tobytes() for rep in range(folds.n_repeats) for _, _, te in folds.repeat_folds(rep)))})

    code_paths = sorted((ROOT / "splitbench").glob("*.py")) + [ROOT / "configs" / "paper_primary.yaml", Path(__file__).resolve()]
    design = {"run_id": run_dir.name, "created_utc": utc(),
              "manifest": "10_未完成实验与整批执行清单_20261125.md §6 B04",
              "matrix": {"geometries": GEOMETRIES, "seeds": SEEDS, "radius_levels": LEVELS,
                         "methods": METHODS, "quota_modes": QUOTA_MODES,
                         "output_paths": OUTPUT_PATHS, "formal_repetitions": args.reps,
                         "warmup_rounds": args.warmups},
              "expected_formal_rows": len(GEOMETRIES)*len(SEEDS)*len(LEVELS)*len(METHODS)*len(QUOTA_MODES)*len(OUTPUT_PATHS)*args.reps,
            "formal_repeat_numbers": list(range(1, args.reps + 1)),
              "blocks": design_blocks,
              "quota_definition": "natural_shared = engine's per-radius per-repeat min buffered class pool across contiguous and scattered folds; fixed_common_min = before timing, component-wise minimum of each radius's natural shared quotas over all three radii, separately for each repeat; prescribed list is in repeat_folds order and result quota serialization preserves that order; fixed mode is explicitly diagnostic and not the natural contract",
              "output_definition": "production_gzip calls splitbench.writers.write_outputs; serialized_count_digest_sink consumes exact UTF-8 serialized payload bytes from the same _payload_lines stream without gzip/file output; not interpreted as pure compression or disk cost",
              "timing": {"exclusive_parent_stages": ["engine_run_city", "payload_sink_or_gzip", "status_csv"], "engine_phases": "res.phases.index/exact/quota/select are separately reported; Full exact work nested in quota/select remains contained in those phase parents and is never added again", "all_cases_serial": True, "perf_counter": "per-case elapsed boundaries; perf_start/perf_end are global monotonic readings", "cpu": "process_time delta and Windows GetSystemTimes machine busy delta", "thread_count": threads},
              "ordering": "deterministic interleaving; method order flips by (radius_index + rep + quota_mode_index + output_path_index + block_index) parity",
              "engine_params": {"block_grid_side_m": side, "block_float_margin_m": margin, "scan_batch_rows": batch, "quota_floor": floor},
              "code_sha256": {str(p.relative_to(ROOT)).replace("\\", "/"): sha_file(p) for p in code_paths},
              "environment": {"python": sys.version, "platform": platform.platform(), "cpu_count": os.cpu_count(), "threadpool_limit": threads}}
    design_path = run_dir / "design.json"
    design_path.write_text(json.dumps(design, indent=1, ensure_ascii=False), encoding="utf-8")
    design["design_sha256"] = sha_file(design_path)
    (run_dir / "design_frozen.json").write_text(json.dumps(design, indent=1, ensure_ascii=False), encoding="utf-8")

    rows_path = run_dir / "b04_rows.csv"
    busy = MachineBusy()
    seq = 0
    total_cases = len(blocks)*len(LEVELS)*len(METHODS)*len(QUOTA_MODES)*len(OUTPUT_PATHS)*(args.reps+args.warmups)
    state = {"aborted": False, "reason": ""}
    with rows_path.open("x", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLS); w.writeheader(); fh.flush()
        for rnd in range(args.reps + args.warmups):
            formal = rnd >= args.warmups
            rep = rnd - args.warmups + 1 if formal else 0
            for bi, (bid, b) in enumerate(blocks.items()):
                ct, folds = b["ct"], b["folds"]
                for ri, level in enumerate(LEVELS):
                    r = b["radii"][level]
                    for qi, quota_mode in enumerate(QUOTA_MODES):
                        prescribed = None
                        if quota_mode == "fixed_common_min":
                            fixed_q = b["fixed"]["common_min"]
                            prescribed = {r: [tuple(int(v) for v in fixed_q[i])
                                             for i in range(N_REPEATS)]}
                        for oi, output_path in enumerate(OUTPUT_PATHS):
                            order = METHODS if (ri+rep+qi+oi+bi) % 2 == 0 else METHODS[::-1]
                            for pos, (method, label) in enumerate(order, 1):
                                seq += 1
                                start_utc, perf_start = utc(), time.perf_counter()
                                proc0, busy0 = time.process_time(), busy.sample()
                                row = dict.fromkeys(COLS, "")
                                row.update(seq=seq, block_id=bid, seed=bid.split("/")[0], geometry=bid.split("/")[1], radius_level=level, radius_m=r, method=method, quota_mode=quota_mode, output_path=output_path, rep=rep, **{"round": "warmup" if not formal else rep}, formal=int(formal), order_pos=pos, method_order=">".join(x[1] for x in order), utc_start=start_utc, perf_start=perf_start, thread_count=threads, status="ok")
                                try:
                                    eng = B1Engine() if method == "kd" else CandidateEngine(arm="c", side=side, margin=margin, batch_rows=batch, policy="priority")
                                    with threadpool_limits(limits=threads):
                                        t = time.perf_counter(); res, _ = eng.run_city(ct, folds, [r], "matched", state=None, floor=floor, prescribed=prescribed); ms_engine = (time.perf_counter()-t)*1000
                                        raw, payload_rows, payload_sha = serialized_bytes(ct, folds, res)
                                        gzip_bytes = ""
                                        if output_path == "production_gzip":
                                            t=time.perf_counter()
                                            payload_rows, gzip_bytes, _ = write_outputs(run_dir / "tmp" / ("seq%06d" % seq), eng.name, ct, folds, res, "matched")
                                            ms_payload=(time.perf_counter()-t)*1000
                                            gz_path=run_dir/"tmp"/("seq%06d"%seq)/"out"/eng.name/("%s__%s__matched.csv.gz"%(ct.dataset,ct.city))
                                            if gzip.decompress(gz_path.read_bytes()) != raw:
                                                raise AssertionError("gzip bytes do not match shared serialized payload")
                                        else:
                                            t=time.perf_counter(); sink_n=0; sink_h=hashlib.sha256()
                                            for line in _payload_lines(ct, folds, res, "matched"):
                                                chunk=line.encode("utf-8"); sink_n+=len(chunk); sink_h.update(chunk)
                                            ms_payload=(time.perf_counter()-t)*1000
                                            if sink_n != len(raw) or sink_h.hexdigest() != payload_sha:
                                                raise AssertionError("count/digest sink disagrees with serialized payload")
                                        t=time.perf_counter()
                                        from splitbench.writers import write_status
                                        write_status(run_dir / "tmp" / ("seq%06d"%seq), eng.name, ct, folds, res, [r], "matched")
                                        ms_status=(time.perf_counter()-t)*1000
                                    perf_end=time.perf_counter(); proc_s=time.process_time()-proc0; busy1=busy.sample()
                                    actual_ordered=_ordered_payload_digest(res)
                                    row.update(utc_end=utc(), perf_end=perf_end, proc_cpu_s=round(proc_s,6), machine_busy_pct=busy.pct(busy0,busy1), feasible=str(bool((res.status.get(r) or {}).get("feasible"))), quota_json=json.dumps(res.quota.get(r), separators=(",", ":")), pool_counts_json=json.dumps(b["counts"][level], separators=(",", ":")), rows_out=payload_rows, serialized_bytes=len(raw), serialized_sha256=payload_sha, gzip_bytes=gzip_bytes, ordered_outputs_sha256=actual_ordered, ordered_outputs_match=True, digest_match=(sha(raw)==payload_sha), ms_engine=round(ms_engine,3), ms_index=round(res.phases.index*1000,3), ms_exact=round(res.phases.exact*1000,3), ms_quota=round(res.phases.quota*1000,3), ms_select=round(res.phases.select*1000,3), ms_payload=round(ms_payload,3), ms_status=round(ms_status,3), ms_total=round(ms_engine+ms_payload+ms_status,3), ms_phase_exclusive_sum=round((res.phases.index+res.phases.exact+res.phases.quota+res.phases.select)*1000,3), n_rows_exact=res.counters.get("n_rows_exact", ""), n_rows_exact_quota=res.counters.get("n_rows_exact_quota", ""), n_rows_exact_select=res.counters.get("n_rows_exact_select", ""), n_block_center_queries=res.counters.get("n_block_center_queries", ""), n_scan_rows_examined=res.counters.get("n_scan_rows_examined", ""), n_scan_batches=res.counters.get("n_scan_batches", ""), counters_json=json.dumps(res.counters, sort_keys=True))
                                    # Retain per-case output files only for successful production-gzip rows.
                                    (run_dir/"tmp"/("seq%06d"%seq)/"out").mkdir(parents=True, exist_ok=True)
                                except Exception as e:
                                    row.update(status="error", error="%s: %s"%(type(e).__name__,e), utc_end=utc(), perf_end=time.perf_counter(), proc_cpu_s=round(time.process_time()-proc0,6), machine_busy_pct=busy.pct(busy0,busy.sample()))
                                    if "res" in locals() and hasattr(res, "matched"):
                                        row["quota_json"] = json.dumps(res.quota.get(r), separators=(",", ":"))
                                        row["ordered_outputs_sha256"] = _ordered_payload_digest(res)
                                        row["error"] += "; partial output digest retained"
                                    state["aborted"] = True; state["reason"] = "case %d failed: %s"%(seq,row["error"])
                                w.writerow(row); fh.flush()
                                if state["aborted"]: break
                            if state["aborted"]: break
                        if state["aborted"]: break
                    if state["aborted"]: break
                if state["aborted"]: break
            if state["aborted"]: break
    # Keep case output files as evidence; do not bulk-delete them.
    with rows_path.open(encoding="utf-8", newline="") as check_fh:
        actual = list(csv.DictReader(check_fh))
    formal_rows = [x for x in actual if x["formal"] == "1"]
    by_identity = {}
    fixed_quota_mismatches = []
    for x in actual:
        if x["formal"] == "1" and x["quota_mode"] == "fixed_common_min" and x["status"] == "ok":
            block = next(z for z in design_blocks if z["block_id"] == x["block_id"])
            expected_quotas = block["fixed_quota_pairs_by_repeat"]
            actual_q = json.loads(x["quota_json"])
            if actual_q != expected_quotas:
                fixed_quota_mismatches.append(x["seq"])
        if x["status"] == "ok":
            key = (x["block_id"], x["radius_level"], x["quota_mode"], x["rep"], x["output_path"])
            old = by_identity.setdefault(key, {})
            old.setdefault(x["method"], set()).add(x["ordered_outputs_sha256"])
    cross_method_matches = all(len(v) == 1 for pair in by_identity.values() for v in pair.values())
    summary = {"run_id": run_dir.name, "expected_formal_rows": design["expected_formal_rows"], "actual_rows": len(actual), "actual_formal_rows": len(formal_rows), "expected_total_with_warmups": total_cases, "aborted": state["aborted"], "abort_reason": state["reason"], "all_case_status_ok": all(x["status"] == "ok" for x in actual), "ordered_output_digest_present": all(bool(x["ordered_outputs_sha256"]) for x in actual if x["status"] == "ok"), "serialized_digest_match": all(x["digest_match"] == "True" for x in actual if x["status"] == "ok"), "cross_method_ordered_output_digest_match": cross_method_matches, "fixed_quota_mismatches": len(fixed_quota_mismatches), "all_1008_formal_complete": len(formal_rows) == design["expected_formal_rows"] and not state["aborted"] and not fixed_quota_mismatches, "finished_utc": utc()}
    (run_dir/"b04_summary.json").write_text(json.dumps(summary,indent=1,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(summary,ensure_ascii=False),flush=True)
    if summary["all_1008_formal_complete"]:
        print("B04 complete: %d formal rows + %d warmups" % (len(formal_rows), len(actual)-len(formal_rows)), flush=True)
    return 0 if summary["all_1008_formal_complete"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
