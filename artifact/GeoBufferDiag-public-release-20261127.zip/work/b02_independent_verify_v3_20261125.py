# -*- coding: utf-8 -*-
"""B02 E2 独立验证器 v2；分块穷举精确距离，不依赖引擎。"""
from __future__ import annotations
import argparse,csv,hashlib,json,os,platform,sys,time,gzip
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];DEFAULT=ROOT/"runs"/"b02-independent-v3-20261125";LEVELS=("p10","p50","p90");QUANTILES=(.1,.5,.9);CHUNK_DEFAULT=64

def sha256_file(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1<<20),b""):h.update(b)
 return h.hexdigest()
def fail(s):raise ValueError(s)
def parse_args(argv=None):
 p=argparse.ArgumentParser(description=__doc__);p.add_argument("--design",type=Path,default=ROOT/"runs/e2-radius-20261123-a/design.json");p.add_argument("--rows",type=Path,default=ROOT/"runs/e2-radius-20261123-a/e2_rows.csv");p.add_argument("--output-dir",type=Path,default=DEFAULT);p.add_argument("--distance-chunk",type=int,default=CHUNK_DEFAULT);p.add_argument("--estimate-only",action="store_true",help="完整执行单个10k block距离算法测耗时");p.add_argument("--test-mode",action="store_true",help="运行小规模合成阵列自测，不视为正式覆盖");p.add_argument("--test-root",type=Path,default=Path(os.environ.get("B02_TEST_ROOT",ROOT)));return p.parse_args(argv)
def load_inputs(dp,rp):
 design=json.loads(dp.read_text(encoding="utf-8"))
 with rp.open("r",encoding="utf-8-sig",newline="") as f:reader=csv.DictReader(f);rows=list(reader);columns=set(reader.fieldnames or())
 required=set("block_id seed geometry n_rows radius_level radius_m method rep formal feasible note quota_pos quota_neg quota_json rows_out dec_bytes dec_sha256 pool_pos pool_neg deletion_rate deletion_rate_min deletion_rate_max inv_ok sig_sha256".split())
 if required-columns:fail("rows CSV缺列: "+", ".join(sorted(required-columns)))
 status_path=rp.with_name("e2_status.csv");status_rows=[]
 if status_path.is_file():
  with status_path.open("r",encoding="utf-8-sig",newline="") as f:status_rows=list(csv.DictReader(f))
 return design,rows,status_rows
def build_data(seed,geometry,n,c):
 """内联原始synthetic生成语义以及NumPy RNG调用顺序。"""
 rng=np.random.default_rng(seed)
 if geometry=="uniform":xy=rng.uniform(0.,10000.,(n,2))
 elif geometry=="cluster":
  nc=int(.8*n);xy=np.vstack((rng.normal(0.,1000.,(nc,2))+(5000.,5000.),rng.uniform(0.,10000.,(n-nc,2))))
 else:fail("unsupported geometry")
 xy=np.clip(xy,0.,10000.);labels=(rng.random(n)<float(c["pos_ratio"])).astype(np.int8);keys=rng.random(n);k=int(c["k_blocks"]);gx=np.clip((xy[:,0]/(10000./k)).astype(np.int64),0,k-1);blocks=[gx==j for j in range(k) if np.any(gx==j)];scattered=[]
 for _ in range(int(c["n_repeats"])):
  masks=[]
  for group in np.array_split(rng.permutation(n),k):
   t=np.zeros(n,dtype=bool);t[group]=True;masks.append(t)
  scattered.append(masks)
 return xy,labels,keys,blocks,scattered
def ordered_folds(blocks,scattered,rep):return [(0,j,t) for j,t in enumerate(blocks)]+[(1,j,t) for j,t in enumerate(scattered[rep])]
def exact_distances(xy,test,candidates,chunk):
 """候选点分块，穷举全部candidate-test float64欧氏距离，无索引或剪枝。"""
 test_xy=xy[test];out=np.empty(len(candidates),dtype=np.float64)
 for start in range(0,len(candidates),chunk):
  ids=candidates[start:start+chunk];delta=xy[ids,None,:]-test_xy[None,:,:];d2=np.einsum("ijk,ijk->ij",delta,delta,optimize=False);out[start:start+len(ids)]=np.sqrt(d2.min(axis=1))
 return out
def class_order(labels,keys,cls):
 ids=np.flatnonzero(labels==cls);return ids[np.lexsort((ids,keys[ids]))]
def choose(order,available,q):return order[available[order]][:q]
def derive(block,radii,floor,chunk):
 n=int(block["n_rows"]);xy,y,keys,blocks,scattered=build_data(int(block["seed"]),block["geometry"],n,block["frozen_constants"]);des=scattered[0][0];di=np.flatnonzero(~des);dist=exact_distances(xy,des,di,chunk);calculated={lv:round(float(np.quantile(dist,q)),6) for lv,q in zip(LEVELS,QUANTILES)};radius_check={lv:{"design":float(block["radius_m"][lv]),"independent":calculated[lv],"match":float(block["radius_m"][lv])==calculated[lv]} for lv in LEVELS};cache=[]
 for rep in range(int(block["frozen_constants"]["n_repeats"])):
  records=[]
  for geom,fi,test in ordered_folds(blocks,scattered,rep):cand=np.flatnonzero(~test);records.append({"geom":geom,"fold":fi,"test":test,"cand":cand,"dist":exact_distances(xy,test,cand,chunk)})
  cache.append(records)
 orders={1:class_order(y,keys,1),0:class_order(y,keys,0)};results={}
 for level in LEVELS:
  radius=float(radii[level]);repeats=[];pools_by_repeat=[]
  for records in cache:
   pools=[];counts=[]
   for f in records:
    kept=np.zeros(n,dtype=bool);kept[f["cand"][f["dist"]>radius]]=True;counts.append((int(np.count_nonzero(y[kept]==1)),int(np.count_nonzero(y[kept]==0))));pools.append({**f,"keep":kept})
   quota=(min(pos for pos,neg in counts),min(neg for pos,neg in counts)) if counts else (0,0);feasible=bool(counts) and quota[0]>=floor and quota[1]>=floor;repeats.append({"quota":quota,"feasible":feasible,"fold_counts":counts});pools_by_repeat.append(pools)
  status=bool(blocks) and all(x["feasible"] for x in repeats);comparisons=[]
  for rep,(rr,pools) in enumerate(zip(repeats,pools_by_repeat)):
   qp,qn=rr["quota"]
   for f in pools:
    avail=np.zeros(n,dtype=bool);avail[f["cand"]]=True
    comparisons.append({"rep":rep,"geom":f["geom"],"fold":f["fold"],"quota":[qp,qn],"feasible":status,"unbuf_pos":choose(orders[1],avail,qp) if status else np.array([],dtype=np.int64),"unbuf_neg":choose(orders[0],avail,qn) if status else np.array([],dtype=np.int64),"buf_pos":choose(orders[1],f["keep"],qp) if status else np.array([],dtype=np.int64),"buf_neg":choose(orders[0],f["keep"],qn) if status else np.array([],dtype=np.int64)})
  results[level]={"radius":radius,"repeats":repeats,"feasible":status,"comparisons":comparisons}
 props={}
 for level in LEVELS:
  r=float(radii[level]);rates=[];pp=pn=0
  for f in cache[0][len(blocks):]:
   kept=f["cand"][f["dist"]>r];rates.append(1-len(kept)/len(f["cand"]));pp+=int(np.count_nonzero(y[kept]==1));pn+=int(np.count_nonzero(y[kept]==0))
  props[level]={"deletion_rate":round(float(np.mean(rates)),6),"deletion_rate_min":round(float(np.min(rates)),6),"deletion_rate_max":round(float(np.max(rates)),6),"pool_pos":pp,"pool_neg":pn}
 return {"xy":xy,"labels":y,"keys":keys,"results":results,"radius_checks":radius_check,"pool_metrics":props,"blocks":blocks,"scattered":scattered}


def expected_matrix(design):
 methods=[m["method"] for m in design["methods"]];return {(b["block_id"],lv,m,rep,formal) for b in design["blocks"] for lv in design["radius_levels"] for m in methods for formal,reps in ((0,1),(1,int(design["repetitions_formal"]))) for rep in (range(0,1) if formal==0 else range(1,reps+1))}
def compare_contract(expected,actual):return [k for k in expected if expected[k]!=actual.get(k)]
def compare_csv_contract(expected,actual):return {field:(expected.get(field),actual.get(field)) for field in expected if expected.get(field)!=actual.get(field)}
def csv_field_fault_injection(rows):
 source=next(r for r in rows if r.get("round")=="warmup")
 cases=(("method_digest","sig_sha256",lambda r:"0"*64),("round","round",lambda r:"invalid"),("quota","quota_pos",lambda r:str(int(r["quota_pos"])+1)),("status","feasible",lambda r:"not-a-bool"))
 checks=[]
 for label,field,mutate in cases:
  altered=dict(source);altered[field]=mutate(source);checks.append({"mutation":label,"field":field,"detected":field in compare_csv_contract(source,altered)})
 return checks
def fault_injection(derived):
 block=next(iter(derived.values()));level=next(iter(block["results"]));r=block["results"][level];comp=next(c for c in r["comparisons"] if c["feasible"]);base={"ids_pos":comp["buf_pos"].tolist(),"ids_neg":comp["buf_neg"].tolist(),"quota":list(comp["quota"]),"status":bool(comp["feasible"])};checks=[]
 for label,field,mut in (("id","ids_pos",base["ids_pos"][:-1]+[base["ids_pos"][-1]+1]),("order","ids_pos",base["ids_pos"][::-1]),("quota","quota",[base["quota"][0]+1,base["quota"][1]]),("status","status",not base["status"])):
  altered=dict(base);altered[field]=mut;checks.append({"mutation":label,"field":field,"detected":field in compare_contract(base,altered)})
 return checks
def record_key(r):return (r["block_id"],r["radius_level"],r["method"],int(r["rep"]),int(r["formal"]))
def logical_repeat(r):return 0
def matrix_formal(r):return 0 if r.get("round")=="warmup" and int(r["rep"])==0 and int(r["formal"])==0 else 1
def row_quota(r):
 actual=json.loads(r["quota_json"])
 if isinstance(actual,dict):actual=[actual[str(i)] for i in range(len(actual))]
 return [[int(x[0]),int(x[1])] for x in actual]
def compare_all(design,rows,derived,expected_status_rows):
 diffs=[];counts={"formal":0,"warmup":0};seen={};blocks={b["block_id"]:b for b in design["blocks"]};status_diffs=[]
 def diff(where,field,expected,actual):diffs.append({"where":where,"field":field,"expected":expected,"actual":actual})
 def canonical_quota(value):
  data=json.loads(value)
  if isinstance(data,dict):data=[data[str(i)] for i in range(len(data))]
  return [[int(pair[0]),int(pair[1])] for pair in data]

 exp=expected_matrix(design)
 for r in rows:
  key=record_key(r);counts["formal" if matrix_formal(r) else "warmup"]+=1
  rep=int(r["rep"]);formal=int(r["formal"]);round_value=r.get("round","")
  legal=(rep==0 and formal==0 and round_value=="warmup") or (1<=rep<=7 and formal==1 and round_value==str(rep))
  if not legal:diff(str(key),"rep_formal_round", "warmup 0/0/warmup or formal 1..7/1/round==str(rep)", {"rep":rep,"formal":formal,"round":round_value})
  if key in seen:diff("matrix", "duplicate", str(key), "duplicate row")
  seen[key]=r
  if key not in exp:diff(str(key),"unexpected_row","not present","present");continue
  bid,lv,method,rep,formal=key
  b=blocks[bid];d=derived[bid];res=d["results"][lv];logical_rep=logical_repeat(r);repeat=res["repeats"][logical_rep];qp,qn=repeat["quota"]
  qfirst=res["repeats"][0]["quota"]
  for f,v in (("seed",b["seed"]),("geometry",b["geometry"]),("n_rows",b["n_rows"]),("radius_m",res["radius"]),("quota_pos",qfirst[0]),("quota_neg",qfirst[1]),("feasible",res["feasible"]),("sig_sha256",r["sig_sha256"])):
   actual=r[f];expected=v
   try:
    if f in ("seed","n_rows","quota_pos","quota_neg"):actual=int(actual)
    elif f in ("radius_m",):actual=float(actual)
    elif f=="feasible":actual=str(actual).lower()=="true"
   except Exception:pass
   if actual!=expected:diff(str(key),f,expected,actual)
  if len(r["sig_sha256"])!=64 or any(ch not in "0123456789abcdef" for ch in r["sig_sha256"].lower()):diff(str(key),"sig_sha256_format","64 hexadecimal characters",r["sig_sha256"])
  expected_q=[list(map(int,x["quota"])) for x in res["repeats"]];actual_q=row_quota(r)
  if actual_q!=expected_q:diff(str(key),"quota_json",expected_q,actual_q)
  if int(r["rows_out"])!=(0 if not res["feasible"] else 1+2*len(res["comparisons"])):diff(str(key),"rows_out",0 if not res["feasible"] else 1+2*len(res["comparisons"]),int(r["rows_out"]))
  if not res["feasible"]:
   if matrix_formal(r):
    if r["note"] not in ("", "quota_floor"):diff(str(key),"note","feasibility failure note",r["note"])
   elif r["note"] not in ("", "warmup"):diff(str(key),"note","warmup or empty",r["note"])
   if r["inv_ok"].lower()!="true":diff(str(key),"inv_ok","true",r["inv_ok"])
   continue
  if matrix_formal(r):
   if r["note"]:diff(str(key),"note","",r["note"])
  elif r["note"] not in ("", "warmup"):diff(str(key),"note","warmup or empty",r["note"])
  if r["inv_ok"].lower()!="true":diff(str(key),"inv_ok","true",r["inv_ok"])
  f=next(x for x in res["comparisons"] if x["rep"]==logical_rep and x["geom"]==1 and x["fold"]==0)
  if res["feasible"]:
   if matrix_formal(r):
    output_rows=1+2*len(res["comparisons"])
    if int(r["rows_out"])!=output_rows:diff(str(key),"rows_out",output_rows,int(r["rows_out"]))
    # E2 retained only per-radius digests, not the original gzip payload. The
    # writer's fast_path bit and payload bytes cannot be proven from CSV alone.
   else:
    if int(r["rows_out"])!=1+2*len(res["comparisons"]):diff(str(key),"rows_out",1+2*len(res["comparisons"]),int(r["rows_out"]))
   if matrix_formal(r):
    refhash=next((x for x in rows if x["block_id"]==bid and x["radius_level"]==lv and x["method"]==method and x["rep"]=="1" and x["formal"]=="1"),None)
    if refhash and (r["dec_bytes"]!=refhash["dec_bytes"] or r["dec_sha256"]!=refhash["dec_sha256"]):diff(str(key),"within_method_repeat_payload_hash",{"dec_bytes":refhash["dec_bytes"],"dec_sha256":refhash["dec_sha256"]},{"dec_bytes":r["dec_bytes"],"dec_sha256":r["dec_sha256"]})
  # Historical pool/deletion summaries are repeat-0 scattered-fold aggregates
  # frozen in design.json; compare the CSV to that artifact, and independently
  # compare the same frozen artifact to the freshly recomputed arrays below.
  frozen=blocks[bid]["data_properties_at_level"][lv]
  for metric in ("pool_pos","pool_neg"):
   if int(r[metric])!=int(frozen[metric]):diff(str(key),metric,int(frozen[metric]),int(r[metric]))
  for metric in ("deletion_rate","deletion_rate_min","deletion_rate_max"):
   if abs(float(r[metric])-float(frozen[metric]))>1e-6:diff(str(key),metric,float(frozen[metric]),float(r[metric]))
 missing=exp-set(seen)
 for key in sorted(missing):diff(str(key),"missing_row","present","missing")
 for bid,d in derived.items():
  for lv,x in d["radius_checks"].items():
   if not x["match"]:diff(bid+"/"+lv,"radius_m",x["design"],x["independent"])
   frozen=blocks[bid]["data_properties_at_level"][lv]
   independent_pool=d["pool_metrics"][lv]
   for metric in ("pool_pos","pool_neg"):
    expected=int(frozen[metric]);actual=int(independent_pool[metric])
    if actual!=expected:diff(bid+"/"+lv,metric,expected,actual)
   for metric in ("deletion_rate","deletion_rate_min","deletion_rate_max"):
    expected=float(frozen[metric]);actual=float(independent_pool[metric])
    if abs(actual-expected)>1e-6:diff(bid+"/"+lv,metric,expected,actual)
 # Paired method keys must match beyond the full matrix.
 groups={}
 for r in rows:
  if matrix_formal(r):groups.setdefault((r["block_id"],r["radius_level"],int(r["rep"]),1),set()).add(r["method"])
  elif int(r["rep"])==0:groups.setdefault((r["block_id"],r["radius_level"],0,0),set()).add(r["method"])
 expected_methods={m["method"] for m in design["methods"]}
 for k,v in groups.items():
  if v!=expected_methods:diff(str(k),"paired_methods",sorted(expected_methods),sorted(v))
 for key in exp:
  if key not in seen:continue
  bid,lv,method,rep,formal=key
  if method!=min(expected_methods):continue
  peer_method=next((m for m in expected_methods if m!=method),None)
  peer_key=(bid,lv,peer_method,rep,formal)
  if peer_key not in seen:continue
  left,right=seen[key],seen[peer_key]
  for field in ("quota_json","feasible","rows_out","dec_sha256","dec_bytes","sig_sha256"):
   lv0=canonical_quota(left[field]) if field=="quota_json" else left[field]
   rv0=canonical_quota(right[field]) if field=="quota_json" else right[field]
   if field in ("rows_out","dec_bytes"):lv0,rv0=int(lv0),int(rv0)
   if lv0!=rv0:diff(str(key),"paired_"+field,lv0,rv0)
 for sr in expected_status_rows:
  dataset=sr.get("dataset","");city=sr.get("city","");matches=[bid for bid in derived if bid.split("/")[1]==city]
  if len(matches)!=1:
   status_diffs.append({"where":"status","field":"city_mapping","expected":"one design block","actual":sr});continue
  bid=matches[0];b=blocks[bid];lv=next((level for level in LEVELS if abs(float(sr.get("radius","nan"))-float(b["radius_m"][level]))<5e-7),None)
  if lv is None:
   status_diffs.append({"where":str(sr),"field":"radius_mapping","expected":"one frozen radius","actual":sr.get("radius")});continue
  expected=derived[bid]["results"][lv]["feasible"];actual=str(sr.get("feasible","")).lower()=="true"
  if actual!=expected:status_diffs.append({"where":bid+"/"+lv+"/"+str(sr.get("repeat")),"field":"feasible/status","expected":expected,"actual":actual})
 return {"diffs":diffs,"status_diffs":status_diffs,"counts":counts,"expected_rows":len(exp),"observed_rows":len(rows)}
def canonical(obj):return json.dumps(obj,sort_keys=True,separators=(",",":"),default=lambda x:x.tolist() if isinstance(x,np.ndarray) else str(x)).encode()
def decimal_ids(ids):return "|".join(map(str,ids.tolist())) if len(ids) else ""
def expected_payload_bytes(block_id,level,radius,results,arm):
 geom_names={0:"contiguous",1:"scattered"};lines=["dataset,city,radius,geometry,repeat,fold,arm,n_pos,n_neg,fast_path,ids_pos,ids_neg\n"]
 for c in results["comparisons"]:
  if c["rep"]!=0:continue
  geom_name=geom_names[c["geom"]];qp,qn=c["quota"]
  pos=c["unbuf_pos"] if arm=="kd" else c["buf_pos"];neg=c["unbuf_neg"] if arm=="kd" else c["buf_neg"]
  lines.append("%s,%s,%s,%s,%d,%d,%s,%d,%d,0,%s,%s\n"%(block_id.split("/")[0],block_id.split("/")[1],format(float(radius),".17g"),geom_name,c["rep"],c["fold"],arm,qp,qn,decimal_ids(pos),decimal_ids(neg)))
 return "".join(lines).encode("utf-8")
def safe_output_path(path,dp,rp,root=ROOT):
 path=Path(os.path.abspath(path));parent=path.parent;root=Path(os.path.abspath(root))
 if path.exists():fail("输出目录已存在，拒绝覆盖: "+str(path))
 if not parent.is_dir():fail("输出父目录不存在: "+str(parent))
 if not path.is_relative_to(root):fail("输出必须位于项目根目录内")
 forbidden=[dp,rp,root/"runs/e2-radius-20261123-a"]
 for item in forbidden:
  item=Path(os.path.abspath(item))
  if path==item or item in path.parents or path in item.parents:fail("输出路径与历史输入/结果冲突: "+str(item))
 if path.parent.resolve()!=parent.resolve():fail("输出父目录路径解析不一致")
 return path
def main(argv=None):
 a=parse_args(argv)
 if a.output_dir.exists():fail("输出目录已存在，拒绝覆盖: "+str(a.output_dir))
 if a.distance_chunk<1:fail("distance chunk必须为正")
 dp=a.design.resolve(strict=True);rp=a.rows.resolve(strict=True);safety_root=a.test_root.resolve() if a.test_mode else ROOT;out=safe_output_path(a.output_dir,dp,rp,safety_root)
 design,rows,status_rows=load_inputs(dp,rp)
 if a.estimate_only:
  b=design["blocks"][0];t=time.perf_counter();xy,y,k,blocks,sc=build_data(b["seed"],b["geometry"],b["n_rows"],b["frozen_constants"]);exact_distances(xy,sc[0][0],np.flatnonzero(~sc[0][0]),a.distance_chunk);elapsed=time.perf_counter()-t;print(json.dumps({"block_id":b["block_id"],"seconds":elapsed,"chunk":a.distance_chunk,"pairs":int(len(sc[0][0])*len(np.flatnonzero(~sc[0][0]))),"estimate_only":True},indent=2));return 0
 if a.test_mode:
  b=design["blocks"][0];small=dict(b);small["n_rows"]=256;d=derive(small,{lv:0.0 for lv in LEVELS},int(design["quota_floor"]),a.distance_chunk);checks=fault_injection({b["block_id"]:d});assert len(d["results"])==3 and all(x["detected"] for x in checks);out.mkdir(parents=False,exist_ok=False);(out/"test-mode.json").write_text(json.dumps({"test_mode":True,"n_rows":256,"formal_coverage":False,"levels":3,"faults":checks},indent=2),encoding="utf-8");print(json.dumps({"test_mode":True,"n_rows":256,"levels":3,"faults":checks},indent=2));return 0
 expected_blocks={b["block_id"] for b in design["blocks"]}
 if len(expected_blocks)!=10 or any(int(b["n_rows"])!=10000 for b in design["blocks"]):fail("design 不满足冻结 10×10k 范围")
 if int(design.get("expected_formal_rows",-1))!=420:fail("design 声明的 formal 行数必须为 420")
 if len(rows)!=480:fail(f"历史 E2 CSV 应为 480 行（420 formal+60 warmup），实际 {len(rows)}")
 if design["radius_levels"]!=list(LEVELS) or int(design["repetitions_formal"])!=7 or int(design["warmup_rounds_discarded"])!=1:fail("design formal/warmup 矩阵不符合预期")
 if int(design["quota_floor"])!=5:fail("quota_floor 与冻结契约不一致")
 start=time.perf_counter();derived={};array_hashes={};arrays_dir=out/"synthetic_arrays";arrays_dir.mkdir(parents=True,exist_ok=False)
 for i,b in enumerate(design["blocks"],1):
  print(f"[{i}/10] 独立重建并计算 {b['block_id']}",flush=True);d=derive(b,b["radius_m"],int(design["quota_floor"]),a.distance_chunk);derived[b["block_id"]]=d
  array_path=arrays_dir/(b["block_id"].replace("/","_")+".npz");np.savez_compressed(array_path,xy=d["xy"],labels=d["labels"],keys=d["keys"]);array_hashes[b["block_id"]]=sha256_file(array_path)
 expected_status_rows=status_rows
 comparison=compare_all(design,rows,derived,expected_status_rows);faults=fault_injection(derived);fault_ok=all(x["detected"] for x in faults)
 status_file=None
 for candidate in (rp.parent/"e2_status.csv",rp.parent/"status.csv",rp.parent/"e2_status.json"):
  if candidate.is_file():status_file=candidate;break
 if not fault_ok:fail("故障注入 comparator 未检出全部变异")
 csv_faults=csv_field_fault_injection(rows)
 if not all(x["detected"] for x in csv_faults):fail("真实 CSV 字段故障注入 comparator 未检出全部变异")
 if comparison["status_diffs"]:comparison["diffs"].extend(comparison["status_diffs"])
 historical_status_comparable=status_file is not None
 comparison["status_artifact_note"]=("Historical status artifact found and compared." if historical_status_comparable else "No historical status artifact exists; status note/empty artifact is not claimed as fully verified.")
 comparison["quota_scalar_semantics"]="logical_repeat=0 applies only to timed-row repeat selection; scalar quota_pos/quota_neg summarize CSV res.quota[0] (repeat 0). quota_json contains all five repeats and each pair is independently compared."
 ref={"blocks":{bid:{"radius_checks":d["radius_checks"],"pool_metrics":d["pool_metrics"],"radii":{lv:r["radius"] for lv,r in d["results"].items()},"levels":{lv:{"feasible":r["feasible"],"repeats":[{"quota":list(q["quota"]),"feasible":q["feasible"],"fold_counts":q["fold_counts"]} for q in r["repeats"]],"comparisons":[{k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in c.items()} for c in r["comparisons"]]} for lv,r in d["results"].items()}} for bid,d in derived.items()}}
 (out/"independent_reference.json").write_text(json.dumps(ref,ensure_ascii=False,indent=2),encoding="utf-8")
 (out/"comparison.json").write_text(json.dumps({**comparison,"fault_injection":faults,"csv_field_fault_injection":csv_faults,"historical_payload_comparison":"not possible: historical E2 did not persist matched payloads; dec_bytes/dec_sha256 are retained CSV summaries but cannot be independently re-derived byte-exactly without the original payload and fast_path metadata. Actual ordered IDs are independently reconstructed, not directly compared"},ensure_ascii=False,indent=2),encoding="utf-8")
 elapsed=time.perf_counter()-start
 env={"created_utc":datetime.now(timezone.utc).isoformat(),"python":sys.version,"executable":sys.executable,"platform":platform.platform(),"numpy":np.__version__,"distance_chunk":a.distance_chunk,"elapsed_seconds_including_serialization":elapsed,"distance_algorithm":"exhaustive float64 candidate chunks against every test point; no spatial index or pruning","historical_payload_comparison":"impossible: historical CSV has summaries but no persisted payload/status","inputs":{"design":str(dp),"design_sha256":sha256_file(dp),"rows":str(rp),"rows_sha256":sha256_file(rp)},"verifier":{"path":str(Path(__file__).resolve()),"sha256":sha256_file(Path(__file__).resolve())},"synthetic_array_sha256":array_hashes}
 (out/"environment.json").write_text(json.dumps(env,ensure_ascii=False,indent=2),encoding="utf-8")
 computational_pass=not comparison["diffs"] and fault_ok and all(x["detected"] for x in csv_faults)
 summary={"status":"LIMITED_PASS" if computational_pass else "DIFFS_FOUND","computational_checks_pass":computational_pass,"historical_status_comparable":historical_status_comparable,"historical_ordered_ids_comparable":False,"historical_payload_digest_independently_rederived":False,"all_differences":comparison["diffs"],"difference_count":len(comparison["diffs"]),"matrix":{"expected_rows":comparison["expected_rows"],"observed_rows":comparison["observed_rows"],"formal":comparison["counts"]["formal"],"warmup":comparison["counts"]["warmup"]},"blocks":len(derived),"radii":len(LEVELS),"fault_injection":faults,"csv_field_fault_injection":csv_faults,"elapsed_seconds_including_serialization":elapsed,"output_dir":str(out)}
 (out/"report.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
 files={p.relative_to(out).as_posix():sha256_file(p) for p in out.rglob("*") if p.is_file() and p.name!="SHA256SUMS.json"};(out/"SHA256SUMS.json").write_text(json.dumps(files,indent=2),encoding="utf-8")
 print(json.dumps({k:v for k,v in summary.items() if k!="all_differences"},ensure_ascii=False,indent=2));return 0 if not comparison["diffs"] else 2
if __name__=="__main__":
 try:raise SystemExit(main())
 except (ValueError,KeyError,TypeError,json.JSONDecodeError) as exc:
  print(json.dumps({"status":"INPUT_OR_CONTRACT_ERROR","error":str(exc)},ensure_ascii=False),file=sys.stderr);raise SystemExit(2)
