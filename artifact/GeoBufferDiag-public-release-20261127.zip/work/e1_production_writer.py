# -*- coding: utf-8 -*-
"""E1: production-writer end-to-end timing with a two-arm (plugged /
unplugged) balanced design on three frozen dataset-cities.

Scope (09_修订后收尾方案_20261123.md, E1):
  * inputs and references are READ ONLY from
    ``runs/postreview-bench-20261119-034720-156/{inputs,ref}``;
  * 3 dataset-cities x 2 methods (kd=B1, full=Full) x 2 radius modes
    (single, batch), output=matched, variant=cold -> 12 timed cells;
  * one discarded warm-up round, then 7 recorded repetitions per cell;
  * two arms per cell, adjacent in time and order-balanced per repetition:
      U = uninstrumented (production engine + production streaming writer)
      I = instrumented (same engine source + runtime method hooks)
    payload is ALWAYS written by ``splitbench.writers.write_outputs``
    (streaming gzip); the buffered ``profile.write_payload_split`` writer is
    never used here;
  * correctness (status/quota/ordered arms/payload rows+bytes) is checked
    outside the timed region against the frozen reference npz.

Nothing under ``splitbench/`` is modified: the instrumented arm attaches
timing wrappers to engine *instances* at run time (``sys.dont_write_bytecode``
is set so no .pyc is written either).

Usage:
    python -B work/e1_production_writer.py --run runs/e1-prodwriter-20261123-a
"""
from __future__ import annotations

import argparse
import csv
import ctypes
import functools
import gzip
import hashlib
import json
import os
import platform
import shutil
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np                          # noqa: E402
from threadpoolctl import threadpool_limits  # noqa: E402

from splitbench.baseline_b1 import B1Engine            # noqa: E402
from splitbench.candidate import CandidateEngine       # noqa: E402
from splitbench.prepare import Reference               # noqa: E402
from splitbench.settings import load_config            # noqa: E402
from splitbench.verifylib import load_city_inputs      # noqa: E402
from splitbench.writers import (EngineResult, _payload_lines,  # noqa: E402
                                fmt_radius, write_outputs, write_status)

SRC_RUN_REL = "runs/postreview-bench-20261119-034720-156"
CITIES = [("streetview", "sz"), ("so2sat43", "shenzhen"),
          ("so2sat10", "guangzhou")]
METHODS = [("kd", "B1"), ("full", "Full")]
MODES = ["single", "batch"]
FORMAL_REPS = 7
WARMUP_ROUNDS = 1
MAX_SECONDS = 1200          # timed part; stop early and report what is done
OUTPUT = "matched"
VARIANT = "cold"

HOOKS = {
    "b1": ["_fresh_mask", "_extend_mask"],
    "c": ["_ensure_blocks", "_ensure_mask", "_ensure_dcenter", "_prune",
          "_exact_rows", "_close_quota", "_prove_fold_by_scan",
          "_comparison", "_c2_select", "_scan_buffered", "_scan_class"],
}

COLS = [
    "seq", "round", "rep", "formal", "config_id", "dataset", "city",
    "method", "engine", "mode", "radii", "output", "variant", "arm",
    "arm_order", "order_pos", "utc_start", "utc_end", "feasible", "note",
    "ms_read", "ms_index", "ms_exact", "ms_quota", "ms_select",
    "ms_engine", "ms_payload", "ms_status", "ms_total", "ms_unaccounted",
    "ms_phase_unaccounted", "ms_engine_gap", "ms_payload_prod_dt",
    "rows_out", "gz_bytes", "dec_bytes", "dec_sha256", "exp_rows",
    "exp_bytes", "exp_sha256", "payload_match", "arms_match", "quota_match",
    "status_match", "verify_ok", "verify_detail",
    "n_rows_exact", "n_rows_queried", "counters_json", "hook_json",
    "cpu_busy_pct", "proc_cpu_s", "ts",
]


# ---------------------------------------------------------------- utilities
def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def rel(p: Path) -> str:
    try:
        return str(p.resolve().relative_to(ROOT)).replace("\\", "/")
    except ValueError:
        return str(p).replace("\\", "/")


class SysCpu:
    """Machine-wide busy fraction from GetSystemTimes (no psutil needed)."""

    def __init__(self):
        self.ok = sys.platform == "win32"
        if self.ok:
            class FT(ctypes.Structure):
                _fields_ = [("lo", ctypes.c_uint32), ("hi", ctypes.c_uint32)]

            self._ft = FT
            self._k32 = ctypes.windll.kernel32

    def _read(self):
        idle, kern, user = self._ft(), self._ft(), self._ft()
        if not self._k32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kern),
                                        ctypes.byref(user)):
            return None
        val = lambda f: (f.hi << 32) | f.lo
        return val(idle), val(kern) + val(user)

    def sample(self):
        return self._read()


def busy_pct(a, b):
    if a is None or b is None:
        return ""
    di = b[0] - a[0]
    dt = b[1] - a[1]
    if dt <= 0:
        return ""
    return round(100.0 * (1.0 - di / dt), 2)


# ---------------------------------------------------------------- hooks
def attach_hooks(engine, store):
    """Wrap engine methods with perf_counter; instance-level, source untouched."""
    for name in HOOKS.get(engine.name, []):
        fn = getattr(engine, name, None)
        if fn is None:
            continue

        @functools.wraps(fn)
        def wrapper(*args, __fn=fn, __name=name, **kw):
            t0 = time.perf_counter()
            try:
                return __fn(*args, **kw)
            finally:
                rec = store.setdefault(__name, [0, 0.0])
                rec[0] += 1
                rec[1] += time.perf_counter() - t0

        setattr(engine, name, wrapper)
    return engine


# ---------------------------------------------------------------- payload oracle
def expected_payload(ct, folds, ref, radii):
    """Rebuild the exact production payload text from the frozen reference.

    The reference npz stores, per radius, the ordered unbuffered/buffered ID
    arrays of every (rep, geom, fold) plus the per-repeat budgets -- i.e. the
    same content the streaming writer encodes.  Building the lines through
    ``_payload_lines`` (the single source shared by the production writer)
    lets us compare rows, decompressed bytes and SHA-256 against the
    reference instead of only against the other arm.
    """
    res = EngineResult(dataset=ct.dataset, city=ct.city)
    for r in radii:
        r = float(r)
        st = ref.status(r)
        comps = []
        for rep, geom, fold, up, un, bp, bn in ref.matched(r):
            qp, qn = (int(st["budgets"][rep][0]),
                      int(st["budgets"][rep][1]))
            # fast_path is not stored in the reference; it is exactly the
            # equality of the two arms (both engines set it that way), so it
            # is reconstructed from the ordered arm arrays instead of guessed.
            fast = bool(np.array_equal(np.asarray(up), np.asarray(bp))
                        and np.array_equal(np.asarray(un), np.asarray(bn)))
            comps.append({"rep": int(rep), "geom": int(geom),
                          "fold": int(fold), "quota": (qp, qn),
                          "fast_path": fast,
                          "unbuf_pos": np.asarray(up), "unbuf_neg": np.asarray(un),
                          "buf_pos": np.asarray(bp), "buf_neg": np.asarray(bn)})
        res.matched[r] = comps
    lines = list(_payload_lines(ct, folds, res, OUTPUT))
    text = "".join(lines).encode("utf-8")
    return {"rows": len(lines), "bytes": len(text),
            "sha256": sha256_bytes(text)}


def check_result(ct, folds, ref, res, radii, exp, status_path, payload_path,
                 rows_out):
    """Timing-free correctness: status, quota, ordered arms, payload."""
    detail, ok_status, ok_quota, ok_arms = [], True, True, True
    for r in radii:
        r = float(r)
        st_new, st_ref = res.status.get(r), ref.status(r)
        if st_new is None:
            ok_status = False
            detail.append("r=%g: missing status" % r)
            continue
        if bool(st_new.get("feasible")) != bool(st_ref["feasible"]):
            ok_status = False
            detail.append("r=%g: feasible %s != %s" % (
                r, st_new.get("feasible"), st_ref["feasible"]))
        q_new = res.quota.get(r) or []
        if bool(st_ref["feasible"]):
            want = [tuple(int(v) for v in b) for b in st_ref["budgets"]]
            got = [tuple(int(v) for v in q) for q in q_new]
            if got != want:
                ok_quota = False
                detail.append("r=%g: quota %s != ref %s" % (r, got, want))
        ref_comps = ref.matched(r)
        new_map = {(c["rep"], c["geom"], c["fold"]): c
                   for c in (res.matched.get(r) or [])}
        if len(ref_comps) != len(new_map):
            ok_arms = False
            detail.append("r=%g: %d comps != ref %d"
                          % (r, len(new_map), len(ref_comps)))
        for rep, geom, fold, up, un, bp, bn in ref_comps:
            c = new_map.get((int(rep), int(geom), int(fold)))
            if c is None:
                ok_arms = False
                detail.append("r=%g: comp %s/%s/%s missing"
                              % (r, rep, geom, fold))
                continue
            for name, want in (("unbuf_pos", up), ("unbuf_neg", un),
                               ("buf_pos", bp), ("buf_neg", bn)):
                if not np.array_equal(np.asarray(c[name]), np.asarray(want)):
                    ok_arms = False
                    detail.append("r=%g: %s %s/%s/%s differs"
                                  % (r, name, rep, geom, fold))

    # status file: one row per (radius, repeat), budgets as in the reference
    ok_status_file = True
    try:
        with open(status_path, encoding="utf-8") as fh:
            srows = list(csv.DictReader(fh))
        by_r = {}
        for row in srows:
            by_r.setdefault(float(row["radius"]), []).append(row)
        for r in radii:
            r = float(r)
            st_ref = ref.status(r)
            got = by_r.get(r, [])
            if len(got) != folds.n_repeats:
                ok_status_file = False
                detail.append("status r=%g: %d rows != %d"
                              % (r, len(got), folds.n_repeats))
                continue
            for rep, row in enumerate(sorted(got, key=lambda x: int(x["repeat"]))):
                if st_ref["feasible"]:
                    want = (int(st_ref["budgets"][rep][0]),
                            int(st_ref["budgets"][rep][1]))
                    if (int(row["budget_pos"]), int(row["budget_neg"])) != want:
                        ok_status_file = False
                        detail.append("status r=%g rep=%d: %s/%s != %s/%s" % (
                            r, rep, row["budget_pos"], row["budget_neg"],
                            want[0], want[1]))
                elif row["budget_pos"] != "-1" or row["budget_neg"] != "-1":
                    ok_status_file = False
                    detail.append("status r=%g rep=%d: infeasible not -1" % (r, rep))
    except FileNotFoundError:
        ok_status_file = False
        detail.append("status file missing")

    # payload: decompressed bytes vs the reference-derived text
    with open(payload_path, "rb") as fh:
        raw = gzip.decompress(fh.read())
    dec_sha = sha256_bytes(raw)
    payload_match = (dec_sha == exp["sha256"] and len(raw) == exp["bytes"]
                     and int(rows_out) == exp["rows"])
    if not payload_match:
        detail.append("payload sha=%s rows=%s bytes=%s != ref sha=%s rows=%s "
                      "bytes=%s" % (dec_sha[:12], rows_out, len(raw),
                                    exp["sha256"][:12], exp["rows"],
                                    exp["bytes"]))
    ok = ok_status and ok_quota and ok_arms and ok_status_file and payload_match
    return {
        "status_match": ok_status and ok_status_file, "quota_match": ok_quota,
        "arms_match": ok_arms, "payload_match": payload_match,
        "verify_ok": ok, "detail": "; ".join(detail[:6]),
        "dec_bytes": len(raw), "dec_sha256": dec_sha,
    }


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="runs/e1-prodwriter-20261123-a")
    ap.add_argument("--reps", type=int, default=FORMAL_REPS)
    ap.add_argument("--warmup", type=int, default=WARMUP_ROUNDS)
    ap.add_argument("--max-seconds", type=float, default=MAX_SECONDS)
    ap.add_argument("--only", default=None,
                    help="substring filter on config_id (smoke tests only)")
    args = ap.parse_args()

    run_dir = Path(args.run)
    if not run_dir.is_absolute():
        run_dir = ROOT / run_dir
    if run_dir.exists() and any(run_dir.iterdir()):
        sys.exit("refusing to write into non-empty %s" % run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    tmp_root = run_dir / "tmp"
    tmp_root.mkdir(exist_ok=True)

    src = ROOT / SRC_RUN_REL
    cfg = load_config(ROOT / "configs" / "paper_primary.yaml")
    ec = dict(cfg["engine"])
    side = float(ec["block_grid_side_m"])
    margin = float(ec["block_float_margin_m"])
    batch_rows = int(ec["scan_batch_rows"])
    floor = int(cfg["run"]["quota_floor"])
    threads = int(cfg["run"]["threads"])

    def radii_for(ds, mode):
        if mode == "single":
            return [float(cfg["radii"]["primary"][ds])]
        return [float(r) for r in cfg["radii"]["sweep"]]

    configs = []
    for ds, city in CITIES:
        for mode in MODES:
            for mkey, mlabel in METHODS:
                configs.append({
                    "config_id": "%s/%s/%s/%s" % (ds, city, mkey, mode),
                    "dataset": ds, "city": city, "method": mkey,
                    "method_label": mlabel, "mode": mode,
                    "radii": radii_for(ds, mode),
                })
    if args.only:
        configs = [c for c in configs if args.only in c["config_id"]]
        if not configs:
            sys.exit("--only %r matched no config" % args.only)

    # ---- inputs/reference digests + in-memory tables ----
    input_files = [src / "inputs" / ("%s__%s.npz" % (ds, c)) for ds, c in CITIES]
    ref_files = [src / "ref" / ("%s__%s.npz" % (ds, c)) for ds, c in CITIES]
    hashes = {rel(p): sha256_file(p) for p in input_files + ref_files}

    tables, folds_map, refs, expected = {}, {}, {}, {}
    needed = sorted({(c["dataset"], c["city"]) for c in configs})
    need_modes = sorted({(c["dataset"], c["city"], c["mode"]) for c in configs})
    for ds, city in needed:
        ct, folds = load_city_inputs(src, ds, city)
        tables[(ds, city)], folds_map[(ds, city)] = ct, folds
        refs[(ds, city)] = Reference(src / "ref" / ("%s__%s.npz" % (ds, city)))
        for mode in MODES:
            if (ds, city, mode) in need_modes:
                expected[(ds, city, mode)] = expected_payload(
                    ct, folds, refs[(ds, city)], radii_for(ds, mode))

    # ---- code digests ----
    code_paths = sorted((ROOT / "splitbench").glob("*.py")) + \
        [Path(__file__).resolve(), ROOT / "configs" / "paper_primary.yaml"]
    code_lines = ["%s  %s" % (sha256_file(p), rel(p)) for p in code_paths]
    (run_dir / "code_sha256").write_text("\n".join(code_lines) + "\n",
                                         encoding="utf-8")
    (run_dir / "inputs_sha256").write_text(
        "\n".join("%s  %s" % (v, k) for k, v in sorted(hashes.items())) + "\n",
        encoding="utf-8")

    # ---- environment (reuse the project snapshot tool, then augment) ----
    subprocess.run([sys.executable, "-B", str(ROOT / "work" / "env_snapshot.py"),
                    "--run", str(run_dir)], check=False,
                   cwd=str(ROOT), capture_output=True, text=True)
    env_path = run_dir / "environment.json"
    env = json.loads(env_path.read_text(encoding="utf-8")) if env_path.exists() else {}
    started_utc = utc_now()
    t_start = time.perf_counter()
    env.update({
        "e1_started_utc": started_utc,
        "e1_interpreter": sys.version,
        "e1_executable_relpath_note": "passed as command variable",
        "e1_threads_pinned": threads,
        "e1_threadpool_scope": "threadpool_limits(1) around engine+writer",
        "e1_process_cpu_note": "process_time delta over wall clock, single thread",
        "e1_machine_load_sampler": ("GetSystemTimes machine-wide idle/total "
                                    "delta per row" if sys.platform == "win32"
                                    else "unavailable"),
        "e1_psutil": "not installed in this interpreter; not used",
        "e1_platform": platform.platform(),
        "e1_cpu_count": os.cpu_count(),
    })
    env_path.write_text(json.dumps(env, indent=1, ensure_ascii=False),
                        encoding="utf-8")

    design = {
        "run_id": run_dir.name,
        "created_utc": started_utc,
        "plan": "09_修订后收尾方案_20261123.md E1",
        "source_run": SRC_RUN_REL,
        "source_run_read_only": True,
        "cities": [{"dataset": d, "city": c} for d, c in CITIES],
        "config_count": len(configs),
        "config_count_user_message": 8,
        "config_count_note": (
            "The message's '8' (2 methods x 2 modes x matched x cold) cannot "
            "cover the three fixed dataset-cities; streetview/sz and "
            "so2sat43/shenzhen are the same city but different input "
            "snapshots (different manifests, point sets, label rules) and are "
            "kept as separate cells. Executed matrix: 3 dataset-cities x 2 "
            "methods x 2 modes = 12 cells, matching the plan's cold-only "
            "12-configuration matrix with 84 formal rows per arm."),
        "configs": configs,
        "repetitions_formal": args.reps,
        "warmup_rounds_discarded": args.warmup,
        "output": OUTPUT,
        "variant": VARIANT,
        "arms": {
            "U": "uninstrumented: production engine + production streaming writer",
            "I": "instrumented: same engine source + runtime perf_counter "
                 "method hooks; payload still write_outputs",
        },
        "arm_order_rule": ("within each config, arms run back-to-back; the "
                           "order is (config_index + rep) % 2 -> U first for "
                           "even, I first for odd; flips every repetition so "
                           "no arm runs as a block"),
        "timing_boundaries": [
            "read: load_city_inputs() of the frozen npz, cold, per row",
            "engine: engine.run_city() incl. index build, distance queries, "
            "quota, selection",
            "payload: splitbench.writers.write_outputs() streaming gzip, "
            "compresslevel=6",
            "status: splitbench.writers.write_status() csv write",
            "total: perf_counter from before read to after status write",
            "per-phase engine split (index/exact/quota/select) recorded only "
            "on the instrumented arm from res.phases",
        ],
        "threads": threads,
        "quota_floor": floor,
        "engine_params": {"block_grid_side_m": side,
                          "block_float_margin_m": margin,
                          "scan_batch_rows": batch_rows},
        "budget": {"max_seconds_timed_part": args.max_seconds,
                   "policy": "stop before next row when exceeded; completed "
                             "rows kept and reported as-is"},
        "expected_payload_reference": {
            "%s/%s/%s" % k: v for k, v in expected.items()},
        "code_sha256": {rel(p): sha256_file(p) for p in code_paths},
        "inputs_ref_sha256": hashes,
        "no_modification": ("splitbench/*.py untouched (hashes in "
                            "code_sha256); source run only read"),
    }
    (run_dir / "design.json").write_text(
        json.dumps(design, indent=1, ensure_ascii=False), encoding="utf-8")

    rows_path = run_dir / "e1_rows.csv"
    fh = open(rows_path, "w", newline="", encoding="utf-8")
    writer = csv.DictWriter(fh, fieldnames=COLS)
    writer.writeheader()
    fh.flush()

    cpu = SysCpu()
    state = {"seq": 0, "aborted": False, "abort_reason": ""}

    def one_row(cfgd, rep, formal, arm, order_pos, arm_order):
        ds, city, mode = cfgd["dataset"], cfgd["city"], cfgd["mode"]
        radii = cfgd["radii"]
        seq = state["seq"] = state["seq"] + 1
        row_dir = tmp_root / ("seq%05d" % seq)
        ct, folds = tables[(ds, city)], folds_map[(ds, city)]
        cpu0, proc0 = cpu.sample(), time.process_time()
        utc0 = utc_now()
        t_row = time.perf_counter()

        t = time.perf_counter()
        ct_c, folds_c = load_city_inputs(src, ds, city)   # cold read
        ms_read = (time.perf_counter() - t) * 1000.0

        hook_store = {}
        with threadpool_limits(limits=threads):
            eng = (B1Engine() if cfgd["method"] == "kd" else
                   CandidateEngine(arm="c", side=side, margin=margin,
                                   batch_rows=batch_rows, policy="priority"))
            if arm == "I":
                attach_hooks(eng, hook_store)
            t = time.perf_counter()
            res, _st = eng.run_city(ct_c, folds_c, radii, OUTPUT,
                                    state=None, floor=floor)
            ms_engine = (time.perf_counter() - t) * 1000.0
            t = time.perf_counter()
            rows_out, gz_bytes, prod_dt = write_outputs(
                row_dir, eng.name, ct_c, folds_c, res, OUTPUT)
            ms_payload = (time.perf_counter() - t) * 1000.0
            t = time.perf_counter()
            status_path, _n_status = write_status(
                row_dir, eng.name, ct_c, folds_c, res, radii, OUTPUT)
            ms_status = (time.perf_counter() - t) * 1000.0

        ms_total = (time.perf_counter() - t_row) * 1000.0
        proc_cpu = time.process_time() - proc0
        cpu1 = cpu.sample()

        payload_path = row_dir / "out" / eng.name / (
            "%s__%s__%s.csv.gz" % (ds, city, OUTPUT))
        v = check_result(ct_c, folds_c, refs[(ds, city)], res, radii,
                         expected[(ds, city, mode)], status_path, payload_path,
                         rows_out)
        shutil.rmtree(row_dir, ignore_errors=True)

        ph = res.phases
        feas = all(bool(res.status[r].get("feasible")) for r in radii)
        note = "" if feas else ";".join(
            "%s:%s" % (fmt_radius(r), res.status[r].get("note"))
            for r in radii if not res.status[r].get("feasible"))
        if arm == "I":
            ms_index = ph.index * 1000.0
            ms_exact = ph.exact * 1000.0
            ms_quota = ph.quota * 1000.0
            ms_select = ph.select * 1000.0
            ms_engine_gap = ms_engine - (ms_index + ms_exact + ms_quota
                                         + ms_select)
            ms_phase_unacc = ms_total - (ms_read + ms_index + ms_exact
                                         + ms_quota + ms_select
                                         + ms_payload + ms_status)
        else:
            ms_index = ms_exact = ms_quota = ms_select = ""
            ms_engine_gap = ms_phase_unacc = ""
        row = {
            "seq": seq, "round": ("warmup" if not formal else rep),
            "rep": rep, "formal": int(formal),
            "config_id": cfgd["config_id"], "dataset": ds, "city": city,
            "method": cfgd["method"], "engine": eng.name, "mode": mode,
            "radii": "|".join(fmt_radius(r) for r in radii),
            "output": OUTPUT, "variant": VARIANT, "arm": arm,
            "arm_order": arm_order, "order_pos": order_pos,
            "utc_start": utc0, "utc_end": utc_now(),
            "feasible": str(feas), "note": note,
            "ms_read": round(ms_read, 3),
            "ms_index": ("" if ms_index == "" else round(ms_index, 3)),
            "ms_exact": ("" if ms_exact == "" else round(ms_exact, 3)),
            "ms_quota": ("" if ms_quota == "" else round(ms_quota, 3)),
            "ms_select": ("" if ms_select == "" else round(ms_select, 3)),
            "ms_engine": round(ms_engine, 3), "ms_payload": round(ms_payload, 3),
            "ms_status": round(ms_status, 3), "ms_total": round(ms_total, 3),
            "ms_unaccounted": round(ms_total - (ms_read + ms_engine
                                                + ms_payload + ms_status), 3),
            "ms_phase_unaccounted": ("" if ms_phase_unacc == ""
                                     else round(ms_phase_unacc, 3)),
            "ms_engine_gap": ("" if ms_engine_gap == ""
                              else round(ms_engine_gap, 3)),
            "ms_payload_prod_dt": round(prod_dt * 1000.0, 3),
            "rows_out": rows_out, "gz_bytes": gz_bytes,
            "dec_bytes": v["dec_bytes"], "dec_sha256": v["dec_sha256"],
            "exp_rows": expected[(ds, city, mode)]["rows"],
            "exp_bytes": expected[(ds, city, mode)]["bytes"],
            "exp_sha256": expected[(ds, city, mode)]["sha256"],
            "payload_match": str(v["payload_match"]),
            "arms_match": str(v["arms_match"]),
            "quota_match": str(v["quota_match"]),
            "status_match": str(v["status_match"]),
            "verify_ok": str(v["verify_ok"]),
            "verify_detail": v["detail"],
            "n_rows_exact": res.counters.get("n_rows_exact", ""),
            "n_rows_queried": res.counters.get("n_rows_queried", ""),
            "counters_json": json.dumps(res.counters, sort_keys=True),
            "hook_json": json.dumps({k: [v2[0], round(v2[1] * 1000.0, 3)]
                                     for k, v2 in hook_store.items()}),
            "cpu_busy_pct": busy_pct(cpu0, cpu1),
            "proc_cpu_s": round(proc_cpu, 3),
            "ts": utc_now(),
        }
        writer.writerow(row)
        fh.flush()
        print("  [%3d] %-42s %s %5.1fs  total=%9.1fms payload=%8.1fms "
              "ok=%s" % (seq, cfgd["config_id"], arm, ms_total / 1000.0,
                         ms_total, ms_payload, v["verify_ok"]), flush=True)
        return row

    elapsed_limit = args.max_seconds
    total_rounds = args.warmup + args.reps
    for rnd in range(total_rounds):
        formal = rnd >= args.warmup
        rep = rnd - args.warmup + 1 if formal else 0
        print("== round %d/%d (%s)" % (rnd + 1, total_rounds,
                                       "rep %d" % rep if formal else "warmup"),
              flush=True)
        for ci, cfgd in enumerate(configs):
            if time.perf_counter() - t_start > elapsed_limit:
                state["aborted"] = True
                state["abort_reason"] = ("time budget %.0fs exceeded before "
                                         "round %d config %s"
                                         % (elapsed_limit, rnd + 1,
                                            cfgd["config_id"]))
                print("  STOP: " + state["abort_reason"], flush=True)
                break
            u_first = (ci + rep) % 2 == 0
            order = ["U", "I"] if u_first else ["I", "U"]
            for pos, arm in enumerate(order):
                one_row(cfgd, rep, formal, arm, pos + 1,
                        ">".join(order))
        if state["aborted"]:
            break
    fh.close()
    ended_utc = utc_now()
    wall = time.perf_counter() - t_start

    # ---------------------------------------------------------------- summary
    rows = list(csv.DictReader(open(rows_path, encoding="utf-8")))
    formal_rows = [r for r in rows if r["formal"] == "1"]
    by_cfg = {}
    for r in formal_rows:
        by_cfg.setdefault(r["config_id"], {"U": [], "I": []})[r["arm"]].append(r)

    def med(rs, key):
        vals = [float(x[key]) for x in rs if x.get(key) not in ("", None)]
        return statistics.median(vals) if vals else ""

    def spread(rs, key):
        vals = sorted(float(x[key]) for x in rs if x.get(key) not in ("", None))
        if not vals:
            return "", "", "", "", ""
        md = statistics.median(vals)
        iqr = (float(np.percentile(vals, 75)) - float(np.percentile(vals, 25)))
        sd = statistics.pstdev(vals) if len(vals) > 1 else 0.0
        return (round(md, 3), round(min(vals), 3), round(max(vals), 3),
                round(iqr, 3), round(sd / md * 100.0, 2) if md else "")

    sum_cols = [
        "config_id", "dataset", "city", "method", "engine", "mode", "radii",
        "n_U", "n_I", "n_fail_U", "n_fail_I",
        "U_med_total", "U_min_total", "U_max_total", "U_iqr_total", "U_cv_pct",
        "I_med_total", "I_min_total", "I_max_total", "I_iqr_total", "I_cv_pct",
        "I_over_U_total_ratio",
        "U_med_payload", "U_med_status", "U_med_read",
        "I_med_payload", "I_med_status", "I_med_read",
        "U_payload_share_pct", "I_payload_share_pct",
        "I_med_index", "I_med_exact", "I_med_quota", "I_med_select",
        "I_med_phase_unaccounted", "I_med_engine_gap",
        "I_med_payload_overhead_pct", "I_med_status_overhead_pct",
        "n_payload_mismatch", "n_verify_fail",
    ]
    summary_path = run_dir / "e1_summary.csv"
    with open(summary_path, "w", newline="", encoding="utf-8") as sfh:
        w = csv.DictWriter(sfh, fieldnames=sum_cols)
        w.writeheader()
        for cfgd in configs:
            cid = cfgd["config_id"]
            grp = by_cfg.get(cid, {"U": [], "I": []})
            u, i = grp["U"], grp["I"]
            out = {"config_id": cid, "dataset": cfgd["dataset"],
                   "city": cfgd["city"], "method": cfgd["method"],
                   "engine": (u or i)[0]["engine"] if (u or i) else "",
                   "mode": cfgd["mode"],
                   "radii": "|".join(fmt_radius(r) for r in cfgd["radii"]),
                   "n_U": len(u), "n_I": len(i),
                   "n_fail_U": sum(1 for x in u if x["verify_ok"] == "False"),
                   "n_fail_I": sum(1 for x in i if x["verify_ok"] == "False"),
                   "n_payload_mismatch": sum(
                       1 for x in u + i if x["payload_match"] == "False"),
                   "n_verify_fail": sum(
                       1 for x in u + i if x["verify_ok"] == "False")}
            for tag, grp2 in (("U", u), ("I", i)):
                md, mn, mx, iqr, cv = spread(grp2, "ms_total")
                out["%s_med_total" % tag] = md
                out["%s_min_total" % tag] = mn
                out["%s_max_total" % tag] = mx
                out["%s_iqr_total" % tag] = iqr
                out["%s_cv_pct" % tag] = cv
            out["U_med_payload"] = med(u, "ms_payload")
            out["U_med_status"] = med(u, "ms_status")
            out["U_med_read"] = med(u, "ms_read")
            out["I_med_payload"] = med(i, "ms_payload")
            out["I_med_status"] = med(i, "ms_status")
            out["I_med_read"] = med(i, "ms_read")
            if u and i and out["U_med_total"] and out["I_med_total"]:
                out["I_over_U_total_ratio"] = round(
                    out["I_med_total"] / out["U_med_total"], 4)
                if out["U_med_payload"] and out["I_med_payload"]:
                    out["I_med_payload_overhead_pct"] = round(
                        (out["I_med_payload"] / out["U_med_payload"] - 1) * 100, 3)
                if out["U_med_status"] and out["I_med_status"]:
                    out["I_med_status_overhead_pct"] = round(
                        (out["I_med_status"] / out["U_med_status"] - 1) * 100, 3)
            for tag, grp2 in (("U", u), ("I", i)):
                if grp2 and out["%s_med_total" % tag]:
                    out["%s_payload_share_pct" % tag] = round(
                        med(grp2, "ms_payload") / out["%s_med_total" % tag] * 100,
                        2)
            for key, col in (("I_med_index", "ms_index"),
                             ("I_med_exact", "ms_exact"),
                             ("I_med_quota", "ms_quota"),
                             ("I_med_select", "ms_select"),
                             ("I_med_phase_unaccounted", "ms_phase_unaccounted"),
                             ("I_med_engine_gap", "ms_engine_gap")):
                out[key] = med(i, col)
            w.writerow(out)

    summary = list(csv.DictReader(open(summary_path, encoding="utf-8")))

    # hook aggregates over instrumented formal rows
    hook_agg = {}
    for r in formal_rows:
        if r["arm"] != "I" or not r["hook_json"]:
            continue
        cid = r["config_id"]
        for name, (calls, ms) in json.loads(r["hook_json"]).items():
            d = hook_agg.setdefault(cid, {}).setdefault(name, [0, []])
            d[0] += int(calls)
            d[1].append(float(ms))

    # ---------------------------------------------------------------- report
    n_config_done = sum(1 for s in summary if int(s["n_U"]) == args.reps
                        and int(s["n_I"]) == args.reps)
    ratios = [float(s["I_over_U_total_ratio"]) for s in summary
              if s["I_over_U_total_ratio"]]
    u_tot = [float(s["U_med_total"]) for s in summary if s["U_med_total"]]
    i_tot = [float(s["I_med_total"]) for s in summary if s["I_med_total"]]
    failures = [r for r in rows if r["verify_ok"] == "False"]
    payload_bad = [r for r in rows if r["payload_match"] == "False"]
    unacc = [float(r["ms_phase_unaccounted"]) for r in formal_rows
             if r["ms_phase_unaccounted"] not in ("", None)]
    unacc_pct = []
    for r in formal_rows:
        if r["ms_phase_unaccounted"] in ("", None):
            continue
        unacc_pct.append(float(r["ms_phase_unaccounted"])
                         / float(r["ms_total"]) * 100.0)

    L = []
    A = L.append
    A("# E1 生产 writer 端到端与分项复核（%s）" % run_dir.name)
    A("")
    A("方案：`09_修订后收尾方案_20261123.md` §3 E1。输入与参考只读取自 "
      "`%s`（未写入该 run）。" % SRC_RUN_REL)
    A("")
    A("## 1. 配置口径与实际完成")
    A("")
    A("| 项目 | 值 |")
    A("|---|---|")
    A("| 配置矩阵 | 3 数据集-城市 × 2 方法（B1/Full）× 2 模式（single/batch），"
      "output=matched、variant=cold |")
    A("| 配置数 | %d（设计 12；用户消息中的 8 无法覆盖三城，理由见 §7） |"
      % len(configs))
    A("| 每配置正式重复 | %d；另有 1 轮丢弃预热 |" % args.reps)
    A("| 完成配置数（两臂各满 %d 条） | %d / %d |"
      % (args.reps, n_config_done, len(configs)))
    A("| 计时行（含预热） | %d |" % len(rows))
    A("| 正式记录 | %d（U=%d，I=%d） |"
      % (len(formal_rows),
         sum(1 for r in formal_rows if r["arm"] == "U"),
         sum(1 for r in formal_rows if r["arm"] == "I")))
    A("| 使用时间 | %s → %s（UTC），wall %.1f s |"
      % (started_utc, ended_utc, wall))
    A("| 线程 | threadpoolctl limits=%d，围绕 engine+writer |" % threads)
    A("| 解释器 | %s |" % sys.version.split()[0])
    A("")
    A("两臂：**U** 未插桩（生产引擎 + 生产流式 writer），**I** 插桩（同一引擎"
      "源码，运行时给实例方法加 `perf_counter` 钩子，payload 仍由 "
      "`write_outputs` 流式 gzip 写出）。同一配置内两臂相邻执行，顺序按 "
      "`(config_index + rep) % 2` 交替（U 先 / I 先），每条记录 `seq` 为全局"
      "执行序号，`order_pos` 为配置内位置。")
    A("")
    A("## 2. 计时边界与不可分项")
    A("")
    A("- `read`：`load_city_inputs()` 冷读冻结 npz；`engine`：`run_city()`；"
      "`payload`：`write_outputs()`（流式 gzip，compresslevel=6）；`status`："
      "`write_status()`；`total`：读入前到 status 写完。")
    A("- 仅插桩臂记录 `res.phases`（index/exact/quota/select），并记录钩子的"
      "inclusive 调用时间（钩子嵌套，不能与 phase 相加）。")
    A("- 未插桩臂**不记录**引擎内部分项：只有 read/payload/status/total 及"
      "两臂共有的行数、字节与校验结果，因此其分项不可分，不做推断。")
    A("- 结构上不可分/不可归因的部分：Full 的精确距离查询发生在 quota 与 "
      "select 内部，无法从 phase 中单独剥离；index 含网格/块与块中心查询；"
      "payload 的计时包含 gzip 压缩与文件落盘；status 与 payload 的 fsync "
      "行为受 OS 缓存影响。")
    A("")
    A("## 3. 每配置中位数（ms）")
    A("")
    A("| 配置 | U total 中位 [min,max] | I total 中位 [min,max] | I/U | "
      "U payload 占比 | I payload 占比 |")
    A("|---|---|---|---|---|---|")
    for s in summary:
        A("| %s | %s [%s, %s] | %s [%s, %s] | %s | %s%% | %s%% |" % (
            s["config_id"], s["U_med_total"], s["U_min_total"], s["U_max_total"],
            s["I_med_total"], s["I_min_total"], s["I_max_total"],
            s["I_over_U_total_ratio"], s["U_payload_share_pct"],
            s["I_payload_share_pct"]))
    A("")
    if u_tot:
        A("- 未插桩臂 %d 配置中位 total 合计 %.1f ms；插桩臂 %.1f ms。"
          % (len(u_tot), sum(u_tot), sum(i_tot)))
    if ratios:
        A("- 插桩/未插桩总时间比：中位 %.4f，范围 %.4f–%.4f。"
          % (statistics.median(ratios), min(ratios), max(ratios)))
    pay = [(float(s["I_med_payload"]) / float(s["U_med_payload"]) - 1) * 100
           for s in summary
           if s["I_med_payload"] and s["U_med_payload"]]
    stat_rt = [(float(s["I_med_status"]) / float(s["U_med_status"]) - 1) * 100
               for s in summary
               if s["I_med_status"] and s["U_med_status"]]
    if pay:
        A("- 同一生产 writer 在两臂下的 payload 中位差：中位 %+.2f%%，范围 "
          "%+.2f%%–%+.2f%%（应为噪声级别；差异大说明磁盘/写回波动）。"
          % (statistics.median(pay), min(pay), max(pay)))
    if stat_rt:
        A("- status 写出中位差：中位 %+.2f%%，范围 %+.2f%%–%+.2f%%。"
          % (statistics.median(stat_rt), min(stat_rt), max(stat_rt)))
    A("")
    A("## 4. 插桩臂分项（中位数，ms）")
    A("")
    A("| 配置 | read | index | exact | quota | select | payload | status | "
      "total | 未归因 | 引擎内间隙 |")
    A("|---|---|---|---|---|---|---|---|---|---|---|")
    for s in summary:
        A("| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
            s["config_id"], s["U_med_read"], s["I_med_index"], s["I_med_exact"],
            s["I_med_quota"], s["I_med_select"], s["I_med_payload"],
            s["I_med_status"], s["I_med_total"], s["I_med_phase_unaccounted"],
            s["I_med_engine_gap"]))
    A("")
    if unacc_pct:
        A("- 相位差（total − read − index − exact − quota − select − payload "
          "− status）中位 %.1f ms，占 total 中位 %.1f%%；超过 10%% 的记录 %d/%d，"
          "最大 %.1f%%。"
          % (statistics.median(unacc), statistics.median(unacc_pct),
             sum(1 for x in unacc_pct if x > 10), len(unacc_pct),
             max(unacc_pct)))
    A("")
    A("## 5. 钩子调用（插桩臂，inclusive）")
    A("")
    A("钩子互相嵌套（`_close_quota` ⊃ `_prove_fold_by_scan` ⊃ `_scan_class` "
      "⊃ `_exact_rows`），下表只用于说明调用分布，不能相加。")
    A("")
    for cid in [c["config_id"] for c in configs]:
        if cid not in hook_agg:
            continue
        parts = ["`%s` n=%d 中位 %.1f ms" % (n, c, statistics.median(v))
                 for n, (c, v) in sorted(hook_agg[cid].items())]
        A("- %s：%s" % (cid, "；".join(parts)))
    A("")
    A("## 6. 正确性（计时外）")
    A("")
    A("- 逐行核对：状态/可行性、每 repeat quota、有序双臂序列（unbuf/buf 的 "
      "pos/neg）、status CSV 预算、解压 payload 的行数与字节 SHA-256。")
    A("- 参考提供有序臂 ID 数组与预算；payload 由 `_payload_lines`（生产 writer "
      "的唯一行源）从参考重建，因此字节比对检查的是参考内容 + 生产编码，而不是"
      "与另一臂互比。")
    A("- 失败/不一致：**%d** 条（payload 不一致 %d 条）。失败即失败，未剔除。"
      % (len(failures), len(payload_bad)))
    for r in failures[:20]:
        A("  - seq %s %s %s：%s" % (r["seq"], r["config_id"], r["arm"],
                                    r["verify_detail"] or "verify_ok=False"))
    A("")
    A("## 7. 口径差异说明（12 vs 8）")
    A("")
    A("方案原文 E1 为 12 配置（3 城 × 2 方法 × 2 模式，matched+cold，每臂 84 "
      "条）；用户消息要求 8。`streetview/sz` 与 `so2sat43/shenzhen` 是同一城市"
      "的两套不同输入快照（不同 manifest、点数、标签规则），在冻结套件中作为"
      "两个数据集-城市单元；去掉任一城会改变冻结套件，且 2×2 无法在保留三城时"
      "得到 8。故按 12 单元执行，并在 `design.json` 中记录该差异。")
    A("")
    A("## 8. 环境与限制")
    A("")
    A("- 同机串行；未启动其他计时/训练任务。CPU 负载用 `GetSystemTimes` 逐行"
      "采样（本解释器无 psutil），另记进程 CPU 时间。")
    if formal_rows:
        busy = [float(r["cpu_busy_pct"]) for r in formal_rows
                if r["cpu_busy_pct"] not in ("", None)]
        if busy:
            A("- 逐行机器 CPU 占用：中位 %.1f%%，范围 %.1f%%–%.1f%%；该机器为共享"
              "环境，不能声称无外部干扰。" % (statistics.median(busy),
                                              min(busy), max(busy)))
    A("- 七次重复是固定预算，不构成显著性保证；高波动只作为环境提示，不扩样、"
      "不剔除。")
    A("- 本轮 payload 占比为生产流式 writer 口径；历史缓冲 writer 的占比不可"
      "用于本轮。")
    A("")
    if state["aborted"]:
        A("## 9. 未完成项")
        A("")
        A("- 提前停止：%s。已完成记录保留在上表与 `e1_rows.csv`。"
          % state["abort_reason"])
    else:
        A("## 9. 未完成项")
        A("")
        A("- 无（%d/%d 配置、两臂各 %d 条正式记录全部完成）。"
          % (n_config_done, len(configs), args.reps))
    A("")
    (run_dir / "e1_report.md").write_text("\n".join(L) + "\n", encoding="utf-8")

    env = json.loads(env_path.read_text(encoding="utf-8"))
    env.update({"e1_ended_utc": ended_utc, "e1_wall_seconds": round(wall, 2),
                "e1_rows_total": len(rows),
                "e1_rows_formal": len(formal_rows),
                "e1_aborted": state["aborted"],
                "e1_abort_reason": state["abort_reason"]})
    env_path.write_text(json.dumps(env, indent=1, ensure_ascii=False),
                        encoding="utf-8")
    shutil.rmtree(tmp_root, ignore_errors=True)
    print("done: %s (formal rows=%d, failures=%d)"
          % (run_dir, len(formal_rows), len(failures)), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
