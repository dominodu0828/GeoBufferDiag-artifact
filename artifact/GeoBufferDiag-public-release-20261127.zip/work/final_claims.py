# -*- coding: utf-8 -*-
"""Final claim table (plan 09 sec. 2, P0-A item 2/3).

Every row states: claim id, paper location, run, source file (with SHA-256),
the exact filter, the per-record formula, the aggregation order, the
denominator/unit, the recomputed value, the status, and the limitation that
must travel with the number.

Status values
  recomputed        value recomputed here from the raw file named in the row
  new_run           value from a run produced in this closeout (E1/E2)
  audited_report    value not recomputed in this pass; taken from the named
                    report/report file whose SHA-256 is recorded, listed so
                    the gap is explicit rather than implied
  withdrawn         claim removed from the manuscript (recorded for audit)

Usage:
    python -B work/final_20261123/final_claims.py --root . \
        --out work/final_20261123/final_claims_20261123.csv
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics as st
from pathlib import Path

PRIMARY = "postreview-bench-20261119-034720-156"
D4 = "postreview-d4-20261122-004931-873"
WRITER = "review-gateb-writer-20261122-231652-1b2ddb"
LARGE = "gated-followup-20261123-0915-a"
E1 = "e1-prodwriter-20261123-b"
E2 = "e2-radius-20261123-a"

ORDER = [("streetview", "sy"), ("streetview", "sz"),
         ("so2sat10", "guangzhou"), ("so2sat10", "moscow"),
         ("so2sat43", "shenzhen"), ("so2sat43", "hongkong")]
ORDER_D4 = [("streetview", "dl"), ("streetview", "gz"),
            ("so2sat10", "nairobi"), ("so2sat10", "munich"),
            ("so2sat43", "vancouver"), ("so2sat43", "amsterdam")]
LABEL = {("streetview", "sy"): "sy", ("streetview", "sz"): "sz",
         ("so2sat10", "guangzhou"): "guangzhou",
         ("so2sat10", "moscow"): "moscow",
         ("so2sat43", "shenzhen"): "shenzhen",
         ("so2sat43", "hongkong"): "hongkong"}

ROWS = []


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load(root: Path, run: str, name: str = "bench.csv"):
    """Read a raw record file.

    Two layouts are accepted: ``<root>/runs/<run>/<name>`` (the project tree)
    and ``<root>/records/<run>/<name>`` (the released candidate package, where
    raw records are grouped under ``records/``).  Nothing else is searched, so
    a missing file is a hard error rather than a silent empty read.
    """
    for sub in ("runs", "records"):
        p = root / sub / run / name
        if p.exists():
            with open(p, encoding="utf-8") as fh:
                return (list(csv.DictReader(fh)), sha256(p),
                        str(p.relative_to(root)).replace("\\", "/"))
    raise SystemExit("missing raw record file: %s or %s"
                     % (root / "runs" / run / name,
                        root / "records" / run / name))


def add(cid, loc, run, src, flt, formula, agg, unit, value, status="recomputed",
        limit="", note=""):
    ROWS.append({"claim_id": cid, "paper_location": loc, "run_id": run,
                 "source_file": src, "source_sha256": SHA.get(src, ""),
                 "filter": flt, "formula": formula, "aggregation": agg,
                 "unit": unit, "value": value, "status": status,
                 "limitation": limit, "note": note})


def med_series(rows, ds, city, method, mode, output, variant):
    vals = [float(r["ms_total"]) for r in rows
            if r["dataset"] == ds and r["city"] == city
            and r["method"] == method and r["mode"] == mode
            and r["output"] == output and r["variant"] == variant
            and r["rep"] not in ("warmup", "")
            and r["ms_total"] not in ("", None)]
    return vals


def med(rows, *key):
    v = med_series(rows, *key)
    return st.median(v) if v else None


def counter_sum(rows, key, method, mode, output="matched", variant="cold"):
    tot, seen = 0, 0
    for ds, city in ORDER:
        vals = [int(float(r[key])) for r in rows
                if r["dataset"] == ds and r["city"] == city
                and r["method"] == method and r["mode"] == mode
                and r["output"] == output and r["variant"] == variant
                and r["rep"] == "1" and r.get(key) not in ("", None)]
        if vals:
            tot += vals[0]
            seen += 1
    return tot, seen


SHA = {}


def _first(root: Path, run: str, name: str) -> Path:
    for sub in ("runs", "records"):
        p = root / sub / run / name
        if p.exists():
            return p
    return root / "runs" / run / name


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--out", type=Path,
                    default=Path("work/final_20261123/final_claims_20261123.csv"))
    a = ap.parse_args()
    root = a.root.resolve()

    prim, s1, p1 = load(root, PRIMARY)
    SHA[p1] = s1
    d4, s2, p2 = load(root, D4)
    SHA[p2] = s2
    wr = _first(root, WRITER, "profile_writer_checks.jsonl")
    if wr.exists():
        SHA[str(wr.relative_to(root)).replace("\\", "/")] = sha256(wr)

    LIM_REPS = ("5 interleaved recorded repetitions per configuration; medians "
                "and observed ranges describe repetition spread, not "
                "confidence intervals")
    LIM_LOCAL = "single local machine; no cross-machine or population claim"

    # ---- C01-C06: primary single-radius table -------------------------------
    for i, (ds, city) in enumerate(ORDER, 1):
        b1 = med(prim, ds, city, "b1", "single", "matched", "cold")
        b1b = med(prim, ds, city, "b1b", "single", "matched", "cold")
        c1 = med(prim, ds, city, "c1", "single", "matched", "cold")
        c2 = med(prim, ds, city, "c2", "single", "matched", "cold")
        cf = med(prim, ds, city, "c", "single", "matched", "cold")
        best = min(b1, b1b)
        add("C%02d" % i, "Table tab:runtime / %s" % LABEL[(ds, city)], PRIMARY,
            p1, "dataset=%s,city=%s,mode=single,output=matched,variant=cold,"
                "rep in 1..5" % (ds, city),
            "median(ms_total) per method; ratio = median(Full)/min(median(B1),"
            "median(B1b))",
            "per-workload median over 5 reps; best-KD chosen per workload; canonical city identity is separate", "ms / ratio",
            "B1=%.1f;B1b=%.1f;C1=%.1f;C2=%.1f;Full=%.1f;bestKD=%.1f;ratio=%.4f"
            % (b1, b1b, c1, c2, cf, best, cf / best), limit=LIM_REPS)

    ratio_by_workload = {}
    for ds, city in ORDER:
        b1 = med(prim, ds, city, "b1", "single", "matched", "cold")
        b1b = med(prim, ds, city, "b1b", "single", "matched", "cold")
        cf = med(prim, ds, city, "c", "single", "matched", "cold")
        ratio_by_workload[(ds, city)] = cf / min(b1, b1b)
    ratios = list(ratio_by_workload.values())
    add("C07", "Abstract; Results 5.1; Conclusion", PRIMARY, p1,
        "6 primary workloads, single radius, cold, matched, reps 1..5",
        "min/max over workloads of median(Full)/min(median(B1),median(B1b))",
        "ratio per workload, then min/max across workloads", "ratio",
        "%.4f-%.4f (n=%d workloads)" % (min(ratios), max(ratios), len(ratios)),
        limit=LIM_REPS)

    # ---- C07b: canonical-city grouping sensitivity -------------------------
    # The suite is workload-equal-weight; Shenzhen and Guangzhou each appear
    # twice once the alias registry is applied.  Re-aggregate the same
    # per-workload ratios by canonical city (within-city median first, then
    # median across cities) and report the shift.  No raw timings are pooled
    # across workloads.
    CANON = {("streetview", "sy"): "Shenyang",
             ("streetview", "sz"): "Shenzhen",
             ("so2sat10", "guangzhou"): "Guangzhou",
             ("so2sat10", "moscow"): "Moscow",
             ("so2sat43", "shenzhen"): "Shenzhen",
             ("so2sat43", "hongkong"): "Hong Kong"}

    def city_median(by_wl):
        groups = {}
        for (ds, city), v in by_wl.items():
            groups.setdefault(CANON.get((ds, city), "%s/%s" % (ds, city)),
                              []).append(v)
        per_city = {c: st.median(v) for c, v in groups.items()}
        return st.median(per_city.values()), len(groups), per_city

    cov_by_wl = {}
    for ds, city in ORDER_D4:
        b1 = med(d4, ds, city, "b1", "single", "matched", "cold")
        b1b = med(d4, ds, city, "b1b", "single", "matched", "cold")
        cf = med(d4, ds, city, "c", "single", "matched", "cold")
        if b1 and cf:
            cov_by_wl[(ds, city)] = cf / min(b1, b1b)
    # coverage city identities (all distinct except Guangzhou, which is only
    # shared across suites, not inside this one)
    COV_CANON = {("streetview", "dl"): "Dalian",
                 ("streetview", "gz"): "Guangzhou",
                 ("so2sat10", "nairobi"): "Nairobi",
                 ("so2sat10", "munich"): "Munich",
                 ("so2sat43", "vancouver"): "Vancouver",
                 ("so2sat43", "amsterdam"): "Amsterdam"}
    for key in list(cov_by_wl):
        CANON.setdefault(key, COV_CANON.get(key, "%s/%s" % key))

    prim_wl = st.median(ratios)
    prim_city, prim_ncity, _ = city_median(ratio_by_workload)
    cov_wl = st.median(list(cov_by_wl.values())) if cov_by_wl else float("nan")
    cov_city, cov_ncity, _ = city_median(cov_by_wl) if cov_by_wl else (
        float("nan"), 0, {})
    comb = dict(ratio_by_workload)
    comb.update(cov_by_wl)
    comb_city, comb_ncity, _ = city_median(comb)
    add("C07b", "Section 4 (aggregation); attached sensitivity table", PRIMARY,
        p1,
        "same per-workload ratios as C07, plus the six coverage workloads from "
        "C18; grouping key = canonical city from configs/city_aliases.csv",
        "within each canonical city take the median of that city's workload "
        "ratios, then take the median across cities; the workload-weighted "
        "figure is the median across workloads",
        "two aggregations of the same per-workload ratios; raw timings are "
        "never pooled across workloads", "ratio",
        "primary: workload=%.4f city=%.4f (%d workloads, %d cities); "
        "coverage: workload=%.4f city=%.4f (%d workloads, %d cities); "
        "combined: workload=%.4f city=%.4f (%d workloads, %d cities)"
        % (prim_wl, prim_city, len(ratios), prim_ncity, cov_wl, cov_city,
           len(cov_by_wl), cov_ncity, st.median(list(comb.values())), comb_city,
           len(comb), comb_ncity),
        limit="descriptive sensitivity only: relabelling workloads by city is "
              "not an independence claim and does not change any measured "
              "value. Shenzhen and Guangzhou each carry two workloads, so the "
              "city-weighted figure differs from the workload-weighted one")

    # ---- C08-C11: batch / duplicate / audit batch / warm ratios -------------
    # explicit rows (no helper tricks): batch, batch_dup, audit-batch, warm
    for cid, mode, output, variant, where, label in (
            ("C08", "batch", "matched", "cold", "Results 5.1; Table tab:batch",
             "four-radius batch"),
            ("C09", "batch_dup", "matched", "cold", "Table tab:batch",
             "repeated 200 m request"),
            ("C10", "batch", "audit", "cold", "Table tab:batch", "audit batch"),
            ("C11", "single", "matched", "warm", "Table tab:batch", "warm")):
        rs = {}
        for ds, city in ORDER:
            u = med(prim, ds, city, "b1", mode, output, variant)
            f = med(prim, ds, city, "c", mode, output, variant)
            if u and f:
                rs[LABEL[(ds, city)]] = round(f / u, 3)
        vals = list(rs.values())
        add(cid, where, PRIMARY, p1,
            "mode=%s,output=%s,variant=%s,rep in 1..5, 6 primary workloads"
            % (mode, output, variant),
            "median(Full)/median(B1) per workload, same mode/output/variant",
            "ratio per workload; reported as per-workload values and min/max",
            "ratio", "%s | range %.3f-%.3f"
            % (";".join("%s=%.3f" % kv for kv in rs.items()), min(vals),
               max(vals)), limit=LIM_REPS)

    # ---- C12: candidate-position accounting (batch, cold, matched) ---------
    b1_pos, n1 = counter_sum(prim, "n_rows_queried", "b1", "batch")
    fq, n2 = counter_sum(prim, "n_rows_exact_quota", "c", "batch")
    fs, n3 = counter_sum(prim, "n_rows_exact_select", "c", "batch")
    bc, n4 = counter_sum(prim, "n_block_center_queries", "c", "batch")
    add("C12", "Results 5.2; Figure fig:work", PRIMARY, p1,
        "mode=batch,output=matched,variant=cold, rep=1, 6 primary workloads",
        "sum over workloads of cumulative counters: B1 n_rows_queried; Full "
        "n_rows_exact_quota + n_rows_exact_select; Full n_block_center_queries",
        "sum across workloads (counters are deterministic per configuration; "
        "rep=1 used, agreement across reps checked)", "query positions",
        "B1_cand=%d;Full_quota=%d;Full_select=%d;Full_cand=%d;delta=%d(%.2f%%);"
        "centers=%d;cand+centers=%d(%.2f%% vs B1)"
        % (b1_pos, fq, fs, fq + fs, b1_pos - (fq + fs),
           (b1_pos - (fq + fs)) / b1_pos * 100, bc, fq + fs + bc,
           (fq + fs + bc) / b1_pos * 100),
        limit="query positions are volume, not time; cost per position differs "
              "and center queries have different locality")

    # determinism check of counters across reps
    det = []
    for ds, city in ORDER:
        vals = {int(float(r["n_rows_queried"])) for r in prim
                if r["dataset"] == ds and r["city"] == city
                and r["method"] == "b1" and r["mode"] == "batch"
                and r["output"] == "matched" and r["variant"] == "cold"
                and r["n_rows_queried"] not in ("", None)}
        det.append(len(vals) == 1)
    add("C12b", "internal check for C12", PRIMARY, p1,
        "same filter as C12, all reps", "number of distinct n_rows_queried "
        "values per workload across reps", "per-workload", "count",
        "all workloads constant across reps: %s" % all(det),
        limit="counter determinism does not imply timing determinism")

    # ---- C13: rank scan volume ---------------------------------------------
    rk, _ = counter_sum(prim, "n_scan_rows_examined", "c", "batch")
    sb, _ = counter_sum(prim, "n_scan_batches", "c", "batch")
    fb, _ = counter_sum(prim, "n_fallbacks", "c", "batch")
    fp, _ = counter_sum(prim, "n_fast_path", "c", "batch")
    fpf, _ = counter_sum(prim, "n_fast_path_fail", "c", "batch")
    add("C13", "Results 5.2", PRIMARY, p1,
        "mode=batch,output=matched,variant=cold, rep=1, 6 primary workloads, "
        "method=c (Full)",
        "sum over workloads of n_scan_rows_examined, n_scan_batches, "
        "n_fallbacks, n_fast_path, n_fast_path_fail",
        "sum across workloads", "counts",
        "rank_positions=%d;scan_batches=%d;fallbacks=%d;fast_path_ok=%d;"
        "fast_path_fail=%d" % (rk, sb, fb, fp, fpf),
        limit="aggregates all evaluated radii including the zero-radius arm; "
              "not a positive-radius success probability")

    # ---- C14: block classification denominators ----------------------------
    tot, _ = counter_sum(prim, "n_blocks_cand_total", "c", "batch")
    ak, _ = counter_sum(prim, "n_blocks_allkeep", "c", "batch")
    ad, _ = counter_sum(prim, "n_blocks_alldelete", "c", "batch")
    un, _ = counter_sum(prim, "n_blocks_uncertain", "c", "batch")
    add("C14", "Results 5.2", PRIMARY, p1,
        "mode=batch,output=matched,variant=cold, rep=1, 6 primary workloads, "
        "method=c",
        "sum of block--mask--radius occurrences: total, allkeep, alldelete, "
        "uncertain; share = (allkeep+alldelete)/total",
        "sum across workloads", "block occurrences / share",
        "total=%d;allkeep=%d;alldelete=%d;uncertain=%d;decided_share=%.1f%%"
        % (tot, ak, ad, un, (ak + ad) / tot * 100),
        limit="zero-radius requests contribute automatically retained blocks; "
              "the share is not a positive-radius pruning rate")

    # ---- C15: C1 ablation ---------------------------------------------------
    c1r = []
    for ds, city in ORDER:
        b1 = med(prim, ds, city, "b1", "single", "matched", "cold")
        c1 = med(prim, ds, city, "c1", "single", "matched", "cold")
        c1r.append(c1 / b1)
    def one_counter(method, key, ds="streetview", city="sy"):
        for r in prim:
            if (r["dataset"] == ds and r["city"] == city
                    and r["method"] == method and r["mode"] == "single"
                    and r["output"] == "matched" and r["variant"] == "cold"
                    and r["rep"] == "1" and r.get(key) not in ("", None)):
                return int(float(r[key]))
        return None

    sy_q_b1 = one_counter("b1", "n_rows_queried")
    sy_q_c1 = one_counter("c1", "n_rows_exact")
    add("C15", "Results 5.4", PRIMARY, p1,
        "single, matched, cold, reps 1..5 (ratios); rep=1 (query counts)",
        "median(C1)/median(B1) per workload; sy n_rows_queried for B1 and C1",
        "median of the six per-workload ratios", "ratio / count",
        "median_C1_ratio=%.3f;sy_B1_q=%d;sy_C1_q=%d"
        % (st.median(c1r), sy_q_b1, sy_q_c1),
        limit=LIM_REPS)

    # ---- C16: externally supplied quotas -----------------------------------
    red = []
    vals = []
    for ds, city in ORDER:
        b1p = med(prim, ds, city, "b1_pre", "single", "matched", "cold")
        cp = med(prim, ds, city, "c_pre", "single", "matched", "cold")
        b1 = med(prim, ds, city, "b1", "single", "matched", "cold")
        cf = med(prim, ds, city, "c", "single", "matched", "cold")
        red.append((cf - cp) / cf * 100)
        vals.append((LABEL[(ds, city)], b1p, cp, cp / b1p))
    add("C16", "Table tab:quota; Results 5.4", PRIMARY, p1,
        "methods b1_pre/c_pre (frozen reference quotas as external input), "
        "single, matched, cold, reps 1..5",
        "median per method; Full_given_q reduction = (median(Full)-"
        "median(Full_given_q))/median(Full)",
        "per-workload medians; reduction range across workloads", "ms / %",
        "given_q: %s | Full reduction %.1f-%.1f%%"
        % (";".join("%s B1=%.1f Full=%.1f ratio=%.3f" % v for v in vals),
           min(red), max(red)),
        limit="quota object construction stays inside the timer; arrays are "
              "loaded before the loop")

    # ---- C17: fixed vs priority -------------------------------------------
    fx = []
    for ds, city in ORDER:
        c = med(prim, ds, city, "c", "single", "matched", "cold")
        f = med(prim, ds, city, "c_fixed", "single", "matched", "cold")
        fx.append((LABEL[(ds, city)], f / c))
    add("C17", "Table tab:quota; Results 5.4", PRIMARY, p1,
        "methods c_fixed/c, single, matched, cold, reps 1..5",
        "median(c_fixed)/median(c) per workload", "per-workload ratios; range",
        "ratio", ";".join("%s=%.2f" % v for v in fx) + " range %.2f-%.2f"
        % (min(x for _l, x in fx), max(x for _l, x in fx)),
        limit="includes possible refinement-work, cache and scheduling "
              "differences; not a scheduler-only attribution")

    # ---- C18: coverage snapshots ------------------------------------------
    d4r = []
    for ds, city in ORDER_D4:
        b1 = med(d4, ds, city, "b1", "single", "matched", "cold")
        b1b = med(d4, ds, city, "b1b", "single", "matched", "cold")
        cf = med(d4, ds, city, "c", "single", "matched", "cold")
        if b1 and cf:
            d4r.append((city, cf / min(b1, b1b)))
    add("C18", "Results 5.6", D4, p2,
        "6 coverage snapshots, single primary radius, cold, matched, reps 1..5",
        "median(Full)/min(median(B1),median(B1b)) per snapshot",
        "ratio per snapshot; range across the six", "ratio",
        ";".join("%s=%.3f" % (c, r) for c, r in d4r) + " range %.3f-%.3f"
        % (min(r for _c, r in d4r), max(r for _c, r in d4r)),
        limit=LIM_REPS + "; snapshot selection rule corrected in "
              "D4_SELECTION_CORRECTION.md (bbox-density extremes, not NN "
              "extremes)")

    # ---- C19: output-cost medians and payload shares -----------------------
    def resid(r):
        return float(r["ms_total"]) - float(r["ms_write"])

    parts, shares = [], {}
    for out in ("matched", "audit"):
        diffs_med, diffs_res = [], []
        for ds, city in ORDER:
            b = {r["rep"]: r for r in prim
                 if r["dataset"] == ds and r["city"] == city
                 and r["method"] == "b1" and r["mode"] == "single"
                 and r["output"] == out and r["variant"] == "cold"
                 and r["rep"] in {str(i) for i in range(1, 6)}}
            f = {r["rep"]: r for r in prim
                 if r["dataset"] == ds and r["city"] == city
                 and r["method"] == "c" and r["mode"] == "single"
                 and r["output"] == out and r["variant"] == "cold"
                 and r["rep"] in {str(i) for i in range(1, 6)}}
            diffs_med.append(st.median([float(x["ms_total"]) for x in b.values()])
                             - st.median([float(x["ms_total"])
                                          for x in f.values()]))
            # residual per repetition, median per workload, then differenced
            diffs_res.append(st.median([resid(x) for x in b.values()])
                             - st.median([resid(x) for x in f.values()]))
        parts.append("%s: diff_of_medians=%.1f;median_of_resid_diffs=%.1f"
                     % (out, st.median(diffs_med), st.median(diffs_res)))

    for meth in ("b1", "c"):
        for out in ("matched", "audit"):
            per_workload = []
            for ds, city in ORDER:
                ss = [float(r["ms_write"]) / float(r["ms_total"]) * 100
                      for r in prim
                      if r["dataset"] == ds and r["city"] == city
                      and r["method"] == meth and r["mode"] == "single"
                      and r["output"] == out and r["variant"] == "cold"
                      and r["rep"] in {str(i) for i in range(1, 6)}
                      and float(r["ms_total"]) > 0]
                if ss:
                    per_workload.append(st.median(ss))
            shares[meth + "_" + out] = st.median(per_workload)
    add("C19", "Results 5.7", PRIMARY, p1,
        "single, cold, reps 1..5; B1 vs Full; matched and audit",
        "residual = ms_total - ms_write per repetition; per workload take the "
        "median residual of each method and difference them; then median over "
        "the six workloads. 'diff_of_medians' differs the medians of ms_total "
        "instead. Payload share = per-workload median of ms_write/ms_total, "
        "then median over the six workloads",
        "per-workload medians, then median over 6 workloads", "ms / %",
        "; ".join(parts) + " | payload_share matched B1=%.1f%% Full=%.1f%%; "
        "audit B1=%.1f%% Full=%.1f%%"
        % (shares["b1_matched"], shares["c_matched"], shares["b1_audit"],
           shares["c_audit"]),
        limit="payload timing covers text conversion, gzip compression and "
              "file write; OS cache state affects it. The two aggregation "
              "orders are reported separately because they do not coincide "
              "for audit")

    # ---- C20: writer byte checks (audited from the run's own file) ---------
    if wr.exists():
        recs = [json.loads(l) for l in wr.read_text(encoding="utf-8").splitlines()
                if l.strip()]
        formal = [r for r in recs
                  if str(r.get("rep")) in {str(i) for i in range(1, 8)}]
        bad = [r for r in formal if not (r.get("payload_match")
                                         and r.get("status_match"))]
        add("C20", "Results 5.3", WRITER,
            str(wr.relative_to(root)).replace("\\", "/"),
            "all written records; formal = rep in 1..7 (warmup, pre1 and pre2 "
            "excluded)",
            "count records; count formal records whose payload_match and "
            "status_match are not both true", "sum over records", "counts",
            "all_records=%d;formal=%d;formal_failing=%d"
            % (len(recs), len(formal), len(bad)),
            limit="writers share serialization components; both timed arms use "
                  "a buffered writer, not the production streaming writer",
            status="audited_report")

    # ---- C21: E1 (new run) -------------------------------------------------
    e1s = _first(root, E1, "e1_summary.csv")
    if e1s.exists():
        s = sha256(e1s)
        key = str(e1s.relative_to(root)).replace("\\", "/")
        SHA[key] = s
        with open(e1s, encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        ratios = [float(r["I_over_U_total_ratio"]) for r in rows
                  if r["I_over_U_total_ratio"]]
        pay = [(float(r["I_med_payload"]) / float(r["U_med_payload"]) - 1) * 100
               for r in rows if r["I_med_payload"] and r["U_med_payload"]]
        u_share = [float(r["U_payload_share_pct"]) for r in rows
                   if r["U_payload_share_pct"]]
        # production-path Full/B1 ratio per dataset and mode, from the U arm
        def get(cid, col):
            for r in rows:
                if r["config_id"] == cid and r[col] not in ("", None):
                    return float(r[col])
            return None
        comp = []
        for ds, city in (("streetview", "sz"), ("so2sat43", "shenzhen"),
                         ("so2sat10", "guangzhou")):
            for mode in ("single", "batch"):
                b1 = get("%s/%s/kd/%s" % (ds, city, mode), "U_med_total")
                fl = get("%s/%s/full/%s" % (ds, city, mode), "U_med_total")
                if b1 and fl:
                    comp.append("%s/%s/%s=%.2f" % (ds, city, mode, fl / b1))
        qshare = [float(r["I_med_quota"]) / float(r["I_med_total"]) * 100
                  for r in rows
                  if r["method"] == "full" and r["I_med_quota"]
                  and r["I_med_total"]]
        add("C21", "Results 5.3 (production writer)", E1, key,
            "12 configs, both arms, formal reps only",
            "per-config medians of ms_total for U (uninstrumented production "
            "path) and I (instrumented); ratio I/U; payload overhead; "
            "production-path Full/B1 ratio = U_med_total(full)/U_med_total(kd); "
            "quota share = I_med_quota/I_med_total for Full",
            "per-config medians, then median/range across configs", "ratio / %",
            "n_configs=%d;I_over_U_median=%.4f (%.4f-%.4f);payload_delta_median="
            "%+.2f%%;U_payload_share median=%.1f%% (%.1f-%.1f);"
            "quota_share_full median=%.1f%%;prod_Full_over_B1: %s"
            % (len(ratios), st.median(ratios), min(ratios), max(ratios),
               st.median(pay) if pay else float("nan"),
               st.median(u_share), min(u_share), max(u_share),
               st.median(qshare) if qshare else float("nan"),
               ";".join(comp)),
            status="new_run",
            limit="7 repetitions per cell are a fixed budget, not a "
                  "significance guarantee; single machine, serial queue")

    # ---- C22: E2 (new run) -------------------------------------------------
    e2j = _first(root, E2, "e2_summary.json")
    if e2j.exists():
        key = str(e2j.relative_to(root)).replace("\\", "/")
        SHA[key] = sha256(e2j)
        sm = json.loads(e2j.read_text(encoding="utf-8"))
        by = sm.get("by_radius_level", {})
        add("C22", "Results 5.6 (mechanism)", E2, key,
            "5 seeds x 2 geometries x 3 radius quantile levels x 2 methods x 7 "
            "reps, cold matched",
            "per block and radius level: median(Full)/median(B1); summarised "
            "per level across the 10 blocks",
            "median across blocks within a level; seed spread kept separate "
            "from timing spread", "ratio",
            ";".join("%s med=%.3f [%.3f,%.3f] all>1=%s"
                     % (k, v["median_ratio"], v["min"], v["max"],
                        v["all_above_one"]) for k, v in by.items()),
            status="new_run",
            limit="radius level is a quantile of each block's own distance "
                  "distribution, so the realised radius in metres differs "
                  "across blocks; 7 reps are timing repetitions of one fixed "
                  "city, not independent data samples")

    # ---- B02/B04 post-review evidence ------------------------------------
    post_review_claims = []
    b02 = _first(root, "b02-independent-v3-20261125", "report.json")
    if b02.exists():
        b02_key = str(b02.relative_to(root)).replace("\\\\", "/")
        SHA[b02_key] = sha256(b02)
        b02j = json.loads(b02.read_text(encoding="utf-8"))
        post_review_claims.append({"claim_id": "B02", "paper_location": "Correctness and Artifact Validation; Discussion", "run_id": "b02-independent-v3-20261125", "source_file": b02_key, "source_sha256": SHA[b02_key], "filter": "10 synthetic blocks x 10,000 rows x 3 frozen radius levels; 420 formal + 60 warmup records", "formula": "independent exhaustive float64 distances; independently recompute pools, per-repeat quotas, feasibility, row counts and matrix; mutation checks for ID/order/quota/status/digest/round", "aggregation": "all observed rows and independent design cells; full raw reference retained in run directory", "unit": "status / differences", "value": "%s; differences=%d; historical status=%s; historical ordered IDs=%s; historical payload digest rederived=%s" % (b02j.get("status"), b02j.get("difference_count"), b02j.get("historical_status_comparable"), b02j.get("historical_ordered_ids_comparable"), b02j.get("historical_payload_digest_independently_rederived")), "status": "limited_pass", "limitation": "historical E2 did not retain matched payloads or status records; independently reconstructed ordered IDs/status cannot be directly compared with historical outputs", "note": "Post-review evidence addendum; not included in the historical 25-claim manuscript table"})

    b04 = _first(root, "b04-fixedquota-output-20261125-rerun21", "b04_summary.json")
    if b04.exists():
        b04_key = str(b04.relative_to(root)).replace("\\\\", "/")
        SHA[b04_key] = sha256(b04)
        b04j = json.loads(b04.read_text(encoding="utf-8"))
        b04_rows_path = b04.parent / "b04_rows.csv"
        SHA[str(b04_rows_path.relative_to(root)).replace("\\\\", "/")] = sha256(b04_rows_path)
        rows_b04 = list(csv.DictReader(open(b04_rows_path, encoding="utf-8-sig")))
        formal_b04 = [r for r in rows_b04 if r.get("formal") == "1" and r.get("status") == "ok"]
        group_vals = {}
        for r in formal_b04:
            group_vals.setdefault((r["quota_mode"], r["output_path"], r["radius_level"], r["method"]), []).append(float(r["ms_total"]))
        diagnostic_ratios = []
        for quota_mode in ("natural_shared", "fixed_common_min"):
            for output_path in ("production_gzip", "serialized_count_digest_sink"):
                for level in ("p10", "p50", "p90"):
                    kd_vals = group_vals.get((quota_mode, output_path, level, "kd"), [])
                    full_vals = group_vals.get((quota_mode, output_path, level, "c"), [])
                    if kd_vals and full_vals:
                        diagnostic_ratios.append((quota_mode, output_path, level, st.median(full_vals) / st.median(kd_vals)))
        ratio_range = (min(x[3] for x in diagnostic_ratios), max(x[3] for x in diagnostic_ratios)) if diagnostic_ratios else (float("nan"), float("nan"))
        post_review_claims.append({"claim_id": "B04", "paper_location": "Discussion and Limitations", "run_id": "b04-fixedquota-output-20261125-rerun21", "source_file": b04_key, "source_sha256": SHA[b04_key], "filter": "2 geometries x 3 seeds x 3 radii x 2 methods x 2 quota modes x 2 output paths x 7 formal reps", "formula": "per cell median ms_total; Full/B1 ratio within quota/output/radius condition; correctness by ordered-output and serialized digests", "aggregation": "condition-specific medians over 42 observations (6 samples x 7 repetitions); diagnostic intervention, not a natural-contract replacement", "unit": "ratio / diagnostic checks", "value": "formal=%d; fixed_quota_mismatches=%s; ordered_digest_match=%s; serialized_digest_match=%s; Full/B1 ratios range %.3f-%.3f" % (len(formal_b04), b04j.get("fixed_quota_mismatches"), b04j.get("cross_method_ordered_output_digest_match"), b04j.get("serialized_digest_match"), ratio_range[0], ratio_range[1]), "status": "new_run_diagnostic", "limitation": "fixed common-min quotas alter the natural quota contract; count/digest sink is not a production end-to-end path; findings do not isolate a single causal overhead", "note": "Post-review evidence addendum; not included in the historical 25-claim manuscript table"})

    # ---- W01: withdrawn claims --------------------------------------------
    add("W01", "Abstract/Results (historical)", "postgis-matched-private-20261123", 
        "", "n/a", "n/a", "n/a", "n/a",
        "general database speed ratio: withdrawn; the isolated single-city "
        "matched comparison does not support a general ratio",
        status="withdrawn",
        limit="warm database vs cold B1, excluded load costs, different "
              "semantics in the historical timing path")

    out = a.out if a.out.is_absolute() else root / a.out
    addendum = out.with_name(out.stem + "_postreview_addendum.csv")
    if out.exists() or (post_review_claims and addendum.exists()):
        raise SystemExit("refusing to overwrite existing output: %s" %
                         (out if out.exists() else addendum))
    out.parent.mkdir(parents=True, exist_ok=True)
    cols = ["claim_id", "paper_location", "run_id", "source_file",
            "source_sha256", "filter", "formula", "aggregation", "unit",
            "value", "status", "limitation", "note"]
    with open(out, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in ROWS:
            w.writerow(r)
    if post_review_claims:
        with open(addendum, "w", newline="", encoding="utf-8-sig") as fh:
            addendum_writer = csv.DictWriter(fh, fieldnames=cols)
            addendum_writer.writeheader()
            addendum_writer.writerows(post_review_claims)
        print("post-review addendum=%d -> %s" % (len(post_review_claims), addendum))
    print("claims=%d -> %s" % (len(ROWS), out))
    for r in ROWS:
        print("  %-5s %-42s %s" % (r["claim_id"], r["value"][:90],
                                   r["status"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
