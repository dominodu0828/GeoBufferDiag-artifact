# -*- coding: utf-8 -*-
"""CLI launcher for splitbench.

The frozen interpreter is an embedded distribution: its ``python312._pth``
pins ``sys.path`` to a fixed embedded distribution path and
ignores both PYTHONPATH and script-mode auto-insertion, so neither
``python -B -m splitbench`` nor a bare script import can see this project,
and the frozen tree must stay read-only.  The launcher inserts the project
root explicitly -- the same mechanism the old project uses in
``analysis/common.py`` -- and then restores the ``-m splitbench`` interface:

    python -B splitbench_cli.py prepare --config configs/paper_primary.yaml \
        --suite six-city --run <run-id>

(All other arguments identical to ``python -B -m splitbench ...``.)
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from splitbench.__main__ import main

main()

