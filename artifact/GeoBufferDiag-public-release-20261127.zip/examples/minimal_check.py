# -*- coding: utf-8 -*-
"""Minimal self-contained example for the public artifact.

Builds one tiny synthetic city with the frozen contract structure, runs the
B1 baseline and the Full candidate, and checks quotas and selections
against a brute-force reference computed inline with NumPy only -- no
external datasets, no proprietary dependencies, no absolute paths.

Contract reproduced here:
  * candidate pool of a fold = rows that are not its test rows;
  * r = 0 keeps every candidate, r > 0 deletes d <= r (d = nearest-test
    distance, closed boundary on the delete side);
  * per-repeat quota = per-class min of kept counts over the repeat's
    contiguous and scattered folds; floor 5 per class;
  * selection = per class the q smallest (key, orig_row) pairs, positives
    first in the emitted order;
  * an infeasible repeat rejects the whole city-radius cell.

Usage (any Python >= 3.10 with numpy, scipy, threadpoolctl installed):
    python examples/minimal_check.py
Expected output: `MINIMAL CHECK PASSED` and exit code 0.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np

from splitbench.baseline_b1 import B1Engine
from splitbench.candidate import CandidateEngine
from splitbench.contract import CityFolds
from splitbench.inputs import CityTable

N = 400
K = 5
N_REPEATS = 2
DOMAIN = 5000.0
RADII = [0.0, 100.0, 200.0]
FLOOR = 5
SEED = 20260801


def make_city():
    rng = np.random.default_rng(SEED)
    xy = rng.uniform(0.0, DOMAIN, (N, 2))
    y = (rng.random(N) < 0.5).astype(np.int8)
    keys = rng.random(N)
    ct = CityTable(dataset="demo", city="demo", manifest=None,
                   manifest_sha256="",
                   orig_row=np.arange(N, dtype=np.int64),
                   biz_id=np.array([str(i) for i in range(N)], dtype=object),
                   label=y, xy=xy, keys=keys, zone=None, southern=None,
                   provenance={})
    gx = np.clip((xy[:, 0] / (DOMAIN / K)).astype(np.int64), 0, K - 1)
    blocks = [gx == k for k in range(K)]
    scatter = []
    for _ in range(N_REPEATS):
        perm = rng.permutation(N)
        groups = np.array_split(perm, K)
        scatter.append([np.zeros(N, dtype=bool) for _ in groups])
        for mask, g in zip(scatter[-1], groups):
            mask[g] = True
    return ct, CityFolds(blocks, scatter)


def nearest_test(xy, te, cand):
    return np.sqrt(((xy[cand][:, None, :] - xy[te][None, :, :]) ** 2)
                   .sum(-1)).min(1)


def brute_force(ct, folds, radii):
    """Per (rep, fold): candidate rows, kept rows per radius; per repeat:
    quota and feasibility.  Pure NumPy, no index, no pruning."""
    xy, y, keys = ct.xy, ct.label, ct.keys
    folds_out = []
    for k, te in enumerate(folds.blocks):
        cand = np.flatnonzero(~te)
        d = nearest_test(xy, te, cand)
        folds_out.append(("contig", k, 0, cand, d))   # rep-independent
    for rep in range(folds.n_repeats):
        for j, te in enumerate(folds.scatter[rep]):
            cand = np.flatnonzero(~te)
            d = nearest_test(xy, te, cand)
            folds_out.append(("scatter", j, rep, cand, d))

    kept = {}
    for kind, fid, rep, cand, d in folds_out:
        for r in radii:
            kept[(kind, fid, rep, r)] = (cand if r == 0
                                         else cand[d > r])
    budgets = {}
    for rep in range(folds.n_repeats):
        per = []
        for kind, fid, rrep, cand, d in folds_out:
            if kind == "scatter" and rrep != rep:
                continue
            k = kept[(kind, fid, rrep, 0.0) if False else
                     (kind, fid, rrep, [r for r in radii][0])]
            # kept counts for THIS radius are taken per radius below
        # quota per radius computed in the caller loop; keep simple
        budgets[rep] = None
    return folds_out, kept


def select(pool, y, keys, qp, qn):
    out = {}
    for cls in (1, 0):
        idx = [int(i) for i in pool if y[i] == cls]
        idx.sort(key=lambda i: (keys[i], i))
        out[cls] = np.array(sorted(idx[:qp if cls == 1 else qn]),
                            dtype=np.int64)
    return out


def main():
    ct, folds = make_city()
    xy, y, keys = ct.xy, ct.label, ct.keys
    engines = {"b1": B1Engine(),
               "b1b": B1Engine(bounded=True),
               "c1": CandidateEngine(arm="c1", side=1000.0, margin=1e-6,
                                     batch_rows=4096),
               "c2": CandidateEngine(arm="c2", side=1000.0, margin=1e-6,
                                     batch_rows=4096),
               "c": CandidateEngine(arm="c", side=1000.0, margin=1e-6,
                                    batch_rows=4096)}
    results = {}
    for name, eng in engines.items():
        res, st = eng.run_city(ct, folds, RADII, "matched")
        res2, _ = eng.run_city(ct, folds, RADII, "matched", state=st)
        for r in RADII:
            if res.status[r]["feasible"] != res2.status[r]["feasible"] or \
                    res.quota[r] != res2.quota[r]:
                print("FAIL cold/warm mismatch", name, r)
                return 1
        results[name] = res

    # brute-force fold geometry once
    fold_d = {}
    for k, te in enumerate(folds.blocks):
        cand = np.flatnonzero(~te)
        fold_d[("contig", k)] = (cand, nearest_test(xy, te, cand))
    for rep in range(folds.n_repeats):
        for j, te in enumerate(folds.scatter[rep]):
            cand = np.flatnonzero(~te)
            fold_d[("scatter", rep, j)] = (cand, nearest_test(xy, te, cand))

    failures = 0
    for r in RADII:
        quotas = {}
        for rep in range(folds.n_repeats):
            per = []
            for k in range(K):
                cand, d = fold_d[("contig", k)]
                kept = cand if r == 0 else cand[d > r]
                per.append((int((y[kept] == 1).sum()),
                            int((y[kept] == 0).sum())))
            for j in range(K):
                cand, d = fold_d[("scatter", rep, j)]
                kept = cand if r == 0 else cand[d > r]
                per.append((int((y[kept] == 1).sum()),
                            int((y[kept] == 0).sum())))
            qp, qn = min(x[0] for x in per), min(x[1] for x in per)
            feas = qp >= FLOOR and qn >= FLOOR
            quotas[rep] = (qp, qn, feas)
            rs = results["b1"].status[r]
            if rs["feasible"] and results["b1"].quota[r][rep] != (qp, qn):
                failures += 1
                print("FAIL quota", rep, r, results["b1"].quota[r][rep],
                      (qp, qn))
        cell_feasible = all(v[2] for v in quotas.values())
        if results["b1"].status[r]["feasible"] != cell_feasible:
            failures += 1
            print("FAIL cell feasibility", r)
        if not cell_feasible:
            continue
        for name in ("b1", "c"):
            ref_m = {(c["rep"], c["geom"], c["fold"]): c
                     for c in results[name].matched[r]}
            for rep in range(folds.n_repeats):
                qp, qn, _ = quotas[rep]
                fold_list = ([((rep, 0, k), fold_d[("contig", k)])
                              for k in range(K)]
                             + [((rep, 1, j),
                                 fold_d[("scatter", rep, j)])
                                for j in range(K)])
                for key, (cand, d) in fold_list:
                    kept = cand if r == 0 else cand[d > r]
                    sel = select(kept, y, keys, qp, qn)
                    got = ref_m[key]
                    for arm_ids, sel_ids in (
                            ("buf_pos", sel[1]), ("buf_neg", sel[0])):
                        if not np.array_equal(np.sort(got[arm_ids]),
                                              np.sort(sel_ids)):
                            failures += 1
                            print("FAIL selection", name, rep, key, r,
                                  arm_ids)
        # unbuffered arm of B1 must equal the buffered arm at r = 0
    if failures == 0:
        print("MINIMAL CHECK PASSED")
        return 0
    print("MINIMAL CHECK FAILED: %d failures" % failures)
    return 1


if __name__ == "__main__":
    sys.exit(main())
