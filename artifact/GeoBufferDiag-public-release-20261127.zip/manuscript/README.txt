Source for GeoBufferDiag PVLDB 2027 manuscript. Compile main.tex with Tectonic or a compatible LaTeX toolchain.
