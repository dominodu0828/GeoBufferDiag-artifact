# E1 生产 writer 端到端与分项复核（e1-prodwriter-20261123-b）

方案：`09_修订后收尾方案_20261123.md` §3 E1。输入与参考只读取自 `runs/postreview-bench-20261119-034720-156`（未写入该 run）。

## 1. 配置口径与实际完成

| 项目 | 值 |
|---|---|
| 配置矩阵 | 3 数据集-城市 × 2 方法（B1/Full）× 2 模式（single/batch），output=matched、variant=cold |
| 配置数 | 12（设计 12；用户消息中的 8 无法覆盖三城，理由见 §7） |
| 每配置正式重复 | 7；另有 1 轮丢弃预热 |
| 完成配置数（两臂各满 7 条） | 12 / 12 |
| 计时行（含预热） | 192 |
| 正式记录 | 168（U=84，I=84） |
| 使用时间 | 2026-11-23T06:43:59.594+00:00 → 2026-11-23T06:49:32.116+00:00（UTC），wall 332.5 s |
| 线程 | threadpoolctl limits=1，围绕 engine+writer |
| 解释器 | 3.12.10 |

两臂：**U** 未插桩（生产引擎 + 生产流式 writer），**I** 插桩（同一引擎源码，运行时给实例方法加 `perf_counter` 钩子，payload 仍由 `write_outputs` 流式 gzip 写出）。同一配置内两臂相邻执行，顺序按 `(config_index + rep) % 2` 交替（U 先 / I 先），每条记录 `seq` 为全局执行序号，`order_pos` 为配置内位置。

## 2. 计时边界与不可分项

- `read`：`load_city_inputs()` 冷读冻结 npz；`engine`：`run_city()`；`payload`：`write_outputs()`（流式 gzip，compresslevel=6）；`status`：`write_status()`；`total`：读入前到 status 写完。
- 仅插桩臂记录 `res.phases`（index/exact/quota/select），并记录钩子的inclusive 调用时间（钩子嵌套，不能与 phase 相加）。
- 未插桩臂**不记录**引擎内部分项：只有 read/payload/status/total 及两臂共有的行数、字节与校验结果，因此其分项不可分，不做推断。
- 结构上不可分/不可归因的部分：Full 的精确距离查询发生在 quota 与 select 内部，无法从 phase 中单独剥离；index 含网格/块与块中心查询；payload 的计时包含 gzip 压缩与文件落盘；status 与 payload 的 fsync 行为受 OS 缓存影响。

## 3. 每配置中位数（ms）

| 配置 | U total 中位 [min,max] | I total 中位 [min,max] | I/U | U payload 占比 | I payload 占比 |
|---|---|---|---|---|---|
| streetview/sz/kd/single | 2000.134 [1850.004, 2858.573] | 2106.993 [1843.76, 2298.466] | 1.0534 | 61.06% | 63.74% |
| streetview/sz/full/single | 2677.789 [2380.392, 3445.072] | 2956.211 [2465.184, 3305.354] | 1.104 | 46.83% | 45.89% |
| streetview/sz/kd/batch | 4752.788 [4155.356, 5607.099] | 4529.698 [4178.314, 5602.761] | 0.9531 | 80.24% | 78.45% |
| streetview/sz/full/batch | 6516.839 [5749.281, 7607.149] | 6278.237 [5760.791, 8666.93] | 0.9634 | 65.69% | 61.88% |
| so2sat43/shenzhen/kd/single | 78.687 [70.963, 115.576] | 80.797 [72.644, 124.79] | 1.0268 | 33.22% | 32.66% |
| so2sat43/shenzhen/full/single | 113.62 [99.129, 136.107] | 126.714 [97.022, 162.553] | 1.1152 | 21.44% | 18.96% |
| so2sat43/shenzhen/kd/batch | 145.285 [140.223, 165.867] | 152.904 [144.161, 179.939] | 1.0524 | 60.03% | 57.83% |
| so2sat43/shenzhen/full/batch | 238.282 [214.202, 310.848] | 242.147 [225.92, 317.152] | 1.0162 | 37.63% | 38.04% |
| so2sat10/guangzhou/kd/single | 151.243 [133.421, 239.75] | 158.501 [135.818, 237.76] | 1.048 | 33.44% | 27.91% |
| so2sat10/guangzhou/full/single | 286.133 [241.879, 407.51] | 280.346 [259.521, 481.375] | 0.9798 | 17.59% | 18.86% |
| so2sat10/guangzhou/kd/batch | 396.281 [337.969, 573.385] | 394.794 [338.992, 469.447] | 0.9962 | 56.3% | 61.04% |
| so2sat10/guangzhou/full/batch | 691.34 [587.305, 802.775] | 755.705 [628.068, 1108.174] | 1.0931 | 35.97% | 34.57% |

- 未插桩臂 12 配置中位 total 合计 18048.4 ms；插桩臂 18063.0 ms。
- 插桩/未插桩总时间比：中位 1.0374，范围 0.9531–1.1152。
- 同一生产 writer 在两臂下的 payload 中位差：中位 +2.06%，范围 -12.53%–+9.98%（应为噪声级别；差异大说明磁盘/写回波动）。
- status 写出中位差：中位 -0.87%，范围 -9.00%–+20.55%。

## 4. 插桩臂分项（中位数，ms）

| 配置 | read | index | exact | quota | select | payload | status | total | 未归因 | 引擎内间隙 |
|---|---|---|---|---|---|---|---|---|---|---|
| streetview/sz/kd/single | 16.897 | 58.892 | 588.272 | 9.549 | 46.492 | 1343.039 | 5.57 | 2106.993 | 9.758 | 4.824 |
| streetview/sz/full/single | 15.352 | 190.413 | 0.0 | 998.571 | 294.157 | 1356.628 | 5.001 | 2956.211 | 7.406 | 2.629 |
| streetview/sz/kd/batch | 16.194 | 64.371 | 612.751 | 40.66 | 144.06 | 3553.539 | 5.243 | 4529.698 | 11.713 | 5.547 |
| streetview/sz/full/batch | 19.539 | 194.829 | 0.0 | 1101.063 | 798.772 | 3885.077 | 5.618 | 6278.237 | 11.389 | 5.167 |
| so2sat43/shenzhen/kd/single | 5.232 | 4.467 | 28.548 | 1.001 | 2.594 | 26.392 | 5.518 | 80.797 | 6.484 | 0.949 |
| so2sat43/shenzhen/full/single | 4.944 | 15.692 | 0.0 | 50.551 | 13.294 | 24.03 | 5.179 | 126.714 | 6.373 | 0.557 |
| so2sat43/shenzhen/kd/batch | 5.296 | 4.215 | 28.619 | 3.922 | 11.52 | 88.42 | 4.591 | 152.904 | 6.125 | 0.9 |
| so2sat43/shenzhen/full/batch | 5.32 | 14.02 | 0.0 | 65.991 | 48.513 | 92.111 | 5.341 | 242.147 | 6.146 | 0.931 |
| so2sat10/guangzhou/kd/single | 5.658 | 11.702 | 71.479 | 3.929 | 10.241 | 44.238 | 5.438 | 158.501 | 8.211 | 2.128 |
| so2sat10/guangzhou/full/single | 5.439 | 38.537 | 0.0 | 127.352 | 41.711 | 52.876 | 5.76 | 280.346 | 7.028 | 0.93 |
| so2sat10/guangzhou/kd/batch | 4.944 | 8.871 | 58.321 | 14.23 | 32.14 | 240.985 | 5.806 | 394.794 | 6.874 | 1.666 |
| so2sat10/guangzhou/full/batch | 4.507 | 38.33 | 0.0 | 220.391 | 199.508 | 261.231 | 4.732 | 755.705 | 9.12 | 3.696 |

- 相位差（total − read − index − exact − quota − select − payload − status）中位 7.6 ms，占 total 中位 1.9%；超过 10% 的记录 0/84，最大 8.4%。

## 5. 钩子调用（插桩臂，inclusive）

钩子互相嵌套（`_close_quota` ⊃ `_prove_fold_by_scan` ⊃ `_scan_class` ⊃ `_exact_rows`），下表只用于说明调用分布，不能相加。

- streetview/sz/kd/single：`_fresh_mask` n=735 中位 587.8 ms
- streetview/sz/full/single：`_close_quota` n=140 中位 945.7 ms；`_comparison` n=1400 中位 293.7 ms；`_ensure_blocks` n=7 中位 11.1 ms；`_ensure_dcenter` n=1400 中位 149.2 ms；`_ensure_mask` n=1400 中位 31.0 ms；`_exact_rows` n=2163 中位 692.4 ms；`_prove_fold_by_scan` n=707 中位 941.8 ms；`_prune` n=1400 中位 13.9 ms；`_scan_buffered` n=1400 中位 260.6 ms；`_scan_class` n=3374 中位 1178.1 ms
- streetview/sz/kd/batch：`_fresh_mask` n=735 中位 612.2 ms
- streetview/sz/full/batch：`_close_quota` n=560 中位 909.2 ms；`_comparison` n=5600 中位 797.5 ms；`_ensure_blocks` n=7 中位 13.2 ms；`_ensure_dcenter` n=1400 中位 152.3 ms；`_ensure_mask` n=1400 中位 31.4 ms；`_exact_rows` n=2268 中位 668.6 ms；`_prove_fold_by_scan` n=707 中位 904.5 ms；`_prune` n=5600 中位 46.9 ms；`_scan_buffered` n=4200 中位 683.7 ms；`_scan_class` n=7434 中位 1631.1 ms
- so2sat43/shenzhen/kd/single：`_fresh_mask` n=210 中位 28.5 ms
- so2sat43/shenzhen/full/single：`_close_quota` n=35 中位 42.8 ms；`_comparison` n=350 中位 13.2 ms；`_ensure_blocks` n=7 中位 2.5 ms；`_ensure_dcenter` n=350 中位 10.0 ms；`_ensure_mask` n=350 中位 2.8 ms；`_exact_rows` n=350 中位 26.8 ms；`_prove_fold_by_scan` n=175 中位 42.0 ms；`_prune` n=350 中位 2.5 ms；`_scan_buffered` n=350 中位 10.9 ms；`_scan_class` n=700 中位 50.7 ms
- so2sat43/shenzhen/kd/batch：`_fresh_mask` n=210 中位 28.5 ms
- so2sat43/shenzhen/full/batch：`_close_quota` n=140 中位 44.1 ms；`_comparison` n=1400 中位 48.3 ms；`_ensure_blocks` n=7 中位 2.3 ms；`_ensure_dcenter` n=350 中位 8.9 ms；`_ensure_mask` n=350 中位 2.7 ms；`_exact_rows` n=1197 中位 30.8 ms；`_prove_fold_by_scan` n=301 中位 43.1 ms；`_prune` n=1400 中位 7.4 ms；`_scan_buffered` n=1050 中位 37.2 ms；`_scan_class` n=1561 中位 68.0 ms
- so2sat10/guangzhou/kd/single：`_fresh_mask` n=735 中位 71.2 ms
- so2sat10/guangzhou/full/single：`_close_quota` n=140 中位 102.4 ms；`_comparison` n=1400 中位 41.5 ms；`_ensure_blocks` n=7 中位 1.8 ms；`_ensure_dcenter` n=1400 中位 28.1 ms；`_ensure_mask` n=1400 中位 8.5 ms；`_exact_rows` n=1407 中位 60.3 ms；`_prove_fold_by_scan` n=700 中位 99.9 ms；`_prune` n=1400 中位 8.9 ms；`_scan_buffered` n=1400 中位 33.7 ms；`_scan_class` n=2793 中位 117.2 ms
- so2sat10/guangzhou/kd/batch：`_fresh_mask` n=735 中位 58.1 ms
- so2sat10/guangzhou/full/batch：`_close_quota` n=560 中位 143.2 ms；`_comparison` n=5600 中位 198.5 ms；`_ensure_blocks` n=7 中位 1.9 ms；`_ensure_dcenter` n=1400 中位 27.7 ms；`_ensure_mask` n=1400 中位 7.7 ms；`_exact_rows` n=4662 中位 94.2 ms；`_prove_fold_by_scan` n=1288 中位 139.1 ms；`_prune` n=5600 中位 26.7 ms；`_scan_buffered` n=4200 中位 160.6 ms；`_scan_class` n=6244 中位 222.5 ms

## 6. 正确性（计时外）

- 逐行核对：状态/可行性、每 repeat quota、有序双臂序列（unbuf/buf 的 pos/neg）、status CSV 预算、解压 payload 的行数与字节 SHA-256。
- 参考提供有序臂 ID 数组与预算；payload 由 `_payload_lines`（生产 writer 的唯一行源）从参考重建，因此字节比对检查的是参考内容 + 生产编码，而不是与另一臂互比。
- 失败/不一致：**0** 条（payload 不一致 0 条）。失败即失败，未剔除。

## 7. 口径差异说明（12 vs 8）

方案原文 E1 为 12 配置（3 城 × 2 方法 × 2 模式，matched+cold，每臂 84 条）；用户消息要求 8。`streetview/sz` 与 `so2sat43/shenzhen` 是同一城市的两套不同输入快照（不同 manifest、点数、标签规则），在冻结套件中作为两个数据集-城市单元；去掉任一城会改变冻结套件，且 2×2 无法在保留三城时得到 8。故按 12 单元执行，并在 `design.json` 中记录该差异。

## 8. 环境与限制

- 同机串行；未启动其他计时/训练任务。CPU 负载用 `GetSystemTimes` 逐行采样（本解释器无 psutil），另记进程 CPU 时间。
- 逐行机器 CPU 占用：中位 49.0%，范围 22.9%–91.9%；该机器为共享环境，不能声称无外部干扰。
- 七次重复是固定预算，不构成显著性保证；高波动只作为环境提示，不扩样、不剔除。
- 本轮 payload 占比为生产流式 writer 口径；历史缓冲 writer 的占比不可用于本轮。

## 9. 未完成项

- 无（12/12 配置、两臂各 7 条正式记录全部完成）。

