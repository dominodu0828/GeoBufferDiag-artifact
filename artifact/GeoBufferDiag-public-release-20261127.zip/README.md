# GeoBufferDiag artifact (PVLDB 2027)

This repository snapshot accompanies the manuscript in `manuscript/`. It contains the paper source and PDF, benchmark implementation, frozen coordinate/label inputs, reference outputs, and selected experiment records used in the paper.

## Data and release scope

The evaluated street-view records are sourced from Baidu Maps; the satellite-derived workloads use So2Sat LCZ42. The authors have confirmed that the evaluated derived records and their public release are permitted. This package contains frozen coordinates, labels, and reference outputs; it does not redistribute raw street-view imagery or satellite image patches.

The package supports inspection and replay of checks for which the frozen inputs and references are included. It does not include the upstream raw imagery or the full feature-extraction pipeline.

## Layout

- `manuscript/`: submitted paper source, bibliography, class/style files, figures, and PDF.
- `splitbench/`, `configs/`, `splitbench_cli.py`: benchmark code and configuration.
- `inputs/`: frozen workload snapshots used in the reported experiments.
- `ref/`: reference artifacts and expected outputs.
- `results/`: selected raw experiment records and post-review verification evidence.
- `claims/`: historical claim table and separately identified post-review addendum.
- `vendor/frozen_old/`: read-only baseline implementation and reference counts.

Machine-specific paths and private cloud links have been removed from the release copy. This clean snapshot excludes the earlier private-review archive.

## Manuscript

The authoritative manuscript PDF is `manuscript/main.pdf`; the corresponding source is `manuscript/main.tex`. The source macro `\vldbavailabilityurl` points to https://github.com/dominodu0828/GeoBufferDiag-artifact.

## Integrity

`MANIFEST.json` lists SHA-256 and byte size for every file except itself. Recompute with Python:

```bash
python -c "import hashlib,json,pathlib; m=json.loads(pathlib.Path('MANIFEST.json').read_text()); bad=[p for p,x in m['files'].items() if hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()!=x['sha256']]; print('OK' if not bad else bad)"
```




