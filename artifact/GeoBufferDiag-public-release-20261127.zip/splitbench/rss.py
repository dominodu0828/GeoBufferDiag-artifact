# -*- coding: utf-8 -*-
"""Process memory via ctypes (psutil is not installed in the frozen env).

The first P0 run recorded ``peak_rss_mb = 0.0`` for all 720 timed rows: the
call had no ``argtypes``, so the 64-bit pseudo-handle from
``GetCurrentProcess`` was truncated to 32 bits, ``GetProcessMemoryInfo``
returned 0 and the helper swallowed the failure into a 0.0 that looked like a
measurement.  The prototype is now declared explicitly and a failure returns
``None`` -- "not measured" is written as an empty cell, never as a number.

``PeakSampler`` polls the working set from a background thread for the
duration of one timed pass, so the peak belongs to that pass and not to the
lifetime of the process (a lifetime peak would be dominated by the first
configuration and would make method comparison meaningless).
"""
from __future__ import annotations

import ctypes
import threading
import time
from ctypes import wintypes


class _PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD),
                ("PageFaultCount", wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t),
                ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t),
                ("PeakPagefileUsage", ctypes.c_size_t)]


def _load():
    try:
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        fn = k32.K32GetProcessMemoryInfo
    except (AttributeError, OSError):
        try:
            psapi = ctypes.WinDLL("psapi", use_last_error=True)
            fn = psapi.GetProcessMemoryInfo
        except (AttributeError, OSError):
            return None, None
    get_current = k32.GetCurrentProcess
    get_current.argtypes = []
    get_current.restype = wintypes.HANDLE
    fn.argtypes = [wintypes.HANDLE, ctypes.POINTER(_PROCESS_MEMORY_COUNTERS),
                   wintypes.DWORD]
    fn.restype = wintypes.BOOL
    return fn, get_current


_GET_INFO, _GET_CURRENT = _load()


def _counters():
    if _GET_INFO is None:
        return None
    pmc = _PROCESS_MEMORY_COUNTERS()
    pmc.cb = ctypes.sizeof(_PROCESS_MEMORY_COUNTERS)
    if not _GET_INFO(_GET_CURRENT(), ctypes.byref(pmc), pmc.cb):
        return None
    return pmc


def working_set_mb():
    """Current working set in MiB, or None when the query fails."""
    pmc = _counters()
    return None if pmc is None else pmc.WorkingSetSize / (1024.0 * 1024.0)


def peak_working_set_mb():
    """Process-lifetime peak working set in MiB, or None when the query fails."""
    pmc = _counters()
    return None if pmc is None else pmc.PeakWorkingSetSize / (1024.0 * 1024.0)


class PeakSampler:
    """Sample the working set of this process for the span of one pass.

    ``stop()`` returns ``(peak_mb, n_samples)``; both are ``None``/``0`` when
    the platform query is unavailable, which the bench records as missing."""

    def __init__(self, interval: float = 0.005):
        self.interval = float(interval)
        self._peak = None
        self._n = 0
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        while not self._stop.is_set():
            v = working_set_mb()
            if v is not None:
                self._n += 1
                if self._peak is None or v > self._peak:
                    self._peak = v
            self._stop.wait(self.interval)

    def start(self):
        if _GET_INFO is None:
            return self
        self._thread.start()
        return self

    def stop(self):
        if _GET_INFO is None:
            return None, 0
        self._stop.set()
        self._thread.join(timeout=2.0)
        return self._peak, self._n
