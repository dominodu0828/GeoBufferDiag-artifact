# -*- coding: utf-8 -*-
"""Gate B mechanism profiling (06 work order sec. 9.4).

Mutually exclusive parents and nested breakdowns
------------------------------------------------
Every profiled run records ONE mutually exclusive parent decomposition

    total = read + index + quota + select + payload_write + status_write
            + unattributed

plus nested breakdowns that are strictly subsets of their parent and are
never added on top of them:

    block_center            subset of index      (candidate engines)
    point_query[stage]      subset of index (B1) / quota / select (candidate)
    interval_close          subset of quota      (candidate, = closing logic
                             minus its inner point queries and rank scans)
    rank_scan[stage]        subset of quota / select (candidate)
    payload_encode + payload_compress + payload_filewrite = payload_write

A row is rejected (the whole profile aborts) unless the parent sum closes
within 1 ms and every breakdown stays inside its parent.  B1's NN distance
materialisation is attributed to ``index`` (its structure build); the raw
production phases (exact/quota/select of the engines) travel in
``counters_json`` for traceability.

Instrumentation is uniform: every method runs the same instrumented
subclass of its production engine (wrappers only accumulate time around
``super()`` calls); a separate control pass runs the production engines
with no timing hooks.  Instrumented-vs-control comparisons therefore never
cross instrumentation versions.

Scope: three cities (so2sat43/shenzhen, streetview/sz, so2sat10/guangzhou),
methods b1/b1b/c1/c2/c, loads single/batch x matched, cold primary, warm
(single) secondary.  Config order is randomised with a pre-recorded seed
and kept interleaved; the formal repetition count is frozen from a 2-rep
pretrial (spread rule recorded in profile_manifest.json).
"""
from __future__ import annotations

import argparse
import csv as _csv
import gzip
import hashlib
import json
import tempfile
import random
import statistics
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

from .baseline_b1 import B1Engine
from .candidate import CandidateEngine
from .settings import suite_cities
from .verifylib import load_city_inputs
from .writers import _payload_lines, write_outputs, write_status

PARENTS = ("read", "index", "quota", "select", "payload_write",
           "status_write")
SUB_OF_PARENT = {
    "block_center": "index",
    "point_query": None,        # stage-aware: index (b1) / quota / select
    "interval_close": "quota",
    "rank_scan": None,          # stage-aware: quota / select
    "payload_encode": "payload_write",
    "payload_compress": "payload_write",
    "payload_filewrite": "payload_write",
}
DEFAULT_SCOPE = [("so2sat43", "shenzhen"), ("streetview", "sz"),
                 ("so2sat10", "guangzhou")]
DEFAULT_METHODS = ("b1", "b1b", "c1", "c2", "c")
_EPS_MS = 1.0                 # parent-closure tolerance (ms)
HIST_BUCKETS = ((1, 1), (2, 10), (11, 100), (101, 1000), (1001, 4096),
                (4097, None))


def _bucket(n):
    for lo, hi in HIST_BUCKETS:
        if n >= lo and (hi is None or n <= hi):
            return "%d-%s" % (lo, hi if hi is not None else "inf")
    return "out"


class ProfileRec:
    """Accumulates one run's parents, nested breakdowns and workload."""

    def __init__(self):
        self.parents = {k: 0.0 for k in PARENTS}
        self.subs = defaultdict(float)          # (name, stage) -> ms
        self.point_calls = defaultdict(int)     # stage -> calls
        self.point_positions = defaultdict(int)  # stage -> queried positions
        self.hist = defaultdict(int)            # bucket -> count
        self.n_interval_collapses = 0
        self.scope = []                         # nested-subtraction stack
        self.trace = None                       # list when tracing
        self.t0 = time.perf_counter()

    # -- scopes (innermost frame accumulates child time) -----------------
    def push(self):
        self.scope.append({"child": 0.0})

    def pop_child(self):
        return self.scope.pop()["child"]

    def charge_child(self, ms):
        if self.scope:
            self.scope[-1]["child"] += ms

    # -- parents ----------------------------------------------------------
    def parent(self, name, ms):
        self.parents[name] += ms

    # -- breakdowns --------------------------------------------------------
    def point_query(self, stage, ms, positions):
        self.subs[("point_query", stage)] += ms
        self.point_calls[stage] += 1
        self.point_positions[stage] += positions
        self.hist[_bucket(positions)] += 1
        self.charge_child(ms)

    def block_center(self, ms, positions):
        self.subs[("block_center", "index")] += ms
        self.charge_child(ms)

    def rank_scan(self, stage, ms):
        # record only -- the wrapper propagates the full wall (own + all
        # nested costs) to the enclosing scope, so a parent's subtraction
        # removes every nested cost exactly once
        self.subs[("rank_scan", stage)] += ms

    def interval_close(self, ms, collapses):
        self.subs[("interval_close", "quota")] += ms
        self.n_interval_collapses += collapses

    def payload(self, encode, compress, filewrite):
        self.subs[("payload_encode", "payload_write")] += encode
        self.subs[("payload_compress", "payload_write")] += compress
        self.subs[("payload_filewrite", "payload_write")] += filewrite

    # -- closure -----------------------------------------------------------
    def close(self, total_ms):
        parents_sum = sum(self.parents.values())
        unattr = total_ms - parents_sum
        return unattr, parents_sum

    def violations(self, total_ms):
        """Parent/breakdown closure checks.

        ``unattributed`` legitimately absorbs threadpool enter/exit, the
        cold-first class-orders build (inside the engines, before their
        phase clocks), sampler bookkeeping and misc control -- it only has
        to stay non-negative and within a sane share of the total."""
        bad = []
        parents_sum = sum(self.parents.values())
        unattr = total_ms - parents_sum
        if unattr < -_EPS_MS:
            bad.append("parents exceed total: sum %.2f vs total %.2f"
                       % (parents_sum, total_ms))
        if unattr > 0.90 * total_ms:
            bad.append("unattributed %.2f exceeds 90%% of total %.2f "
                       "(accounting broken)" % (unattr, total_ms))
        for (name, stage), v in self.subs.items():
            p = SUB_OF_PARENT.get(name)
            if p is None:
                p = stage if stage in PARENTS else None
            if p is not None and v > self.parents[p] + _EPS_MS:
                bad.append("sub %s[%s]=%.2f exceeds parent %s=%.2f"
                           % (name, stage, v, p, self.parents[p]))
        pq = sum(v for (n, _), v in self.subs.items() if n == "point_query")
        if pq > 0 and self.subs.get(("point_query", "index"), 0) + \
                self.subs.get(("point_query", "quota"), 0) + \
                self.subs.get(("point_query", "select"), 0) - pq > _EPS_MS:
            bad.append("point_query stage split does not close")
        for p in ("payload_write",):
            s = sum(v for (n, st), v in self.subs.items() if st == p)
            if s > self.parents[p] + _EPS_MS:
                bad.append("payload subs %.2f exceed payload_write %.2f"
                           % (s, self.parents[p]))
        return bad


# ---------------------------------------------------------------------------
# instrumented engines (uniform wrappers; super() does all real work)
# ---------------------------------------------------------------------------
class _ProfB1(B1Engine):
    """point_query = wall of the distance-array materialisation calls
    (fresh / extended), attributed to the index parent."""

    def __init__(self, bounded=False, rec=None, trace=None):
        super().__init__(bounded=bounded)
        self._rec = rec
        self._trace = trace

    def _fresh_mask(self, xy, te, tree, cand, rmax, radii, counters):
        if self._rec is None:
            return super()._fresh_mask(xy, te, tree, cand, rmax, radii,
                                       counters)
        t0 = time.perf_counter()
        r = super()._fresh_mask(xy, te, tree, cand, rmax, radii, counters)
        self._rec.point_query("index", (time.perf_counter() - t0) * 1000.0,
                              int(len(cand)))
        return r

    def _extend_mask(self, xy, te, m, rmax, radii, counters):
        if self._rec is None:
            return super()._extend_mask(xy, te, m, rmax, radii, counters)
        t0 = time.perf_counter()
        r = super()._extend_mask(xy, te, m, rmax, radii, counters)
        trunc = int((~np.isfinite(m["d"])).sum())
        self._rec.point_query("index", (time.perf_counter() - t0) * 1000.0,
                              trunc)
        return r


class _ProfCand(CandidateEngine):
    """Uniform instrumentation of the candidate engines."""

    def __init__(self, arm="c", side=1000.0, margin=1e-6, batch_rows=4096,
                 policy="priority", rec=None, trace=None):
        super().__init__(arm=arm, side=side, margin=margin,
                         batch_rows=batch_rows, policy=policy)
        self._rec = rec
        self._trace = trace

    def _ensure_dcenter(self, ct, key, te, m, blocks, counters):
        if self._rec is None:
            return super()._ensure_dcenter(ct, key, te, m, blocks, counters)
        t0 = time.perf_counter()
        r = super()._ensure_dcenter(ct, key, te, m, blocks, counters)
        self._rec.block_center((time.perf_counter() - t0) * 1000.0,
                               int(counters.get("n_block_center_queries", 0)))
        return r

    def _exact_rows(self, ct, key, te, m, rows, counters, stage="select"):
        if self._rec is None:
            return super()._exact_rows(ct, key, te, m, rows, counters, stage)
        rows = np.asarray(rows)
        if len(rows):
            unknown = int((~np.isfinite(m["d_arr"][rows])).sum())
        else:
            unknown = 0
        t0 = time.perf_counter()
        r = super()._exact_rows(ct, key, te, m, rows, counters, stage)
        self._rec.point_query(stage, (time.perf_counter() - t0) * 1000.0,
                              unknown)
        return r

    def _scan_class(self, ct, key, te, m, radius, oi, q, row_status,
                    counters, stage="select"):
        if self._rec is None:
            return super()._scan_class(ct, key, te, m, radius, oi, q,
                                       row_status, counters, stage)
        self._rec.push()
        t0 = time.perf_counter()
        r = super()._scan_class(ct, key, te, m, radius, oi, q, row_status,
                                counters, stage)
        wall = (time.perf_counter() - t0) * 1000.0
        child = self._rec.pop_child()
        # record the scan's own time (wall minus its inner point queries)
        # and propagate the FULL wall to the enclosing scope
        self._rec.rank_scan(stage, wall - child)
        self._rec.charge_child(wall)
        return r

    def _close_quota(self, ct, state, radius, floor, fold_keys, intervals,
                     counters):
        if self._rec is None:
            return super()._close_quota(ct, state, radius, floor, fold_keys,
                                        intervals, counters)
        self._rec.push()
        before = sum(1 for v in intervals.values()
                     if v[0] == v[1] and v[2] == v[3])
        t0 = time.perf_counter()
        r = super()._close_quota(ct, state, radius, floor, fold_keys,
                                 intervals, counters)
        wall = (time.perf_counter() - t0) * 1000.0
        child = self._rec.pop_child()
        after = sum(1 for v in intervals.values()
                    if v[0] == v[1] and v[2] == v[3])
        # closing logic proper = wall minus its inner point queries and
        # rank scans (both recorded in their own breakdowns); propagate
        # the full wall to the enclosing scope
        self._rec.interval_close(wall - child, after - before)
        self._rec.charge_child(wall)
        return r

    def _prove_fold_by_scan(self, ct, key, te, m, radius, row_status,
                            bound_pos, bound_neg, counters):
        r = super()._prove_fold_by_scan(ct, key, te, m, radius, row_status,
                                        bound_pos, bound_neg, counters)
        if self._trace is not None:
            self._trace.append({
                "key": list(key) if isinstance(key, tuple) else key,
                "radius": radius, "bound_pos": bound_pos,
                "bound_neg": bound_neg,
                "interval": list(r),
                "collapsed": bool(r[0] == r[1] and r[2] == r[3])})
        return r


def _mk_engine(method, rec=None, trace=None):
    if method == "b1":
        return _ProfB1(rec=rec, trace=trace)
    if method == "b1b":
        return _ProfB1(bounded=True, rec=rec, trace=trace)
    side, margin, batch = 1000.0, 1e-6, 4096
    arm = {"c1": "c1", "c2": "c2", "c": "c"}[method]
    policy = "priority"
    return _ProfCand(arm=arm, side=side, margin=margin, batch_rows=batch,
                     policy=policy, rec=rec, trace=trace)


def _mk_control(method):
    if method == "b1":
        return B1Engine()
    if method == "b1b":
        return B1Engine(bounded=True)
    arm = {"c1": "c1", "c2": "c2", "c": "c"}[method]
    return CandidateEngine(arm=arm, side=1000.0, margin=1e-6, batch_rows=4096,
                          policy="priority")


def _radius_list(cfg, mode):
    sweep = [float(r) for r in cfg["radii"]["sweep"]]
    primary = {k: float(v) for k, v in cfg["radii"]["primary"].items()}
    return {"single": None, "batch": sweep}      # single resolved per city


def write_payload_split(path: Path, ct, folds, res, output, rec=None):
    """Profile split writer: encode (render, join and UTF-8), compress (gzip), file
    write -- three timed steps sharing ``writers._payload_lines`` with the
    production writer.  Used by BOTH arms (instrumented and control) so the
    two never differ in write implementation; only the hooks differ.
    Returns (rows, bytes, decompressed_bytes)."""
    t0 = time.perf_counter()
    lines = list(_payload_lines(ct, folds, res, output))
    data = "".join(lines).encode("utf-8")
    encode = (time.perf_counter() - t0) * 1000.0
    t1 = time.perf_counter()
    comp = gzip.compress(data, compresslevel=6, mtime=0)
    tc = (time.perf_counter() - t1) * 1000.0
    t2 = time.perf_counter()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(comp)
    tf = (time.perf_counter() - t2) * 1000.0
    if rec is not None:
        rec.payload(encode, tc, tf)
    return len(lines), len(comp), data, (encode, tc, tf)


def check_writer_contract(ct, folds, res, radii, method, output, profile_root,
                          profile_rows):
    """Compare the current result's profile files with production outside timing."""
    name = "%s__%s__%s" % (ct.dataset, ct.city, output)
    profile_payload = profile_root / "out" / method / (name + ".csv.gz")
    profile_status = profile_root / "out" / method / (name + "__status.csv")
    with tempfile.TemporaryDirectory(prefix="writer-check-") as tmp:
        root = Path(tmp)
        production_rows, _, _ = write_outputs(root, method, ct, folds, res, output)
        status_path, production_status_rows = write_status(
            root, method, ct, folds, res, radii, output)
        production_payload = root / "out" / method / (name + ".csv.gz")
        with gzip.open(profile_payload, "rb") as fh:
            actual = fh.read()
        with gzip.open(production_payload, "rb") as fh:
            expected = fh.read()
        actual_status = profile_status.read_bytes()
        expected_status = status_path.read_bytes()
        with profile_status.open(newline="", encoding="utf-8") as fh:
            profile_status_rows = sum(1 for _ in _csv.DictReader(fh))
        expected_rows = (1 + 2 * sum(len(v) for v in res.matched.values())
                         if output in ("matched", "audit") else
                         1 + sum(len(v) for v in res.stats.values()))
        expected_status_rows = sum(
            max(len(res.quota.get(float(r)) or []), folds.n_repeats, 0)
            for r in set(radii))
        checks = {
            "payload_match": actual == expected,
            "status_match": actual_status == expected_status,
            "payload_count_match": (profile_rows == production_rows ==
                                    len(actual.splitlines()) == expected_rows),
            "status_count_match": (profile_status_rows == production_status_rows
                                   == expected_status_rows),
        }
        return {**checks, "profile_rows": profile_rows,
                "production_rows": production_rows,
                "expected_rows": expected_rows,
                "profile_status_rows": profile_status_rows,
                "production_status_rows": production_status_rows,
                "expected_status_rows": expected_status_rows,
                "payload_sha256": hashlib.sha256(actual).hexdigest(),
                "production_payload_sha256": hashlib.sha256(expected).hexdigest(),
                "status_sha256": hashlib.sha256(actual_status).hexdigest(),
                "production_status_sha256": hashlib.sha256(expected_status).hexdigest()}


# ---------------------------------------------------------------------------
def _one_instrumented_run(cfg, run_dir, ct, folds, radii, method, mode,
                          variant, state, out_dir, trace=None):
    """One profiled pass; returns (row_dict, state, res)."""
    rec = ProfileRec()
    t_start = time.perf_counter()
    ms_read = 0.0
    if variant == "cold":
        t0 = time.perf_counter()
        ct, folds = load_city_inputs(run_dir, ct.dataset, ct.city)
        ms_read = (time.perf_counter() - t0) * 1000.0
    t0 = time.perf_counter()
    tp = threadpool_limits(limits=1)
    ms_tp_enter = (time.perf_counter() - t0) * 1000.0
    sampler = __import__("splitbench.rss", fromlist=["rss"]).PeakSampler(
        interval=0.002).start()
    try:
        eng = _mk_engine(method, rec=rec, trace=trace)
        t0 = time.perf_counter()
        res, st = eng.run_city(ct, folds, radii, "matched", state=state)
        eng_wall = (time.perf_counter() - t0) * 1000.0
        # parent attribution from the production phase clocks
        if method in ("b1", "b1b"):
            rec.parent("index", res.phases.index * 1000.0
                       + res.phases.exact * 1000.0)
        else:
            rec.parent("index", res.phases.index * 1000.0)
            assert res.phases.exact == 0.0, "matched must not exact for audit"
        rec.parent("quota", res.phases.quota * 1000.0)
        rec.parent("select", res.phases.select * 1000.0)
        # out_dir is a synthetic run dir: writers append out/<method>/
        out_path = out_dir / "out" / method / ("%s__%s__matched.csv.gz"
                                               % (ct.dataset, ct.city))
        rows_out, bytes_out, data, _ = write_payload_split(
            out_path, ct, folds, res, "matched", rec)
        rec.parent("payload_write",
                   rec.subs[("payload_encode", "payload_write")]
                   + rec.subs[("payload_compress", "payload_write")]
                   + rec.subs[("payload_filewrite", "payload_write")])
        t0 = time.perf_counter()
        write_status(out_dir, eng.name, ct, folds, res, radii, "matched")
        rec.parent("status_write", (time.perf_counter() - t0) * 1000.0)
    finally:
        t0 = time.perf_counter()
        tp.unregister()
        ms_tp_exit = (time.perf_counter() - t0) * 1000.0
    peak, n_samples = sampler.stop()
    total_ms = (time.perf_counter() - t_start) * 1000.0
    rec.parent("read", ms_read)
    unattr, psum = rec.close(total_ms)
    bad = rec.violations(total_ms)
    row = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "dataset": ct.dataset, "city": ct.city, "mode": mode,
        "output": "matched", "method": eng.name, "variant": variant,
        "instrumented": "True",
        "feasible": str(all(res.status[r]["feasible"] for r in radii)),
        "ms_read": round(ms_read, 3),
        "ms_index": round(rec.parents["index"], 3),
        "ms_quota": round(rec.parents["quota"], 3),
        "ms_select": round(rec.parents["select"], 3),
        "ms_payload_write": round(rec.parents["payload_write"], 3),
        "ms_status_write": round(rec.parents["status_write"], 3),
        "ms_total": round(total_ms, 3),
        "ms_unattributed": round(unattr, 3),
        "ms_tp_enter": round(ms_tp_enter, 3),
        "ms_tp_exit": round(ms_tp_exit, 3),
        "sub_block_center": round(rec.subs.get(("block_center", "index"),
                                               0.0), 3),
        "sub_point_query": round(sum(v for (n, _), v in rec.subs.items()
                                     if n == "point_query"), 3),
        "sub_point_query_index": round(rec.subs.get(("point_query", "index"),
                                                    0.0), 3),
        "sub_point_query_quota": round(rec.subs.get(("point_query", "quota"),
                                                    0.0), 3),
        "sub_point_query_select": round(rec.subs.get(("point_query",
                                                      "select"), 0.0), 3),
        "sub_interval_close": round(rec.subs.get(("interval_close", "quota"),
                                                 0.0), 3),
        "sub_rank_scan": round(sum(v for (n, _), v in rec.subs.items()
                                   if n == "rank_scan"), 3),
        "sub_rank_scan_quota": round(rec.subs.get(("rank_scan", "quota"),
                                                  0.0), 3),
        "sub_rank_scan_select": round(rec.subs.get(("rank_scan", "select"),
                                                   0.0), 3),
        "sub_payload_encode": round(rec.subs.get(("payload_encode",
                                                  "payload_write"), 0.0), 3),
        "sub_payload_compress": round(rec.subs.get(("payload_compress",
                                                    "payload_write"), 0.0),
                                      3),
        "sub_payload_filewrite": round(rec.subs.get(("payload_filewrite",
                                                     "payload_write"), 0.0),
                                       3),
        "point_calls_json": json.dumps({k: v for k, v in
                                        rec.point_calls.items()}),
        "point_positions_json": json.dumps({k: v for k, v in
                                            rec.point_positions.items()}),
        "batch_hist_json": json.dumps(dict(rec.hist)),
        "n_interval_collapses": rec.n_interval_collapses,
        "rows_out": rows_out, "bytes_out": bytes_out,
        "peak_rss_mb": round(peak, 1) if peak is not None else "",
        "rss_samples": n_samples,
        "engine_wall_ms": round(eng_wall, 3),
        "payload_equal_control": "",
        "assert_violations": "|".join(bad),
        "counters_json": json.dumps({**res.counters,
                                     "phase_raw": res.phases.as_dict()}),
    }
    return row, st, res


def _one_control_run(cfg, run_dir, ct, folds, radii, method, mode, variant,
                     state, out_dir):
    """Control pass: production engine and split writer without profile hooks."""
    t_start = time.perf_counter()
    ms_read = 0.0
    if variant == "cold":
        t0 = time.perf_counter()
        ct, folds = load_city_inputs(run_dir, ct.dataset, ct.city)
        ms_read = (time.perf_counter() - t0) * 1000.0
    t0 = time.perf_counter()
    tp = threadpool_limits(limits=1)
    ms_tp_enter = (time.perf_counter() - t0) * 1000.0
    sampler = __import__("splitbench.rss", fromlist=["rss"]).PeakSampler(
        interval=0.002).start()
    try:
        eng = _mk_control(method)
        res, st = eng.run_city(ct, folds, radii, "matched", state=state)
        # SAME split writer as the instrumented arm (no hooks): the two
        # arms differ only in instrumentation, never in write impl
        out_path = out_dir / "out" / eng.name / (
            "%s__%s__matched.csv.gz" % (ct.dataset, ct.city))
        rows_out, bytes_out, _, (enc, comp, fw) = write_payload_split(
            out_path, ct, folds, res, "matched")
        t0s = time.perf_counter()
        write_status(out_dir, eng.name, ct, folds, res, radii, "matched")
        status_write = (time.perf_counter() - t0s) * 1000.0
    finally:
        t0 = time.perf_counter()
        tp.unregister()
        ms_tp_exit = (time.perf_counter() - t0) * 1000.0
    peak, n_samples = sampler.stop()
    total_ms = (time.perf_counter() - t_start) * 1000.0
    if method in ("b1", "b1b"):
        index = res.phases.index + res.phases.exact
    else:
        index = res.phases.index
    payload_write = enc + comp + fw
    row = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "dataset": ct.dataset, "city": ct.city, "mode": mode,
        "output": "matched", "method": eng.name, "variant": variant,
        "instrumented": "False",
        "feasible": str(all(res.status[r]["feasible"] for r in radii)),
        "ms_read": round(ms_read, 3),
        "ms_index": round(index * 1000.0, 3),
        "ms_quota": round(res.phases.quota * 1000.0, 3),
        "ms_select": round(res.phases.select * 1000.0, 3),
        "ms_payload_write": round(payload_write, 3),
        "ms_status_write": round(status_write, 3),
        "ms_total": round(total_ms, 3),
        "ms_unattributed": round(total_ms - (ms_read + index * 1000.0
                                             + res.phases.quota * 1000.0
                                             + res.phases.select * 1000.0
                                             + payload_write
                                             + status_write), 3),
        "ms_tp_enter": round(ms_tp_enter, 3),
        "ms_tp_exit": round(ms_tp_exit, 3),
        "sub_block_center": "", "sub_point_query": "",
        "sub_point_query_index": "", "sub_point_query_quota": "",
        "sub_point_query_select": "", "sub_interval_close": "",
        "sub_rank_scan": "", "sub_rank_scan_quota": "",
        "sub_rank_scan_select": "", "sub_payload_encode": "",
        "sub_payload_compress": "", "sub_payload_filewrite": "",
        "point_calls_json": "", "point_positions_json": "",
        "batch_hist_json": "", "n_interval_collapses": "",
        "rows_out": rows_out, "bytes_out": bytes_out,
        "peak_rss_mb": round(peak, 1) if peak is not None else "",
        "rss_samples": n_samples,
        "engine_wall_ms": "",
        "payload_equal_control": "",
        "assert_violations": "",
        "counters_json": json.dumps({**res.counters,
                                     "phase_raw": res.phases.as_dict()}),
    }
    return row, st, res


COLS = ["ts", "dataset", "city", "mode", "output", "method", "variant",
        "instrumented", "feasible", "ms_read", "ms_index", "ms_quota",
        "ms_select", "ms_payload_write", "ms_status_write", "ms_total",
        "ms_unattributed", "ms_tp_enter", "ms_tp_exit",
        "sub_block_center", "sub_point_query",
        "sub_point_query_index", "sub_point_query_quota",
        "sub_point_query_select", "sub_interval_close", "sub_rank_scan",
        "sub_rank_scan_quota", "sub_rank_scan_select", "sub_payload_encode",
        "sub_payload_compress", "sub_payload_filewrite", "point_calls_json",
        "point_positions_json", "batch_hist_json", "n_interval_collapses",
        "rows_out", "bytes_out", "peak_rss_mb", "rss_samples",
        "engine_wall_ms", "payload_equal_control", "assert_violations",
        "counters_json"]


def run_memory_children(run_dir: Path, configs):
    """One isolated subprocess per cold matched config (9.4.4)."""
    import subprocess
    from .settings import ROOT
    child = ROOT / "splitbench" / "profile_memchild.py"
    mem_rows = []
    for ds, city, mode, m, variant in configs:
        if variant != "cold":
            continue
        out = subprocess.run(
            [sys.executable, "-B", str(child), "--run", str(run_dir),
             "--dataset", ds, "--city", city, "--method", m,
             "--mode", mode],
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=600)
        line = [ln for ln in out.stdout.splitlines() if ln.startswith("{")]
        if out.returncode != 0 or not line:
            mem_rows.append({"dataset": ds, "city": city, "mode": mode,
                             "method": m, "variant": variant,
                             "status": "child_failed rc=%d %s"
                             % (out.returncode, out.stderr[-200:])})
            continue
        j = json.loads(line[-1])
        j.update({"dataset": ds, "city": city, "mode": mode, "method": m,
                  "variant": variant, "status": "ok"})
        mem_rows.append(j)
    return mem_rows


def run_profile(cfg, run_dir: Path, cities=None, methods=None, seed=20261120,
                reps=None, with_memory=True, with_trace=True) -> dict:
    """Full Gate B protocol; writes profile_breakdown.csv, the control
    pass, profile_overhead.csv, memory_isolated.csv, scheduler_trace.jsonl
    and profile_manifest.json."""
    from .settings import ROOT
    if any((run_dir / name).exists() for name in
           ("profile_breakdown.csv", "profile_manifest.json",
            "profile_overhead.csv", "profile_writer_checks.jsonl")):
        raise FileExistsError("profile artifacts already exist in %s" % run_dir)
    scope = cities or DEFAULT_SCOPE
    methods = methods or DEFAULT_METHODS
    manifest = {"run_id": run_dir.name, "scope": ["%s/%s" % c for c in scope],
                "methods": list(methods), "seed": seed,
                "engine_cfg": {"block_grid_side_m": 1000.0,
                               "scan_batch_rows": 4096,
                               "block_float_margin_m": 1e-6},
                "loads": ["single/matched", "batch/matched"],
                "variants": ["cold", "warm(single only)"]}

    cities_data = {}
    for ds, city in scope:
        cities_data[(ds, city)] = load_city_inputs(run_dir, ds, city)

    configs = []
    for ds, city in scope:
        primary = float(cfg["radii"]["primary"][ds])
        for m in methods:
            for mode in ("single", "batch"):
                configs.append((ds, city, mode, m, "cold"))
                if mode == "single":
                    configs.append((ds, city, mode, m, "warm"))
    rng = random.Random(seed)
    rng.shuffle(configs)
    manifest["config_order_first5"] = configs[:5]

    def radii_for(ds, mode):
        if mode == "single":
            return [float(cfg["radii"]["primary"][ds])]
        return [float(r) for r in cfg["radii"]["sweep"]]

    out_root = run_dir / "out" / "profile"
    ctrl_root = run_dir / "out" / "profile_control"
    trace_path = run_dir / "scheduler_trace.jsonl"
    writer_path = run_dir / "profile_writer_checks.jsonl"
    if writer_path.exists():
        raise FileExistsError("writer checks already exist: %s" % writer_path)
    writer_checks = []

    def one_pass(rep_label, instrumented, states, warmup=False):
        rows = []
        for ds, city, mode, m, variant in configs:
            ct, folds = cities_data[(ds, city)]
            key = (ds, city, mode, m, variant)
            radii = radii_for(ds, mode)
            state = None if variant == "cold" else states.get(key)
            if instrumented:
                trace = [] if (with_trace and m in ("c2", "c")) else None
                row, st, res = _one_instrumented_run(
                    cfg, run_dir, ct, folds, radii, m, mode, variant, state,
                    out_root, trace=trace)
                if trace is not None and not warmup:
                    for t in trace:
                        t.update({"rep": rep_label, "dataset": ds,
                                  "city": city, "mode": mode, "method": m})
                        trace_path.open("a", encoding="utf-8").write(
                            json.dumps(t) + "\n")
                if variant == "warm":
                    states[key] = st
            else:
                row, st, res = _one_control_run(
                    cfg, run_dir, ct, folds, radii, m, mode, variant, state,
                    ctrl_root)
                if variant == "warm":
                    states[key] = st
            row["rep"] = rep_label
            checked = check_writer_contract(
                ct, folds, res, radii, row["method"], "matched",
                out_root if instrumented else ctrl_root, row["rows_out"])
            record = {"dataset": ds, "city": city, "mode": mode,
                      "method": m, "variant": variant, "output": "matched",
                      "radii": radii, "rep": rep_label,
                      "instrumented": instrumented, **checked}
            writer_checks.append(record)
            with writer_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, ensure_ascii=False) + "\n")
            if not all(checked[k] for k in ("payload_match", "status_match",
                                           "payload_count_match", "status_count_match")):
                raise AssertionError("writer contract failed: %s" % record)
            rows.append(row)
        return rows

    # -- pass sequence -----------------------------------------------------
    # warmup (builds warm states, discarded) -> 2-rep pretrial (labels
    # pre1/pre2, decides the formal repetition count) -> formal instrumented
    # reps -> control warmup -> formal control reps.  Overhead medians use
    # formal rows only; pre/warmup rows stay in the CSV for auditability.
    rows_all = []
    states_warm = {}
    rows_all += one_pass("warmup", True, states_warm, warmup=True)
    pre_rows = []
    for rep in (1, 2):
        pre_rows += one_pass("pre%d" % rep, True, states_warm)
    rows_all += pre_rows
    spreads = {}
    by_cfg = defaultdict(list)
    for r in pre_rows:
        by_cfg[(r["dataset"], r["city"], r["mode"], r["method"],
                r["variant"])].append(float(r["ms_total"]))
    for k, vs in by_cfg.items():
        med_v = sorted(vs)[len(vs) // 2]
        spreads["%s/%s/%s/%s/%s" % k] = ((max(vs) - min(vs)) / med_v
                                         if med_v else 0)
    if reps is None:
        reps = 5 if max(spreads.values()) < 0.15 else 7
    manifest["pretrial_spread_max"] = round(max(spreads.values()), 4)
    manifest["pretrial_spread_p95"] = round(sorted(spreads.values())[
        int(0.95 * (len(spreads) - 1))], 4)
    manifest["reps_frozen"] = reps
    manifest["reps_rule"] = "5 if pretrial max spread < 0.15 else 7"
    manifest["pretrial_worst"] = sorted(spreads.items(), key=lambda kv:
                                        -kv[1])[:3]

    # formal passes: instrumented and control ALTERNATE per repetition so
    # machine drift (thermal/load) hits both arms symmetrically
    states_ctrl = {}
    rows_all += one_pass("warmup", False, states_ctrl, warmup=True)
    formal, formal_ctrl = [], []
    for rep in range(1, reps + 1):
        formal += one_pass(str(rep), True, states_warm)
        formal_ctrl += one_pass(str(rep), False, states_ctrl)
    rows_all += formal + formal_ctrl
    manifest["arm_interleaving"] = "instrumented and control alternate per repetition"

    formal_labels = {str(i) for i in range(1, reps + 1)}
    violations = [(r["dataset"], r["city"], r["mode"], r["method"],
                   r["variant"], r["rep"], r["assert_violations"])
                  for r in rows_all
                  if r["assert_violations"] and r["rep"] in formal_labels]
    soft = [(r["dataset"], r["city"], r["mode"], r["method"], r["variant"],
             r["rep"], r["assert_violations"])
            for r in rows_all
            if r["assert_violations"] and r["rep"] not in formal_labels]
    if violations:
        raise AssertionError("parent/breakdown closure violations: %s"
                             % violations[:5])
    manifest["soft_violations_warmup_pre"] = len(soft)

    breakdown = run_dir / "profile_breakdown.csv"
    with breakdown.open("w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=["rep"] + COLS)
        w.writeheader()
        for r in rows_all:
            w.writerow(r)

    # -- overhead table (formal rows only; warmup/pre excluded) ------------
    formal_inst = [r for r in formal]
    formal_ctl = [r for r in formal_ctrl]

    def med(rows):
        vs = [float(r["ms_total"]) for r in rows]
        return statistics.median(vs)

    oh_rows = []
    for ds, city, mode, m, variant in configs:
        k = (ds, city, mode, m, variant)
        inst = [r for r in formal_inst
                if (r["dataset"], r["city"], r["mode"], r["method"],
                    r["variant"]) == k]
        ctrl = [r for r in formal_ctl
                if (r["dataset"], r["city"], r["mode"], r["method"],
                    r["variant"]) == k]
        if not inst or not ctrl:
            continue
        mi, mc = med(inst), med(ctrl)
        ci = json.loads(inst[-1]["counters_json"])
        cc = json.loads(ctrl[-1]["counters_json"])
        counters_match = all(ci.get(k2) == cc.get(k2) for k2 in cc
                             if not k2.startswith("phase_"))
        checks = [r for r in writer_checks
                  if (r["dataset"], r["city"], r["mode"], r["method"],
                      r["variant"]) == k and r["rep"] in formal_labels]
        if len(checks) != 2 * reps:
            raise AssertionError("missing per-arm writer checks for %s" % (k,))
        payload_match = str(all(r["payload_match"] and r["status_match"]
                                and r["payload_count_match"]
                                and r["status_count_match"] for r in checks))
        oh_rows.append({
            "dataset": ds, "city": city, "mode": mode, "method": m,
            "variant": variant,
            "median_instrumented_ms": round(mi, 2),
            "median_control_ms": round(mc, 2),
            "overhead_ratio": round(mi / mc, 4) if mc else "",
            "counters_match": str(counters_match),
            "payload_match": payload_match,
            "reps": len(inst)})
    overhead = run_dir / "profile_overhead.csv"
    with overhead.open("w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=list(oh_rows[0].keys()))
        w.writeheader()
        for r in oh_rows:
            w.writerow(r)

    # -- isolated memory (one subprocess per cold matched config) ----------
    mem_rows = run_memory_children(run_dir, configs) if with_memory else []
    memory_csv = run_dir / "memory_isolated.csv"
    mem_cols = ["dataset", "city", "mode", "method", "variant", "status",
                "baseline_rss_mb", "pre_rss_mb", "peak_rss_mb",
                "pre_exit_rss_mb", "interval_ms", "samples", "ms_total",
                "bytes_out"]
    with memory_csv.open("w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=mem_cols, extrasaction="ignore")
        w.writeheader()
        for r in mem_rows:
            w.writerow({k: (round(r[k], 1) if isinstance(r.get(k), float)
                            else r.get(k, "")) for k in mem_cols})

    manifest["writer_checks"] = len(writer_checks)
    manifest["writer_checks_file"] = writer_path.name
    manifest["writer_check_scope"] = "each pass, each arm, same result; outside timing"
    manifest["rows_breakdown"] = len(rows_all)
    manifest["violations"] = 0
    manifest["trace_entries"] = (sum(1 for _ in
                                     trace_path.open(encoding="utf-8"))
                                 if trace_path.exists() else 0)
    (run_dir / "profile_manifest.json").write_text(
        json.dumps(manifest, indent=1, ensure_ascii=False), encoding="utf-8")
    return {"manifest": manifest, "overhead": oh_rows, "memory": mem_rows,
            "breakdown_csv": str(breakdown)}


def main(argv=None) -> int:
    import argparse as _ap
    from .settings import DEFAULT_CONFIG, load_config, ROOT
    ap = _ap.ArgumentParser(prog="splitbench profile")
    ap.add_argument("--config", default=None)
    ap.add_argument("--cities", default=None,
                    help="comma list dataset/city; default Gate B scope")
    ap.add_argument("--methods", default=None,
                    help="default b1,b1b,c1,c2,c")
    ap.add_argument("--seed", type=int, default=20261120)
    ap.add_argument("--reps", type=int, default=None,
                    help="override the frozen repetition count (pretrial "
                         "still runs)")
    ap.add_argument("--no-memory", action="store_true")
    ap.add_argument("--no-trace", action="store_true")
    ap.add_argument("--run", required=True)
    args = ap.parse_args(argv)
    path = Path(args.config) if args.config else DEFAULT_CONFIG
    if not path.is_absolute():
        path = ROOT / path
    cfg = load_config(path)
    run_dir = ROOT / "runs" / args.run
    if not run_dir.is_dir():
        print("run directory not found: %s" % run_dir)
        return 2
    cities = [tuple(c.strip().split("/")) for c in args.cities.split(",")] \
        if args.cities else None
    methods = [m.strip() for m in args.methods.split(",")] \
        if args.methods else None
    res = run_profile(cfg, run_dir, cities=cities, methods=methods,
                      seed=args.seed, reps=args.reps,
                      with_memory=not args.no_memory,
                      with_trace=not args.no_trace)
    m = res["manifest"]
    print("profile: %d rows, reps frozen %d (pretrial max spread %.3f), "
          "%d trace entries"
          % (m["rows_breakdown"], m["reps_frozen"],
             m["pretrial_spread_max"], m["trace_entries"]))
    bad_counters = [r for r in res["overhead"] if r["counters_match"] != "True"]
    print("overhead: %d configs, counters_match failures: %d"
          % (len(res["overhead"]), len(bad_counters)))
    worst = sorted(res["overhead"], key=lambda r: -float(
        r["overhead_ratio"]) if r["overhead_ratio"] else 0)[:3]
    for r in worst:
        print("  highest overhead: %s/%s/%s/%s/%s ratio %s"
              % (r["city"], r["mode"], r["method"], r["variant"],
                 r["counters_match"], r["overhead_ratio"]))
    mem_bad = [r for r in res["memory"] if r.get("status") != "ok"]
    print("memory children: %d, failed: %d" % (len(res["memory"]),
                                               len(mem_bad)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
