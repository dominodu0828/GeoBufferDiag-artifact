# -*- coding: utf-8 -*-
"""splitbench CLI: prepare / verify / bench / report.

Every subcommand locates its run via ``--run <run-id>`` (a directory under
``runs/``); later steps read the earlier steps' products.  Semantic values
(seed, quota floor, folds, radii) come only from the config file -- the CLI
accepts scopes and repetition counts, never protocol overrides.

    python -B -m splitbench prepare --config configs/paper_primary.yaml \
        --suite six-city --run <run-id>
    python -B -m splitbench verify  --suite six-city \
        --outputs matched,audit --run <run-id>
    python -B -m splitbench bench   --suite six-city \
        --methods kd,postgis,block,quota,full,bounded --repetitions 5 \
        --run <run-id>
    python -B -m splitbench roundtrip --run <run-id>
    python -B -m splitbench report  --run <run-id> [--name CLOSEOUT_REPORT.md]
"""
from __future__ import annotations

import argparse
import json
import platform
import sys
import time
from pathlib import Path

from .settings import DEFAULT_CONFIG, ROOT, load_config
from . import rss


def _run_dir(run_id: str) -> Path:
    p = ROOT / "runs" / run_id
    if not p.is_dir():
        raise SystemExit("run directory not found: %s" % p)
    return p


def _load(run_id: str, config: str | None):
    path = Path(config) if config else DEFAULT_CONFIG
    if not path.is_absolute():
        path = ROOT / path
    return load_config(path), _run_dir(run_id), path


def _cpu_info() -> dict:
    info = {"platform": platform.platform(),
            "python": sys.version.split()[0],
            "machine": platform.machine(),
            "cpu": platform.processor() or platform.machine()}
    try:
        import numpy
        import scipy
        import sklearn
        import pandas
        info["numpy"] = numpy.__version__
        info["scipy"] = scipy.__version__
        info["sklearn"] = sklearn.__version__
        info["pandas"] = pandas.__version__
    except Exception as e:                       # pragma: no cover
        info["versions_error"] = str(e)
    try:
        out = __import__("subprocess").run(
            ["powercfg", "/getactivescheme"], capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=10).stdout.strip()
        info["power_scheme"] = " ".join(out.split()[2:]) or out or "unknown"
    except Exception:
        info["power_scheme"] = "unknown"
    return info


def cmd_prepare(args):
    cfg, run_dir, cfg_path = _load(args.run, args.config)
    from .prepare import run_prepare
    t0 = time.perf_counter()
    manifest = run_prepare(cfg, run_dir, args.suite)
    dt = time.perf_counter() - t0
    rm = {"run_id": args.run, "config": str(cfg_path), "suite": args.suite,
          "prepare_seconds": round(dt, 3),
          "environment": _cpu_info(),
          "threads_pinned": int(cfg["run"]["threads"]),
          "step": "prepare", "ts": _now()}
    _update_run_manifest(run_dir, rm)
    n_cities = len(manifest["cities"])
    print("prepare: %d cities in %.1fs -> %s" % (n_cities, dt, run_dir))
    if (run_dir / "input_manifest.json").exists():
        print("  inputs: %s" % (run_dir / "input_manifest.json"))
    return 0


def cmd_verify(args):
    cfg, run_dir, cfg_path = _load(args.run, args.config)
    from .verifylib import run_verify
    outputs = tuple(x.strip() for x in args.outputs.split(",") if x.strip())
    summary = run_verify(cfg, run_dir, args.suite, outputs=outputs)
    _update_run_manifest(run_dir, {"step": "verify", "ts": _now(),
                                   "verify": summary})
    print("verify: %d rows, %d mismatches" % (summary["n_rows"],
                                              summary["n_bad"]))
    if not summary["all_match"]:
        print("  first difference: see %s"
              % (run_dir / "first_diff_repro.json"))
        return 1
    print("  all engines match the frozen old functions row by row")
    return 0


def cmd_bench(args):
    cfg, run_dir, cfg_path = _load(args.run, args.config)
    from .benchlib import run_bench
    methods = [m.strip() for m in args.methods.split(",") if m.strip()]
    summary = run_bench(cfg, run_dir, methods, args.repetitions,
                        suite=args.suite)
    _update_run_manifest(run_dir, {"step": "bench", "ts": _now(),
                                   "bench": summary})
    print("bench: %d configurations x %d reps -> %s"
          % (summary["n_configs"], summary["repetitions"],
             summary["bench_csv"]))
    if summary.get("postgis_pending"):
        print("  postgis: pending (no PostgreSQL instance on this host)")
    return 0


def cmd_report(args):
    cfg, run_dir, cfg_path = _load(args.run, args.config)
    if args.name and args.name.lower() != "p0_report.md":
        # round-3 closeout report (CLOSEOUT_REPORT.md) from the same
        # products; report.py keeps writing P0_REPORT.md for history
        from .closeout_report import build_closeout_report
        path = build_closeout_report(cfg, run_dir, args.suite, name=args.name)
    else:
        from .report import build_report
        path = build_report(cfg, run_dir, args.suite)
    _update_run_manifest(run_dir, {"step": "report", "ts": _now(),
                                   "artifact": str(path)})
    print("report: %s" % path)
    return 0


def cmd_profile(args):
    cfg, run_dir, cfg_path = _load(args.run, args.config)
    from .profile import run_profile
    cities = [tuple(c.strip().split("/")) for c in args.cities.split(",")] \
        if args.cities else None
    methods = [m.strip() for m in args.methods.split(",")] \
        if args.methods else None
    res = run_profile(cfg, run_dir, cities=cities, methods=methods,
                      seed=args.seed, reps=args.reps,
                      with_memory=not args.no_memory,
                      with_trace=not args.no_trace)
    m = res["manifest"]
    _update_run_manifest(run_dir, {"step": "profile", "ts": _now(),
                                   "profile": m})
    print("profile: %d rows, reps=%d (pretrial max spread %.3f), "
          "%d trace entries, %d memory children"
          % (m["rows_breakdown"], m["reps_frozen"], m["pretrial_spread_max"],
             m["trace_entries"], len(res["memory"])))
    bad_counters = [r for r in res["overhead"]
                    if r["counters_match"] != "True"]
    print("  overhead configs: %d, counters_match failures: %d"
          % (len(res["overhead"]), len(bad_counters)))
    return 0


def cmd_gate_d(args):
    from .gate_d import run_gate_d, run_gate_d3
    run_dir = ROOT / "runs" / args.run
    if not run_dir.is_dir():
        print("run directory not found: %s" % run_dir)
        return 2
    if args.stages == "D3":
        res = run_gate_d3(run_dir, reps=args.reps or 3)
    elif args.stages == "D3seeds":
        from .gate_d import run_gate_d3_seeds
        res = {"manifest": {"rows": len(run_gate_d3_seeds(run_dir)),
                            "reps": "fixed"}}
    else:
        res = run_gate_d(run_dir, stages=tuple(args.stages.split(",")),
                         reps_override=args.reps)
    _update_run_manifest(run_dir, {"step": "gate_d", "ts": _now(),
                                   "gate_d": res["manifest"]})
    mrows = res["manifest"]
    print("gate_d: %d rows, reps %s, design sha %s..., elapsed %.0fs"
          % (mrows["rows"],
             mrows.get("reps_effective", mrows.get("reps")),
             str(mrows.get("design_sha256_frozen",
                           mrows.get("design_sha256")))[:8],
             mrows["elapsed_s"]))
    return 0


def cmd_roundtrip(args):
    cfg, run_dir, cfg_path = _load(args.run, args.config)
    from .roundtrip import run_roundtrip
    cities = [c.strip() for c in args.cities.split(",")] \
        if args.cities else None
    summary = run_roundtrip(cfg, run_dir, cities=cities,
                            fault_injection=not args.no_faults,
                            suite=args.suite)
    _update_run_manifest(run_dir, {"step": "roundtrip", "ts": _now(),
                                   "roundtrip": {
                                       k: v for k, v in summary.items()
                                       if k != "faults"},
                                   "fault_injection": summary["faults"]})
    print("roundtrip: %d files, missing=%d inconsistent=%d duplicate=%d"
          % (summary["n_files_read"], summary["n_missing"],
             summary["n_inconsistent"], summary["n_duplicate_keys"]))
    for name, f in summary["faults"].items():
        print("  fault %-22s detected=%s" % (name, f.get("detected")))
    ok = summary["all_roundtrip_ok"] and \
        summary["all_faults_detected"] is not False
    print("  %s" % ("all round-trip checks passed" if ok
                    else "ROUNDTRIP FAILED -- see roundtrip_summary.json"))
    return 0 if ok else 1


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def _update_run_manifest(run_dir: Path, update: dict):
    path = run_dir / "run_manifest.json"
    data = {}
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
    if update.get("step"):
        data["step"] = update["step"]
        data.setdefault("history", []).append(
            {"step": update["step"], "ts": update.get("ts", _now())})
    for k, v in update.items():
        if k not in ("step", "ts"):
            data[k] = v
    data.setdefault("outputs", {})
    for name in ("frozen_replay.log", "input_manifest.json",
                 "correctness.csv", "verify_summary.json", "bench.csv",
                 "bench_summary.csv", "calibration.csv", "P0_REPORT.md",
                 "CLOSEOUT_REPORT.md", "roundtrip_summary.json",
                 "postgis_status.json", "first_diff_repro.json"):
        p = run_dir / name
        if p.exists():
            import hashlib
            data["outputs"][name] = {
                "bytes": p.stat().st_size,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
    path.write_text(json.dumps(data, indent=1, ensure_ascii=False),
                    encoding="utf-8")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="splitbench")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("prepare")
    p.add_argument("--config", default=None)
    p.add_argument("--suite", default="six-city")
    p.add_argument("--run", required=True)
    p.set_defaults(fn=cmd_prepare)

    p = sub.add_parser("verify")
    p.add_argument("--config", default=None)
    p.add_argument("--suite", default="six-city")
    p.add_argument("--outputs", default="matched,audit")
    p.add_argument("--run", required=True)
    p.set_defaults(fn=cmd_verify)

    p = sub.add_parser("bench")
    p.add_argument("--config", default=None)
    p.add_argument("--suite", default="six-city")
    p.add_argument("--methods", default="kd,postgis,block,quota,full,bounded")
    p.add_argument("--repetitions", type=int, default=5)
    p.add_argument("--run", required=True)
    p.set_defaults(fn=cmd_bench)

    p = sub.add_parser("report")
    p.add_argument("--config", default=None)
    p.add_argument("--suite", default="six-city")
    p.add_argument("--name", default="P0_REPORT.md",
                   help="output file name inside the run directory "
                        "(e.g. CLOSEOUT_REPORT.md)")
    p.add_argument("--run", required=True)
    p.set_defaults(fn=cmd_report)

    p = sub.add_parser("roundtrip")
    p.add_argument("--config", default=None)
    p.add_argument("--suite", default="six-city")
    p.add_argument("--cities", default=None,
                   help="comma list dataset/city; default all six-city")
    p.add_argument("--no-faults", action="store_true",
                   help="skip the file-level fault-injection pass")
    p.add_argument("--run", required=True)
    p.set_defaults(fn=cmd_roundtrip)

    p = sub.add_parser("profile")
    p.add_argument("--config", default=None)
    p.add_argument("--cities", default=None,
                   help="comma list dataset/city; default Gate B scope "
                        "(shenzhen, sz, guangzhou)")
    p.add_argument("--methods", default=None,
                   help="default b1,b1b,c1,c2,c")
    ap_seed = p.add_argument("--seed", type=int, default=20261120)
    p.add_argument("--reps", type=int, default=None)
    p.add_argument("--no-memory", action="store_true")
    p.add_argument("--no-trace", action="store_true")
    p.add_argument("--run", required=True)
    p.set_defaults(fn=cmd_profile)

    p = sub.add_parser("gate_d")
    p.add_argument("--run", required=True)
    p.add_argument("--stages", default="D1,D2")
    p.add_argument("--reps", type=int, default=None)
    p.set_defaults(fn=cmd_gate_d)

    args = ap.parse_args(argv)
    sys.exit(args.fn(args))


if __name__ == "__main__":
    main()
