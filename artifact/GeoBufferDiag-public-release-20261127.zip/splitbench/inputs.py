# -*- coding: utf-8 -*-
"""Manifest metadata loader: frozen row order, filters, projection, keys.

Identity contract (work order sec. 2): a row is identified inside its snapshot
by ``(manifest_sha256, original row number)``; the original row number is the
zero-based position among the manifest's data rows (header excluded).  The
business ID column is carried along as an extra column -- two rows with the
same business ID (or identical coordinates) are still two samples.

Per dataset the frozen protocol is:

* streetview   -- keep ``city != gz2023`` and truthy ``feat_ok``; label is the
  original binary ``label`` column; coordinates via the old per-city
  ``to_utm(lon_req, lat_req)`` (zone from the city centroid).  The manifest's
  own ``block`` column is carried as provenance only; it does NOT replace the
  frozen K-means blocks.
* so2sat10/43  -- corrected slice: ``0 <= lcz <= 5`` with positive = ``lcz <= 2``
  (the label column in the manifest is built/natural and must NOT be used);
  patch centres are the existing ``x_utm, y_utm``; coordinates are never mixed
  across cities.  so2sat43 additionally applies the old loader's per-city
  ``min_n = 50`` rule.

Invalid input contract (sec. 3.1): negative or non-finite radius, non-finite
coordinates, wrong coordinate dimensions, and unknown units are rejected here
-- the frozen code would silently accept some of these (its ``buffered_pool``
treats any ``r <= 0`` as keep-all), so the new engine is deliberately stricter.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from . import oldbridge
from .settings import ROOT


class InvalidInput(ValueError):
    """Raised for inputs the exact query contract declares invalid."""


@dataclass
class CityTable:
    """One city's frozen rows in original manifest order."""
    dataset: str
    city: str
    manifest: Path
    manifest_sha256: str
    orig_row: np.ndarray          # (n,) int64, zero-based manifest data row
    biz_id: np.ndarray            # (n,) object/str, business ID column
    label: np.ndarray             # (n,) int8 0/1
    xy: np.ndarray                # (n, 2) float64 projected metres
    keys: np.ndarray              # (n,) float64 common random numbers
    zone: int | None              # UTM zone for the lonlat datasets
    southern: bool | None
    provenance: dict              # filter description, column provenance

    def __len__(self) -> int:
        return len(self.label)

    def to_city_data(self):
        """Old-analysis CityData with an empty feature matrix (P0 needs none)."""
        C = oldbridge.load_old()
        return C.CityData(name=self.city, X=np.empty((len(self), 0)),
                          y=self.label, xy=self.xy, keys=self.keys)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _validate_xy(xy: np.ndarray, where: str) -> np.ndarray:
    xy = np.asarray(xy, dtype=np.float64)
    if xy.ndim != 2 or xy.shape[1] != 2:
        raise InvalidInput("%s: coordinates must be (n, 2), got %r"
                           % (where, xy.shape))
    if not np.isfinite(xy).all():
        raise InvalidInput("%s: non-finite coordinate(s)" % where)
    return xy


def _validate_radius(r: float) -> float:
    r = float(r)
    if not np.isfinite(r):
        raise InvalidInput("radius must be finite, got %r" % r)
    if r < 0:
        raise InvalidInput("negative radius %r is invalid (r = 0 is the "
                           "unbuffered arm, not a negative radius)" % r)
    return r


def load_city(cfg: dict, dataset: str, city: str) -> CityTable:
    """Load one city's rows in original manifest order with frozen filtering."""
    spec = cfg["datasets"][dataset]
    manifest = ROOT / spec["manifest"]
    m = pd.read_csv(manifest, encoding="utf-8-sig")
    orig_row_all = np.arange(len(m), dtype=np.int64)

    prov = {"filter": spec["filter"], "geometry": spec["geometry"]}
    zone = southern = None

    if dataset == "streetview":
        keep = (m["city"] != "gz2023") & m["feat_ok"].astype(bool)
        m = m[keep]
        g = m[m["city"] == city]
        # boolean masking keeps the RangeIndex labels, i.e. the original
        # manifest data-row numbers
        orig_row = orig_row_all[g.index.to_numpy()]
        label = g["label"].to_numpy(dtype=np.int8)
        xy, zone, southern = oldbridge.to_utm(g["lon_req"].to_numpy(dtype=float),
                                              g["lat_req"].to_numpy(dtype=float))
        prov["utm_zone"] = int(zone)
        prov["southern"] = bool(southern)
        prov["block_column_note"] = ("manifest block column kept as provenance "
                                     "only; frozen K-means blocks are rebuilt")
        block_prov = g["block"].to_numpy()
        idx = g["IDX"].to_numpy()
        if idx.dtype.kind == "f" and np.isfinite(idx).all() and (idx == np.floor(idx)).all():
            biz = np.array(["%d" % int(v) for v in idx], dtype=object)
        else:
            biz = idx.astype(str)
    else:
        m2 = m[m["lcz"].between(0, 5)].copy()
        m2["label"] = (m2["lcz"] <= 2).astype(np.int8)
        g = m2[m2["city"] == city]
        if dataset == "so2sat43" and len(g) < int(spec.get("min_city_n", 50)):
            raise InvalidInput("city %s has %d rows < min_city_n" % (city, len(g)))
        orig_row = orig_row_all[g.index.to_numpy()]
        label = g["label"].to_numpy(dtype=np.int8)
        xy = _validate_xy(g[["x_utm", "y_utm"]].to_numpy(dtype=float),
                          "%s/%s" % (dataset, city))
        biz = orig_row.astype(str)
        prov["min_city_n"] = int(spec.get("min_city_n", 0))
        block_prov = None

    xy = _validate_xy(xy, "%s/%s" % (dataset, city))
    C = oldbridge.load_old()
    keys = C._keys_for(len(g), C._city_seed(city))
    return CityTable(dataset=dataset, city=city, manifest=manifest,
                     manifest_sha256=sha256_file(manifest),
                     orig_row=orig_row, biz_id=biz, label=label, xy=xy,
                     keys=keys, zone=zone, southern=southern,
                     provenance=dict(prov, n_block_column=block_prov))


def load_suite(cfg: dict, suite_cities: list[tuple[str, str]]) -> dict:
    """{(dataset, city): CityTable} in suite order."""
    out = {}
    for ds, city in suite_cities:
        out[(ds, city)] = load_city(cfg, ds, city)
    return out
