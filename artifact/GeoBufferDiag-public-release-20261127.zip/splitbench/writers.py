# -*- coding: utf-8 -*-
"""Unified writer: identical output encoding for every engine.

Outputs live under ``<run>/out/<method>/<dataset>__<city>__<output>.csv.gz``:

* matched -- one row per (radius, repeat, geometry, fold, arm): the ordered
  training IDs (positives then negatives) as ``|``-joined original manifest
  row numbers, plus the common quota of that repeat.
* audit   -- additionally one row per (radius, repeat, geometry, fold) with
  the complete kept / deleted ID lists of the buffered pool.
* stats   -- counts only (quotas, kept/deleted counts, fast-path count); no
  ID materialisation.

Original manifest row numbers are the identifier of record (verifiable
against the manifest); SHA-256 of each file is recorded for tracking but is
never a substitute for the row-by-row comparison in verify.

Status records: the matched/audit files carry comparisons only, so an
infeasible city-radius cell used to leave *no* trace at all -- an empty
comparison list is indistinguishable from a cell nobody ran.  ``write_status``
persists one record per (radius, repeat) for every *distinct* requested
radius, feasible or not, with the quotas and the rejection reason; acceptance
treats "the run matched" and "the status record is missing" as two different
outcomes.

Radius contract: every radius written to disk uses ``fmt_radius`` (``repr``
of the float64 value), which round-trips exactly.  ``%g`` kept only six
significant digits and collapsed 199.999999995 / 200.0 / 200.000000005 onto
one string "200" (60 Moscow status rows produced 40 duplicate (radius,
repeat) keys, 960 matched rows 640 duplicate payload keys), so near-adjacent
radii lost their identity on disk.  A duplicated-radius *request*
(e.g. ``[0, 100, 200, 400, 200]``) is saved by unique numeric result -- the
payload has one block per distinct radius -- while the full request list,
duplicates included, stays in ``bench.csv``'s ``radii`` column (same
``fmt_radius`` encoding) and in the run manifest.
"""
from __future__ import annotations

import csv
import gzip
import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

GEOM_NAMES = {0: "contiguous", 1: "scattered"}
ARM_NAMES = {0: "unbuffered", 1: "buffered"}

STATUS_COLS = ["dataset", "city", "output", "method", "radius", "repeat",
               "feasible", "budget_pos", "budget_neg", "n_comparisons", "note"]


def fmt_radius(r: float) -> str:
    """Round-trippable float64 radius representation for every disk format.

    ``repr`` of the float64 value preserves the exact number: ``float(s)``
    returns the identical value, so near-adjacent radii (200-5e-9 vs 200)
    keep distinct identities on disk and duplicate-radius requests can be
    audited against the request list."""
    return repr(float(r))


@dataclass
class Phases:
    """Wall-clock seconds per phase; engines fill what applies to them."""
    read: float = 0.0
    index: float = 0.0
    exact: float = 0.0
    quota: float = 0.0
    select: float = 0.0
    write: float = 0.0
    total: float = 0.0

    def as_dict(self):
        return {k: round(getattr(self, k) * 1000.0, 3) for k in
                ("read", "index", "exact", "quota", "select", "write", "total")}


@dataclass
class EngineResult:
    dataset: str = ""
    city: str = ""
    status: dict = field(default_factory=dict)      # radius -> status dict
    matched: dict = field(default_factory=dict)     # radius -> [comp dict]
    audit: dict = field(default_factory=dict)       # radius -> [comp dict]
    stats: dict = field(default_factory=dict)       # radius -> [comp dict]
    quota: dict = field(default_factory=dict)       # radius -> [(qp, qn) per rep]
    phases: Phases = field(default_factory=Phases)
    counters: dict = field(default_factory=dict)


def _join_ids(ct, ids: np.ndarray) -> str:
    return "|".join(map(str, ct.orig_row[ids])) if len(ids) else ""


def _iter_comparisons(folds):
    """Canonical comparison enumeration, fixed order:
    radius-major is applied by callers; here rep-major, contiguous first."""
    for rep in range(folds.n_repeats):
        for geom, k, te in folds.repeat_folds(rep):
            yield rep, geom, k, te


def write_status(run_dir, method: str, ct, folds, res: EngineResult,
                 radii, output: str) -> tuple[Path, int]:
    """Write one status record per (radius, repeat) of every distinct
    requested radius.

    Returns (path, rows).  An infeasible radius still produces its records --
    with the budgets set to -1 and the engine's rejection note -- so a cell
    that was rejected is never confused with a cell that was not run.
    Duplicate radii in the request list collapse to one record set here; the
    full request list (duplicates included) lives in bench.csv."""
    out_dir = run_dir / "out" / method
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / ("%s__%s__%s__status.csv" % (ct.dataset, ct.city, output))
    rows = 0
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=STATUS_COLS)
        w.writeheader()
        for radius in sorted(set(float(r) for r in radii)):
            st = res.status.get(radius) or {}
            feasible = bool(st.get("feasible", False))
            note = st.get("note", "") or ("" if feasible else "unknown")
            quotas = list(res.quota.get(radius) or [])
            n_cmp = len(res.matched.get(radius) or [])
            n_rep = max(len(quotas), folds.n_repeats, 0)
            for rep in range(n_rep):
                q = quotas[rep] if rep < len(quotas) else (-1, -1)
                w.writerow({
                    "dataset": ct.dataset, "city": ct.city, "output": output,
                    "method": method, "radius": fmt_radius(radius),
                    "repeat": rep,
                    "feasible": str(feasible),
                    "budget_pos": int(q[0]) if feasible else -1,
                    "budget_neg": int(q[1]) if feasible else -1,
                    "n_comparisons": n_cmp if rep == 0 else "",
                    "note": note})
                rows += 1
    return path, rows


def _payload_lines(ct, folds, res, output):
    """Yield the exact lines ``write_outputs`` persists, trailing newlines
    included.  Single source shared by the production writer and the Gate-B
    profile split writer (encode/compress timing), so the two cannot drift:
    the profile writer must reproduce the same decompressed payload."""
    if output == "matched":
        yield ("dataset,city,radius,geometry,repeat,fold,arm,"
               "n_pos,n_neg,fast_path,ids_pos,ids_neg\n")
        for radius in sorted(res.matched):
            for comp in res.matched[radius]:
                rep, geom, k = comp["rep"], comp["geom"], comp["fold"]
                qp, qn = comp["quota"]
                yield "%s,%s,%s,%s,%d,%d,%s,%d,%d,%d,%s,%s\n" % (
                    ct.dataset, ct.city, fmt_radius(radius),
                    GEOM_NAMES[geom], rep, k, ARM_NAMES[0],
                    qp, qn, 0,
                    _join_ids(ct, comp["unbuf_pos"]),
                    _join_ids(ct, comp["unbuf_neg"]))
                yield "%s,%s,%s,%s,%d,%d,%s,%d,%d,%d,%s,%s\n" % (
                    ct.dataset, ct.city, fmt_radius(radius),
                    GEOM_NAMES[geom], rep, k, ARM_NAMES[1],
                    qp, qn, int(comp["fast_path"]),
                    _join_ids(ct, comp["buf_pos"]),
                    _join_ids(ct, comp["buf_neg"]))
    elif output == "audit":
        yield ("dataset,city,radius,geometry,repeat,fold,arm,"
               "n_pos,n_neg,fast_path,ids_pos,ids_neg,"
               "n_kept,n_deleted,kept_ids,deleted_ids\n")
        for radius in sorted(res.matched):
            aud = {(c["rep"], c["geom"], c["fold"]): c
                   for c in res.audit.get(radius, [])}
            for comp in res.matched[radius]:
                key = (comp["rep"], comp["geom"], comp["fold"])
                ac = aud[key]
                qp, qn = comp["quota"]
                yield "%s,%s,%s,%s,%d,%d,%s,%d,%d,%d,%s,%s,%d,%d,%s,%s\n" % (
                    ct.dataset, ct.city, fmt_radius(radius),
                    GEOM_NAMES[comp["geom"]], comp["rep"], comp["fold"],
                    ARM_NAMES[0], qp, qn, 0,
                    _join_ids(ct, comp["unbuf_pos"]),
                    _join_ids(ct, comp["unbuf_neg"]),
                    ac["n_cand"], 0,
                    _join_ids(ct, ac["cand_idx"]), "")
                yield "%s,%s,%s,%s,%d,%d,%s,%d,%d,%d,%s,%s,%d,%d,%s,%s\n" % (
                    ct.dataset, ct.city, fmt_radius(radius),
                    GEOM_NAMES[comp["geom"]], comp["rep"], comp["fold"],
                    ARM_NAMES[1], qp, qn, int(comp["fast_path"]),
                    _join_ids(ct, comp["buf_pos"]),
                    _join_ids(ct, comp["buf_neg"]),
                    ac["n_kept"], ac["n_deleted"],
                    _join_ids(ct, ac["kept_idx"]),
                    _join_ids(ct, ac["del_idx"]))
    elif output == "stats":
        yield ("dataset,city,radius,geometry,repeat,fold,n_cand,n_kept,"
               "n_deleted,kept_pos,kept_neg,quota_pos,quota_neg,"
               "pool_action,training_action\n")
        for radius in sorted(res.stats):
            st = {(c["rep"], c["geom"], c["fold"]): c
                  for c in res.stats[radius]}
            mt = {(c["rep"], c["geom"], c["fold"]): c
                  for c in res.matched.get(radius, [])}
            for key, c in st.items():
                m = mt.get(key)
                pa = 1 if c["n_deleted"] > 0 else 0
                ta = ""
                if m is not None:
                    same = (np.array_equal(m["unbuf_pos"], m["buf_pos"])
                            and np.array_equal(m["unbuf_neg"], m["buf_neg"]))
                    ta = 0 if same else 1
                yield "%s,%s,%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%s\n" % (
                    ct.dataset, ct.city, fmt_radius(radius),
                    GEOM_NAMES[key[1]], key[0], key[2],
                    c["n_cand"], c["n_kept"], c["n_deleted"],
                    c["kept_pos"], c["kept_neg"],
                    c["quota"][0], c["quota"][1], pa, ta)
    else:
        raise ValueError("unknown output %r" % output)


def write_outputs(run_dir, method: str, ct, folds, res: EngineResult,
                  output: str) -> tuple[int, int, float]:
    """Write one output file; returns (rows, bytes, seconds).

    Row order is deterministic: radius ascending, then repeat, geometry,
    fold, arm -- identical for every engine, so byte equality is achievable
    and recorded as a bonus signal (verify still compares row by row).
    The lines come from ``_payload_lines`` (shared with the profile split
    writer); this wrapper only owns the gzip sink."""
    t0 = time.perf_counter()
    out_dir = run_dir / "out" / method
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / ("%s__%s__%s.csv.gz" % (ct.dataset, ct.city, output))

    rows = 0
    with gzip.open(path, "wt", encoding="utf-8", compresslevel=6,
                   newline="\n") as fh:
        for line in _payload_lines(ct, folds, res, output):
            fh.write(line)
            rows += 1
    dt = time.perf_counter() - t0
    return rows, path.stat().st_size, dt
