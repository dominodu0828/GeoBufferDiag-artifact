# -*- coding: utf-8 -*-
"""splitbench: exact split-construction engine comparison for GeoBufferDiag P0.

See README.md and runs/<run-id>/P0_REPORT.md.
"""
