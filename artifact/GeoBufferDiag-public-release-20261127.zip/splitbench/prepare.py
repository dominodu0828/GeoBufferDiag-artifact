# -*- coding: utf-8 -*-
"""prepare: frozen fold export + old-function reference (P0-A).

One-shot, untimed-forever work whose products every later step reads:

* ``inputs/<dataset>__<city>.npz``  -- verifiable frozen inputs: projected
  coordinates, original row order, labels, common random keys, every test
  mask (contiguous blocks + every scattered repeat).
* ``ref/<dataset>__<city>.npz``     -- the old functions' own answers for
  every sweep radius: per-repeat common budgets, per-comparison ordered
  training IDs of both arms, and the complete kept/deleted pools.  This is
  the regression oracle; verify compares engines against it row by row.
* ``ref/<dataset>__<city>__status.csv`` -- per radius/repeat budget or the
  infeasibility note; infeasible repeats reject the whole city-radius grid
  (frozen city_L semantics) and still produce status rows.
* ``input_manifest.json``           -- manifest hashes, filters, per-city
  class counts, projection provenance, file hashes.

The one-shot fold generation is timed here and reported separately from the
per-method full pipelines measured in bench.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

import numpy as np

from . import oldbridge
from .contract import build_folds
from .inputs import CityTable, load_city
from .settings import ROOT, primary_radius


def _pack_ragged(arrays: list[np.ndarray]):
    """Concatenate ragged int arrays; returns (flat, offsets)."""
    offsets = np.zeros(len(arrays) + 1, dtype=np.int64)
    for i, a in enumerate(arrays):
        offsets[i + 1] = offsets[i] + len(a)
    flat = (np.concatenate(arrays).astype(np.int32)
            if arrays else np.zeros(0, dtype=np.int32))
    return flat, offsets


def _npz_digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def export_city_inputs(ct: CityTable, folds, out_dir: Path) -> dict:
    path = out_dir / ("%s__%s.npz" % (ct.dataset, ct.city))
    scatter_masks = [te for rep in range(folds.n_repeats)
                     for te in folds.scatter[rep]]
    np.savez_compressed(
        path,
        xy=ct.xy, y=ct.label, keys=ct.keys,
        orig_row=ct.orig_row,
        biz_id=np.array(ct.biz_id, dtype="U64"),
        blocks=np.array(folds.blocks, dtype=bool) if folds.blocks
        else np.zeros((0, len(ct)), dtype=bool),
        scatter=np.array(scatter_masks, dtype=bool) if scatter_masks
        else np.zeros((0, len(ct)), dtype=bool),
        n_blocks=np.int64(len(folds.blocks)),
        n_scatter=np.int64(len(scatter_masks)),
        n_scatter_per_rep=np.array([len(us) for us in folds.scatter],
                                   dtype=np.int64),
        n_repeats=np.int64(folds.n_repeats),
        zone=np.int64(ct.zone if ct.zone is not None else -1),
        southern=np.bool_(bool(ct.southern)),
    )
    return {
        "dataset": ct.dataset, "city": ct.city,
        "manifest": str(ct.manifest), "manifest_sha256": ct.manifest_sha256,
        "n_rows": int(len(ct)),
        "n_pos": int((ct.label == 1).sum()), "n_neg": int((ct.label == 0).sum()),
        "n_blocks": len(folds.blocks),
        "n_scatter_folds": int(sum(len(us) for us in folds.scatter)),
        "n_repeats": folds.n_repeats,
        "usable": bool(folds.usable),
        "provenance": {k: v for k, v in ct.provenance.items()
                       if k != "n_block_column"},
        "inputs_npz_sha256": _npz_digest(path),
    }


class Reference:
    """Loaded view of ref/<dataset>__<city>.npz (see export_city_reference)."""

    def __init__(self, path: Path):
        z = np.load(path, allow_pickle=False)
        self.path = path
        self.radii = [float(r) for r in z["radii"]]
        self._z = {k: z[k] for k in z.files}

    def status(self, radius: float):
        z = self._z
        key = self._rk(radius)
        return {"feasible": bool(z[key + "_feasible"][()]),
                "budgets": z[key + "_budgets"].copy(),
                "note": str(z[key + "_note"][()])}

    def matched(self, radius: float):
        """[(rep, geom, fold, unbuf_pos, unbuf_neg, buf_pos, buf_neg)]"""
        z = self._z
        key = self._rk(radius)
        out = []
        for i in range(int(z[key + "_n_comp"][()])):
            seg = lambda pre: (z[pre + "_flat"][z[pre + "_off"][i]:
                                            z[pre + "_off"][i + 1]])
            out.append((int(z[key + "_comp_rep"][i]),
                        int(z[key + "_comp_geom"][i]),
                        int(z[key + "_comp_fold"][i]),
                        seg(key + "_upos"), seg(key + "_uneg"),
                        seg(key + "_bpos"), seg(key + "_bneg")))
        return out

    def audit(self, radius: float):
        z = self._z
        key = self._rk(radius)
        out = []
        for i in range(int(z[key + "_n_comp"][()])):
            seg = lambda pre: (z[pre + "_flat"][z[pre + "_off"][i]:
                                            z[pre + "_off"][i + 1]])
            out.append((int(z[key + "_comp_rep"][i]),
                        int(z[key + "_comp_geom"][i]),
                        int(z[key + "_comp_fold"][i]),
                        seg(key + "_cand"), seg(key + "_kept"),
                        seg(key + "_del")))
        return out

    def _rk(self, radius: float) -> str:
        for r in self.radii:
            if abs(r - radius) < 1e-9:
                return "r%g" % r
        raise KeyError("radius %g not in reference" % radius)


def export_city_reference(ct: CityTable, folds, radii, out_dir: Path) -> dict:
    """Old-function reference for every sweep radius (the verify oracle)."""
    C = oldbridge.load_old()
    cd = ct.to_city_data()
    reps_masks = folds.scatter
    blocks = folds.blocks
    out: dict = {"radii": np.array(sorted(radii))}
    status_rows = ["dataset,city,radius,repeat,budget_pos,budget_neg,note"]
    actions = {}

    for radius in sorted(radii):
        rk = "r%g" % radius
        budgets = [C.common_budget(cd, [us, blocks], radius)
                   for us in reps_masks]
        feasible = all(b is not None for b in budgets) and folds.usable
        note = "" if feasible else (
            "no usable units" if not folds.usable else "budget infeasible")
        bud_arr = (np.array(budgets, dtype=np.int32) if feasible
                   else np.full((folds.n_repeats, 2), -1, dtype=np.int32))
        out[rk + "_feasible"] = np.bool_(feasible)
        out[rk + "_budgets"] = bud_arr
        out[rk + "_note"] = np.array(note)
        for rep in range(folds.n_repeats):
            b = budgets[rep] if feasible else None
            status_rows.append("%s,%s,%g,%d,%s,%s,%s" % (
                ct.dataset, ct.city, radius, rep,
                b[0] if b else "", b[1] if b else "", note))

        if not feasible:
            out[rk + "_n_comp"] = np.int64(0)
            for pre in ("upos", "uneg", "bpos", "bneg", "cand", "kept", "del"):
                out[rk + "_" + pre + "_flat"] = np.zeros(0, dtype=np.int32)
                out[rk + "_" + pre + "_off"] = np.zeros(1, dtype=np.int64)
            out[rk + "_comp_rep"] = np.zeros(0, dtype=np.int64)
            out[rk + "_comp_geom"] = np.zeros(0, dtype=np.int64)
            out[rk + "_comp_fold"] = np.zeros(0, dtype=np.int64)
            continue

        upos, uneg, bpos, bneg = [], [], [], []
        cand, kept, dele = [], [], []
        comp_rep, comp_geom, comp_fold = [], [], []
        n_pool_actions = n_training_actions = n_comparisons = 0
        n_pool_actions_blk = n_training_actions_blk = n_comparisons_blk = 0
        for rep, (n_pos, n_neg) in enumerate(budgets):
            for geom, k, te in folds.repeat_folds(rep):
                pool = ~te
                bpool = C.buffered_pool(cd, te, radius)
                acted = not np.array_equal(pool, bpool)
                u = C.subsample(cd, pool, n_pos, n_neg)
                b = C.subsample(cd, bpool, n_pos, n_neg)
                trained = not np.array_equal(np.sort(u), np.sort(b))
                n_pool_actions += int(acted)
                n_training_actions += int(trained)
                n_comparisons += 1
                if geom == 0:
                    # contiguous-block strata only -- the frozen
                    # primary_action_strata.json counts these
                    n_pool_actions_blk += int(acted)
                    n_training_actions_blk += int(trained)
                    n_comparisons_blk += 1
                comp_rep.append(rep); comp_geom.append(geom)
                comp_fold.append(k)
                upos.append(u[ct.label[u] == 1]); uneg.append(u[ct.label[u] == 0])
                bpos.append(b[ct.label[b] == 1]); bneg.append(b[ct.label[b] == 0])
                cand.append(np.flatnonzero(pool))
                kept.append(np.flatnonzero(bpool))
                dele.append(np.flatnonzero(pool & ~bpool))
        out[rk + "_n_comp"] = np.int64(n_comparisons)
        out[rk + "_comp_rep"] = np.array(comp_rep, dtype=np.int64)
        out[rk + "_comp_geom"] = np.array(comp_geom, dtype=np.int64)
        out[rk + "_comp_fold"] = np.array(comp_fold, dtype=np.int64)
        for name, arrs in (("upos", upos), ("uneg", uneg),
                           ("bpos", bpos), ("bneg", bneg),
                           ("cand", cand), ("kept", kept), ("del", dele)):
            flat, off = _pack_ragged(arrs)
            out[rk + "_" + name + "_flat"] = flat
            out[rk + "_" + name + "_off"] = off
        actions[radius] = {"n_comparisons": n_comparisons,
                           "n_pool_actions": n_pool_actions,
                           "n_training_actions": n_training_actions,
                           "contiguous": {
                               "n_comparisons": n_comparisons_blk,
                               "n_pool_actions": n_pool_actions_blk,
                               "n_training_actions": n_training_actions_blk}}

    path = out_dir / ("%s__%s.npz" % (ct.dataset, ct.city))
    np.savez_compressed(path, **out)
    (out_dir / ("%s__%s__status.csv" % (ct.dataset, ct.city))).write_text(
        "\n".join(status_rows) + "\n", encoding="utf-8")
    return {"reference_npz_sha256": _npz_digest(path), "actions": actions}


def run_prepare(cfg: dict, run_dir: Path, suite: str) -> dict:
    """Full prepare step; returns the input manifest dict."""
    from .settings import suite_cities
    inputs_dir = run_dir / "inputs"; inputs_dir.mkdir(exist_ok=True)
    ref_dir = run_dir / "ref"; ref_dir.mkdir(exist_ok=True)

    sweep = sorted(set(float(r) for r in cfg["radii"]["sweep"]))
    floor = int(cfg["run"]["quota_floor"])

    cities = suite_cities(cfg, suite)
    manifest = {"suite": suite, "seed": int(cfg["run"]["seed"]),
                "quota_floor": floor,
                "k_blocks": int(cfg["run"]["k_blocks"]),
                "sweep_radii": sweep, "cities": {}}
    t_folds = 0.0
    for ds, city in cities:
        t0 = time.perf_counter()
        ct = load_city(cfg, ds, city)
        t_load = time.perf_counter() - t0
        t0 = time.perf_counter()
        folds = build_folds(oldbridge.load_old(), ct,
                            n_repeats=int(cfg["datasets"][ds]["n_repeats"]))
        t_folds += time.perf_counter() - t0
        info = export_city_inputs(ct, folds, inputs_dir)
        ref = export_city_reference(ct, folds, sweep, ref_dir)
        info.update(ref)
        info["t_load_manifest_s"] = round(t_load, 4)
        info["primary_radius"] = primary_radius(cfg, ds)
        manifest["cities"]["%s/%s" % (ds, city)] = info

    manifest["t_fold_generation_s_one_shot"] = round(t_folds, 4)
    (run_dir / "input_manifest.json").write_text(
        json.dumps(manifest, indent=1, ensure_ascii=False), encoding="utf-8")
    return manifest
