# -*- coding: utf-8 -*-
"""B0: pointwise reference engine -- small examples only.

No cKDTree, no candidate pruning: every candidate's nearest-test distance is
computed explicitly (contract.nn_distance_bruteforce forms the full pairwise
matrix chunk by chunk), both arms are enumerated explicitly and stable-
sorted, and the quota is the explicit per-fold min.  This is the semantic
yardstick for the unit tests and the verify spot checks; it is far too slow
to be a paper speed opponent on the real cities (work order sec. 4, B0).

``subset`` limits the run to given (rep, geom, fold) comparisons so the big
cities can be spot-checked without a full O(n^2) sweep.
"""
from __future__ import annotations

import time

import numpy as np

from .contract import (nn_distance_bruteforce, quota_for_repeat,
                       select_arms, _validate_radius)
from .writers import EngineResult, Phases


class B0Engine:
    name = "b0"

    def __init__(self, subset=None):
        self.subset = subset          # None = all comparisons

    def run_city(self, ct, folds, radii, output, state=None, floor: int = 5):
        t_start = time.perf_counter()
        ph = Phases()
        counters = {"engine": "b0", "n_rows_exact": 0}
        radii = [_validate_radius(r) for r in radii]
        y, xy = ct.label, ct.xy

        state = {} if state is None else state
        if "orders" not in state:
            from .contract import class_orders
            state["orders"] = class_orders(y, ct.keys)

        res = EngineResult(dataset=ct.dataset, city=ct.city,
                           phases=ph, counters=counters)
        usable = bool(folds.usable)

        for radius in radii:
            quotas = []
            feasible_all = usable
            note = "" if usable else "no usable units"
            for rep in range(folds.n_repeats):
                fold_cand, fold_kept = [], []
                for geom, k, te in folds.repeat_folds(rep):
                    if self.subset is not None and \
                            (rep, geom, k) not in self.subset:
                        continue
                    cand = np.flatnonzero(~te)
                    if radius == 0:
                        keep = np.zeros(len(y), dtype=bool)
                        keep[cand] = True
                    else:
                        d = nn_distance_bruteforce(xy, te, cand)
                        counters["n_rows_exact"] += len(cand)
                        keep = np.zeros(len(y), dtype=bool)
                        keep[cand[d > radius]] = True
                    fold_cand.append(cand)
                    fold_kept.append(keep)
                if not fold_cand:
                    quotas.append((-1, -1))
                    continue
                (qp, qn), feasible = quota_for_repeat(y, fold_cand, fold_kept,
                                                      floor)
                quotas.append((qp, qn))
                if not feasible:
                    feasible_all = False
                    note = "budget infeasible"
            res.quota[radius] = quotas
            res.status[radius] = {"feasible": feasible_all,
                                  "budgets": quotas if feasible_all else None,
                                  "note": note}

            comps, auds, stats = [], [], []
            for rep in range(folds.n_repeats):
                if self.subset is not None:
                    reps_here = {g for (r_, g, f_) in self.subset
                                 if r_ == rep}
                    if not reps_here:
                        continue
                qp, qn = quotas[rep]
                if qp < 0:
                    continue
                for geom, k, te in folds.repeat_folds(rep):
                    if self.subset is not None and \
                            (rep, geom, k) not in self.subset:
                        continue
                    cand = np.flatnonzero(~te)
                    pool_u = np.zeros(len(y), dtype=bool)
                    pool_u[cand] = True
                    if radius == 0:
                        pool_b = pool_u.copy()
                        d = None
                    else:
                        d = nn_distance_bruteforce(xy, te, cand)
                        counters["n_rows_exact"] += len(cand)
                        pool_b = np.zeros(len(y), dtype=bool)
                        pool_b[cand[d > radius]] = True
                    u, b, fast = select_arms(y, state["orders"], pool_u,
                                             pool_b, qp, qn)
                    comps.append({"rep": rep, "geom": geom, "fold": k,
                                  "quota": (qp, qn), "fast_path": fast,
                                  "unbuf_pos": u[y[u] == 1],
                                  "unbuf_neg": u[y[u] == 0],
                                  "buf_pos": b[y[b] == 1],
                                  "buf_neg": b[y[b] == 0]})
                    if output == "audit":
                        if d is None:
                            kept_idx, del_idx = cand, cand[:0]
                        else:
                            keep_c = d > radius
                            kept_idx = cand[keep_c]
                            del_idx = cand[~keep_c]
                        auds.append({"rep": rep, "geom": geom, "fold": k,
                                     "cand_idx": cand, "kept_idx": kept_idx,
                                     "del_idx": del_idx,
                                     "n_kept": len(kept_idx),
                                     "n_deleted": len(del_idx),
                                     "n_cand": len(cand)})
                    if output == "stats":
                        nk = len(cand) if d is None else int((d > radius).sum())
                        labels = y[cand] if d is None else y[cand[d > radius]]
                        stats.append({"rep": rep, "geom": geom, "fold": k,
                                      "quota": (qp, qn), "n_cand": len(cand),
                                      "n_kept": nk,
                                      "n_deleted": len(cand) - nk,
                                      "kept_pos": int((labels == 1).sum()),
                                      "kept_neg": int((labels == 0).sum())})
            res.matched[radius] = comps
            if output == "audit":
                res.audit[radius] = auds
            if output == "stats":
                res.stats[radius] = stats

        ph.exact = time.perf_counter() - t_start
        ph.total = ph.exact
        return res, state
