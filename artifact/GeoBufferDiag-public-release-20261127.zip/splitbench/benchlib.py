# -*- coding: utf-8 -*-
"""bench: interleaved, warmed-up timing of every method on the six cities.

Protocol (work order sec. 5, P0 performance):

* one discarded warm-up pass, then ``repetitions`` recorded passes,
  interleaved round-robin over configurations so drift hits all arms alike;
* every recorded pass appends one raw row to ``bench.csv`` -- the summary
  medians in ``bench_summary.csv`` are aggregates over those raw rows only;
* variants: ``cold`` rebuilds every derived structure (test trees, distance
  arrays, block indexes, class orders) from the frozen inputs in each pass;
  ``warm`` builds them once (in the warm-up pass) and reuses them, so the
  recorded passes measure quota/selection/write on a hot index -- this is
  the "one-time index build vs warm reuse" split;
* radius modes: ``single`` (primary), ``batch`` (0/100/200/400), and
  ``batch_dup`` (0/100/200/400 + the primary repeated) to exercise the
  caches;
* threadpool limits pinned to 1 for every timed phase; per-phase wall clock
  (index / exact / quota / select / write / total), the engines' counters
  (exact rows, pruned blocks, cache hits, fallbacks, ...), output rows and
  bytes, and working-set samples are all recorded per pass.

``postgis`` is accepted as a method name and produces pending rows only when
no PostgreSQL instance is available (P0 found none on this host).
"""
from __future__ import annotations

import csv as _csv
import json
import time
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

from .baseline_b1 import B1Engine
from .candidate import CandidateEngine
from .prepare import Reference
from . import rss
from .verifylib import load_city_inputs
from .writers import write_outputs, write_status, fmt_radius

METHODS = {
    "kd": lambda ec: B1Engine(),
    "bounded": lambda ec: B1Engine(bounded=True),
    "block": lambda ec: CandidateEngine(arm="c1",
                                        side=float(ec["block_grid_side_m"]),
                                        margin=float(ec["block_float_margin_m"]),
                                        batch_rows=int(ec["scan_batch_rows"])),
    "quota": lambda ec: CandidateEngine(arm="c2",
                                        side=float(ec["block_grid_side_m"]),
                                        margin=float(ec["block_float_margin_m"]),
                                        batch_rows=int(ec["scan_batch_rows"]),
                                        policy="priority"),
    "full": lambda ec: CandidateEngine(arm="c",
                                       side=float(ec["block_grid_side_m"]),
                                       margin=float(ec["block_float_margin_m"]),
                                       batch_rows=int(ec["scan_batch_rows"]),
                                       policy="priority"),
    "full_fixed": lambda ec: CandidateEngine(arm="c",
                                             side=float(ec["block_grid_side_m"]),
                                             margin=float(
                                                 ec["block_float_margin_m"]),
                                             batch_rows=int(
                                                 ec["scan_batch_rows"]),
                                             policy="fixed"),
    # prescribed-quota arms (closeout 8.1): the per-repeat quotas come from
    # the frozen reference export as an external input, so the recorded time
    # excludes the quota acquisition cost by construction; the corresponding
    # normal (quota-computing) runs are measured in the same batch.
    "kd_pre": lambda ec: B1Engine(),
    "full_pre": lambda ec: CandidateEngine(arm="c",
                                           side=float(ec["block_grid_side_m"]),
                                           margin=float(
                                               ec["block_float_margin_m"]),
                                           batch_rows=int(
                                               ec["scan_batch_rows"]),
                                           policy="priority"),
}

# bench method key -> engine name used in bench rows and writer paths
# (kd_pre runs B1Engine with prescribed quotas, full_pre runs the c arm
# with prescribed quotas, full_fixed runs the c arm with the fixed policy)
SPECIAL_METHOD_NAMES = {"kd_pre": "b1_pre", "full_pre": "c_pre",
                        "full_fixed": "c_fixed"}

COUNTER_COLS = ["n_rows_queried", "n_rows_exact", "n_rows_exact_quota",
                "n_rows_exact_select", "n_rows_cache_hits",
                "n_rows_exact_train", "n_rows_exact_test_self",
                "n_block_center_queries", "n_blocks_cand_total",
                "n_blocks_grid", "n_selection_cache_hits", "n_masks",
                "n_masks_reused", "n_masks_expanded",
                "n_rows_requeried_expansion",
                "n_blocks_allkeep", "n_blocks_alldelete",
                "n_blocks_uncertain", "n_query_batches",
                "n_quota_picks", "n_quota_folds_deferred_max",
                "n_fast_path", "n_fast_path_fail", "n_scan_rows_examined",
                "n_scan_batches", "n_fallbacks", "n_fallback_rows",
                "n_boundary_rechecks"]


def radius_lists(cfg, ds):
    primary = float(cfg["radii"]["primary"][ds])
    sweep = [float(r) for r in cfg["radii"]["sweep"]]
    dup = [float(r) for r in cfg["radii"]["batch_with_duplicate"]]
    return {"single": [primary], "batch": sweep, "batch_dup": dup}


def make_configs(cfg, methods, outputs, modes, variants,
                 suite="six-city"):
    """Fixed benchmark matrix (trimmed to what the report consumes):

    * matched/single: every requested method x {cold, warm} -- the ablation
      arms (block/quota), the bounded variant and the postgis pending rows
      only ever run here;
    * matched/batch: kd, full, bounded x {cold, warm};
    * matched/batch_dup: kd, full x {cold} -- the duplicate radius exercises
      the caches (duplicate-radius correctness is covered by verify);
    * audit and stats: kd, full x {cold} -- audit must exact everything, so
      warm reuse has nothing to show beyond what matched already shows;
    * postgis: pending rows, matched/single only.

    ``methods``/``outputs``/``modes``/``variants`` act as filters on this
    matrix, not as a cross product."""
    from .settings import suite_cities
    ec = dict(cfg["engine"])
    ec["block_grid_side_m"] = float(
        cfg["engine"].get("block_grid_side_m",
                          cfg["engine"]["block_grid_sides_m"][1]))
    out = []
    for ds, city in suite_cities(cfg, suite):

        def add(mode, output, m, variant):
            if m in methods and output in outputs and mode in modes \
                    and variant in variants:
                out.append((ds, city, mode, output, m, variant, ec))

        for m in ("kd", "bounded", "block", "quota", "full", "full_fixed",
                  "kd_pre", "full_pre", "postgis"):
            for variant in ("cold", "warm"):
                add("single", "matched", m, variant)
        for m in ("kd", "full", "bounded"):
            for variant in ("cold", "warm"):
                add("batch", "matched", m, variant)
        for m in ("kd", "full"):
            add("batch_dup", "matched", m, "cold")
        for m in ("kd", "full"):
            add("single", "audit", m, "cold")
            add("batch", "audit", m, "cold")
            add("single", "stats", m, "cold")
    return out


def run_bench(cfg, run_dir: Path, methods, repetitions, outputs=None,
              modes=None, variants=None, suite="six-city") -> dict:
    outputs = outputs or ["matched", "audit", "stats"]
    modes = modes or ["single", "batch", "batch_dup"]
    variants = variants or ["cold", "warm"]
    floor = int(cfg["run"]["quota_floor"])
    warmup = int(cfg["bench"]["warmup"])
    from .settings import suite_cities
    cities = {}
    for ds, city in suite_cities(cfg, suite):
        cities[(ds, city)] = load_city_inputs(run_dir, ds, city)

    refs = {(ds, city): Reference(run_dir / "ref" / ("%s__%s.npz" % (ds, city)))
            for ds, city in cities}

    cols = (["run_id", "ts", "dataset", "city", "mode", "radii", "output",
             "method", "variant", "rep", "feasible",
             "ms_read", "ms_index", "ms_exact", "ms_quota", "ms_select",
             "ms_write", "ms_total", "rows_out", "bytes_out", "rss_before_mb",
             "rss_after_mb", "peak_rss_mb", "rss_samples", "note"]
            + COUNTER_COLS + ["counters_json"])
    bench_path = run_dir / "bench.csv"
    fh = open(bench_path, "w", newline="", encoding="utf-8")
    wr = _csv.DictWriter(fh, fieldnames=cols)
    wr.writeheader()
    run_id = run_dir.name
    states = {}          # (ds, city, mode, output, method, variant) -> state
    pending_sql = "postgis" in methods

    def one_pass(rep_label):
        n_rows_written = 0
        for ds, city, mode, output, m, variant, ec in configs:
            ct, folds = cities[(ds, city)]
            key = (ds, city, mode, output, m, variant)
            radii = radius_lists(cfg, ds)[mode]
            status_note = ""
            if m == "postgis":
                # P0 found no PostgreSQL instance on this host; recorded as
                # pending, never silently dropped
                wr.writerow(dict(run_id=run_id, ts=_now(), dataset=ds,
                                 city=city, mode=mode,
                                 radii=_fmt_radii(radii), output=output,
                                 method="postgis", variant=variant,
                                 rep=rep_label, feasible="pending",
                                 ms_read="", ms_index="", ms_exact="",
                                 ms_quota="", ms_select="", ms_write="",
                                 ms_total="", rows_out="", bytes_out="",
                                 rss_before_mb="", rss_after_mb="",
                                 peak_rss_mb="", rss_samples="",
                                 note="pending: no instance",
                                 **{c: "" for c in COUNTER_COLS},
                                 counters_json=""))
                n_rows_written += 1
                continue
            before_mb = rss.working_set_mb()
            t0 = time.perf_counter()
            ms_read = 0.0
            state = None if variant == "cold" else states.get(key)
            if variant == "cold":
                # cold end-to-end includes re-reading the frozen inputs
                t_read = time.perf_counter()
                ct_cold, folds_cold = load_city_inputs(run_dir, ds, city)
                ms_read = (time.perf_counter() - t_read) * 1000.0
                ct, folds = ct_cold, folds_cold
            sampler = rss.PeakSampler().start()
            pres = (_prescribed_quotas(refs[(ds, city)], radii)
                    if m.endswith("_pre") else None)
            with threadpool_limits(limits=int(cfg["run"]["threads"])):
                eng = METHODS[m](ec)
                # the engine's own name is the arm (b1/b1b/c1/c2/c); the
                # special bench methods must keep distinct bench rows AND
                # distinct writer directories, so they are re-keyed here
                if m in SPECIAL_METHOD_NAMES:
                    eng.name = SPECIAL_METHOD_NAMES[m]
                res, st = eng.run_city(ct, folds, radii, output,
                                       state=state, floor=floor,
                                       prescribed=pres)
                rows_out, bytes_out, write_s = write_outputs(
                    run_dir, eng.name, ct, folds, res, output)
                write_status(run_dir, eng.name, ct, folds, res, radii, output)
            peak_mb, n_samples = sampler.stop()
            after_mb = rss.working_set_mb()
            if variant == "warm":
                states[key] = st
            total_ms = (time.perf_counter() - t0) * 1000.0
            feas = all(res.status[r]["feasible"] for r in radii)
            counters = dict(res.counters)
            row = dict(run_id=run_id, ts=_now(), dataset=ds, city=city,
                       mode=mode, radii=_fmt_radii(radii), output=output,
                       method=eng.name, variant=variant, rep=rep_label,
                       feasible=str(feas),
                       ms_read=ms_read,
                       ms_index=res.phases.index * 1000.0,
                       ms_exact=res.phases.exact * 1000.0,
                       ms_quota=res.phases.quota * 1000.0,
                       ms_select=res.phases.select * 1000.0,
                       ms_write=write_s * 1000.0,
                       ms_total=total_ms,
                       rows_out=rows_out, bytes_out=bytes_out,
                       rss_before_mb=("" if before_mb is None
                                      else round(before_mb, 1)),
                       rss_after_mb=("" if after_mb is None
                                     else round(after_mb, 1)),
                       peak_rss_mb=("" if peak_mb is None
                                    else round(peak_mb, 1)),
                       rss_samples=n_samples,
                       note=status_note,
                       counters_json=json.dumps(counters))
            for c in COUNTER_COLS:
                row[c] = counters.get(c, "")
            wr.writerow(row)
            n_rows_written += 1
        return n_rows_written

    configs = make_configs(cfg, methods, outputs, modes, variants,
                           suite=suite)
    n_configs = len(configs)
    summary_started = time.time()
    print("  bench: %d configurations x (1 warm-up + %d reps)"
          % (n_configs, repetitions), flush=True)
    with threadpool_limits(limits=int(cfg["run"]["threads"])):
        one_pass("warmup")
        for rep in range(1, repetitions + 1):
            one_pass(str(rep))
            print("    rep %d/%d done (%.0fs elapsed)"
                  % (rep, repetitions, time.time() - summary_started),
                  flush=True)
    fh.close()

    _write_summary(run_dir, bench_path, repetitions)
    lifetime = rss.peak_working_set_mb()
    return {"n_configs": n_configs, "repetitions": repetitions,
            "bench_csv": str(bench_path),
            "postgis_pending": pending_sql,
            "peak_rss_mb": (round(lifetime, 1) if lifetime is not None
                            else None)}


def _fmt_radii(radii):
    """Request metadata: round-trippable radii, duplicates preserved.

    This column is the full request list that the payload files (keyed by
    unique numeric radius) deliberately collapse; the duplicate entry of a
    batch_dup request must stay visible here."""
    return "|".join(fmt_radius(r) for r in radii)


def _prescribed_quotas(ref, radii):
    """Frozen-reference per-repeat quotas as an external input (closeout 8.1).

    Returns {radius: [(qp, qn), ...]} for feasible radii and {radius: None}
    for infeasible ones; the engines treat a None entry as an infeasible
    cell.  ``ph.quota`` is excluded by construction for these runs."""
    out = {}
    for r in radii:
        r = float(r)
        st = ref.status(r)
        out[r] = ([tuple(int(v) for v in b)
                   for b in np.asarray(st["budgets"])]
                  if st["feasible"] else None)
    return out


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def _write_summary(run_dir, bench_path, repetitions):
    """Aggregate medians/min/max per configuration from the raw rows."""
    rows = list(_csv.DictReader(open(bench_path, encoding="utf-8")))
    groups = {}
    for row in rows:
        if row["rep"] in ("", "warmup") or row["ms_total"] == "":
            continue
        key = (row["dataset"], row["city"], row["mode"], row["output"],
               row["method"], row["variant"], row["feasible"])
        groups.setdefault(key, []).append(row)
    out = run_dir / "bench_summary.csv"
    cols = ["dataset", "city", "mode", "output", "method", "variant",
            "feasible", "reps", "median_ms_total", "min_ms_total",
            "max_ms_total", "median_ms_read", "median_ms_index",
            "median_ms_exact", "median_ms_quota", "median_ms_select",
            "median_ms_write", "median_bytes_out", "median_peak_rss_mb",
            "median_rss_samples", "counters_json"]
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for key in sorted(groups):
            rs = groups[key]
            tot = [float(r["ms_total"]) for r in rs]
            med = lambda f: (round(float(np.median([float(r[f]) for r in rs
                                                    if r[f] != ""])), 2)
                             if any(r[f] != "" for r in rs) else "")
            w.writerow(dict(
                dataset=key[0], city=key[1], mode=key[2], output=key[3],
                method=key[4], variant=key[5], feasible=key[6],
                reps=len(rs),
                median_ms_total=round(float(np.median(tot)), 2),
                min_ms_total=round(min(tot), 2),
                max_ms_total=round(max(tot), 2),
                median_ms_read=med("ms_read"),
                median_ms_index=med("ms_index"),
                median_ms_exact=med("ms_exact"),
                median_ms_quota=med("ms_quota"),
                median_ms_select=med("ms_select"),
                median_ms_write=med("ms_write"),
                median_bytes_out=med("bytes_out"),
                median_peak_rss_mb=med("peak_rss_mb"),
                median_rss_samples=med("rss_samples"),
                counters_json=rs[-1]["counters_json"]))
