# -*- coding: utf-8 -*-
"""Gate D staged mechanism matrix (06 work order sec. 9.6).

DESIGN FREEZE -- the constants below are the pre-registered design; they are
written into <run>/design_d1.json (hash recorded in the manifest) before the
first timed run and must not change afterwards:

* generator seed 20261121; domain 10 km x 10 km fixed for every size
  (density grows with n -- "same city, more samples" scaling);
* geometry ``uniform``  = uniform points;
  geometry ``cluster`` = 80% of points in one Gaussian cluster (sigma 1 km
  around the domain centre) + 20% uniform;
* labels independent of geometry, class ratio 50/50; common random keys
  uniform; folds exactly like the frozen protocol structure: K = 5 spatial
  x-bands as the fixed contiguous blocks, and 5 scattered repeats that each
  partition all rows into 5 random groups (every row is a test row of
  exactly one fold per repeat, K = 5 sets test density = 20%);
* radius rule (frozen): compute the nearest-test-distance distribution of
  the n = 10^4 *uniform* reference city (seed above), first scattered fold
  of repeat 0; D1 uses the median (p50) of that distribution for every
  config; D2 uses the p10 / p50 / p90 quantiles of the SAME distribution;
* loads: D1 single [p50] and batch [0, p50]; D2 single at each quantile;
* methods b1/b1b/c1/c2/c; quota floor 5 (frozen protocol);
* repetitions (frozen): D1 n <= 10^4 -> pretrial 2 reps, formal 5 if the
  max per-config spread < 0.20 else 7; D1 n = 10^5 -> formal 2 (resource
  budget); D2 -> formal 2;
* resource budget (frozen): one timed run counts as over budget above
  300 s (row kept with status over_budget -- never deleted); isolated
  memory children only for n in {10^3, 10^5};
* stop rule (frozen): if at 10^5 the Full/B1 ratio is >= 8x AND still
  monotonically worsening AND no breakdown component (point query vs rank
  scan vs write) explains >= 50% of the candidate excess, D1/D2 count as
  "no distinguishable mechanism" -> stop scaling, narrow the paper.

Every run also records the counter set (candidate/block-center queries,
undecided-block share, scan depth vs quota, cache hits) and the
Gate-B-style parent/breakdown phases, so a mechanism reading is possible
without re-running.  Infeasible / over-budget / failed rows are kept.
"""
from __future__ import annotations

import argparse
import csv as _csv
import hashlib
import json
import random
import statistics
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

from .profile import ProfileRec, _mk_engine  # noqa: F401
from .profile import write_payload_split
from .settings import suite_cities
from .verifylib import load_city_inputs
from .writers import write_status

DESIGN_SEED = 20261121
DOMAIN_M = 10000.0
K_BLOCKS = 5
N_REPEATS = 5
SIZES = (1000, 10000, 100000)
GEOMETRIES = ("uniform", "cluster")
METHODS = ("b1", "b1b", "c1", "c2", "c")
FLOOR = 5
REPS_SMALL = 5
REPS_BIG = 2
REPS_D2 = 2
PRE_REPS = 2
SPREAD_RULE = 0.20
OVER_BUDGET_MS = 300000.0
MEMORY_CHILD_SIZES = (1000, 100000)


# ---------------------------------------------------------------------------
# synthetic city generator (frozen design)
# ---------------------------------------------------------------------------
def make_city(n: int, geometry: str, rng: np.random.Generator,
              k_blocks: int = K_BLOCKS, n_repeats: int = N_REPEATS,
              pos_ratio: float = 0.5):
    """One synthetic city + folds under the frozen structure (K and the
    class ratio are frozen constants for D1/D2; D3 overrides them under
    its own frozen design)."""
    if geometry == "uniform":
        xy = rng.uniform(0.0, DOMAIN_M, (n, 2))
    elif geometry == "cluster":
        n_cl = int(0.8 * n)
        cl = rng.normal(0.0, 1000.0, (n_cl, 2)) + (DOMAIN_M / 2, DOMAIN_M / 2)
        un = rng.uniform(0.0, DOMAIN_M, (n - n_cl, 2))
        xy = np.vstack([cl, un])
    else:
        raise ValueError(geometry)
    xy = np.clip(xy, 0.0, DOMAIN_M)
    y = (rng.random(n) < pos_ratio).astype(np.int8)
    keys = rng.random(n)
    # contiguous blocks: K spatial x-bands (fixed across repeats)
    gx = np.clip((xy[:, 0] / (DOMAIN_M / k_blocks)).astype(np.int64), 0,
                 k_blocks - 1)
    blocks = [gx == k for k in range(k_blocks)]
    blocks = [b for b in blocks if b.any()]
    # scattered repeats: partition all rows into K random groups per repeat
    scatter = []
    for _ in range(n_repeats):
        perm = rng.permutation(n)
        groups = np.array_split(perm, k_blocks)
        scatter.append([np.zeros(n, dtype=bool) for _ in groups])
        for mask, g in zip(scatter[-1], groups):
            mask[g] = True
    from .contract import CityFolds
    from .inputs import CityTable
    ct = CityTable(dataset="syn", city="%s%d" % (geometry, n),
                   manifest=None, manifest_sha256="",
                   orig_row=np.arange(n, dtype=np.int64),
                   biz_id=np.array([str(i) for i in range(n)], dtype=object),
                   label=y, xy=xy, keys=keys, zone=None, southern=None,
                   provenance={"generator": "gate_d", "n": n,
                               "geometry": geometry})
    return ct, CityFolds(blocks, scatter)


def reference_radii() -> dict:
    """Frozen radius rule: p10/p50/p90 of the nearest-test-distance
    distribution of the n = 10^4 uniform reference city (first scattered
    fold of repeat 0), computed with cKDTree exactly like the engines."""
    from scipy.spatial import cKDTree
    rng = np.random.default_rng(DESIGN_SEED)
    ct, folds = make_city(10000, "uniform", rng)
    te = folds.scatter[0][0]
    cand = np.flatnonzero(~te)
    d = cKDTree(ct.xy[te]).query(ct.xy[cand], k=1)[0]
    return {"p10": float(np.quantile(d, 0.10)),
            "p50": float(np.quantile(d, 0.50)),
            "p90": float(np.quantile(d, 0.90))}


# ---------------------------------------------------------------------------
def _one_run(ct, folds, radii, method, variant, state, out_dir, rec=None):
    t_start = time.perf_counter()
    sampler = __import__("splitbench.rss", fromlist=["rss"]).PeakSampler(
        interval=0.002).start()
    tp = threadpool_limits(limits=1)
    try:
        eng = _mk_engine(method, rec=rec)
        res, st = eng.run_city(ct, folds, radii, "matched", state=state)
        out_path = out_dir / "out" / eng.name / (
            "%s__%s__matched.csv.gz" % (ct.dataset, ct.city))
        rows_out, bytes_out, _, _ = write_payload_split(
            out_path, ct, folds, res, "matched", rec)
        if rec is not None:
            rec.parent("payload_write",
                       rec.subs[("payload_encode", "payload_write")]
                       + rec.subs[("payload_compress", "payload_write")]
                       + rec.subs[("payload_filewrite", "payload_write")])
        t0s = time.perf_counter()
        write_status(out_dir, eng.name, ct, folds, res, radii, "matched")
        if rec is not None:
            rec.parent("status_write", (time.perf_counter() - t0s) * 1000.0)
    finally:
        tp.unregister()
    peak, n_samples = sampler.stop()
    total_ms = (time.perf_counter() - t_start) * 1000.0
    return res, st, total_ms, rows_out, bytes_out, peak, n_samples


def _row_from_rec(stage, size, geometry, mode, method, variant, rep, radii,
                  res, rec, total_ms, rows_out, bytes_out, peak, n_samples,
                  status="ok"):
    if method in ("b1", "b1b"):
        index = res.phases.index + res.phases.exact
    else:
        index = res.phases.index
        assert res.phases.exact == 0.0
    parents_sum = (index * 1000.0 + res.phases.quota * 1000.0
                   + res.phases.select * 1000.0
                   + rec.parents["payload_write"] + rec.parents["status_write"]
                   + rec.parents["read"])
    unattr = total_ms - parents_sum
    if status == "ok" and unattr < -1.0:
        status = "accounting_error"
    quota = res.quota.get(radii[-1]) if res.quota else None
    qp = int(quota[0][0]) if quota else -1
    c = res.counters
    # No aligned denominator is available for the combined proof/selection scans.
    scan_ratio = ""
    return {
        "stage": stage, "size": size, "geometry": geometry, "mode": mode,
        "method": method, "variant": variant, "rep": rep,
        "status": status,
        "radii": "|".join(repr(r) for r in radii),
        "feasible": str(all(res.status[r]["feasible"] for r in radii)),
        "quota_pos": qp,
        "quota_by_radius_json": json.dumps(res.quota),
        "ms_total": round(total_ms, 2),
        "over_budget": str(total_ms > OVER_BUDGET_MS),
        "ms_index": round(index * 1000.0, 2),
        "ms_quota": round(res.phases.quota * 1000.0, 2),
        "ms_select": round(res.phases.select * 1000.0, 2),
        "ms_payload_write": round(rec.parents["payload_write"], 2),
        "ms_status_write": round(rec.parents["status_write"], 2),
        "ms_read": round(rec.parents["read"], 2),
        "ms_unattributed": round(unattr, 2),
        "sub_block_center": round(rec.subs.get(("block_center", "index"), 0.0),
                                  2),
        "sub_point_query": round(sum(v for (n, _), v in rec.subs.items()
                                     if n == "point_query"), 2),
        "sub_point_query_quota": round(rec.subs.get(("point_query", "quota"),
                                                    0.0), 2),
        "sub_point_query_select": round(rec.subs.get(("point_query", "select"),
                                                     0.0), 2),
        "sub_interval_close": round(rec.subs.get(("interval_close", "quota"),
                                                 0.0), 2),
        "sub_rank_scan": round(sum(v for (n, _), v in rec.subs.items()
                                   if n == "rank_scan"), 2),
        "scan_depth_over_quota": round(scan_ratio, 3)
        if isinstance(scan_ratio, float) else scan_ratio,
        "undecided_block_share": round(
            c.get("n_blocks_uncertain", 0)
            / max(c.get("n_blocks_cand_total", 1), 1), 4),
        "n_rows_exact": c.get("n_rows_exact", ""),
        "n_rows_exact_test_self": c.get("n_rows_exact_test_self", ""),
        "n_block_center_queries": c.get("n_block_center_queries", ""),
        "n_rows_cache_hits": c.get("n_rows_cache_hits", ""),
        "n_fallbacks": c.get("n_fallbacks", ""),
        "n_scan_rows_examined": c.get("n_scan_rows_examined", ""),
        "n_quota_picks": c.get("n_quota_picks", ""),
        "n_interval_collapses": rec.n_interval_collapses,
        "rows_out": rows_out, "bytes_out": bytes_out,
        "peak_rss_mb": round(peak, 1) if peak is not None else "",
        "rss_samples": n_samples,
        "counters_json": json.dumps({**c,
                                     "phase_raw": res.phases.as_dict()}),
    }


GATE_D_COLS = ["stage", "size", "geometry", "mode", "method", "variant",
               "rep", "status", "radii", "feasible", "quota_pos",
               "quota_by_radius_json", "ms_total",
               "over_budget", "ms_index", "ms_quota", "ms_select",
               "ms_payload_write", "ms_status_write", "ms_read",
               "ms_unattributed", "sub_block_center", "sub_point_query",
               "sub_point_query_quota", "sub_point_query_select",
               "sub_interval_close", "sub_rank_scan",
               "scan_depth_over_quota", "undecided_block_share",
               "n_rows_exact", "n_rows_exact_test_self",
               "n_block_center_queries", "n_rows_cache_hits", "n_fallbacks",
               "n_scan_rows_examined", "n_quota_picks", "n_interval_collapses",
               "rows_out", "bytes_out", "peak_rss_mb", "rss_samples",
               "k_blocks", "pos_ratio", "n_repeats", "counters_json"]


def run_gate_d(run_dir: Path, stages=("D1", "D2"), reps_override=None,
               with_memory=True, sizes=None) -> dict:
    """Freeze the design, run D1/D2, write gate_d_breakdown.csv + manifest."""
    if any((run_dir / name).exists() for name in
           ("design_d1.json", "design_d1_effective.json", "gate_d_breakdown.csv",
            "gate_d_manifest.json")):
        raise FileExistsError("Gate D artifacts already exist; use a new run")
    if reps_override is not None and reps_override < 1:
        raise ValueError("reps_override must be positive")
    sizes = tuple(SIZES if sizes is None else sizes)
    if not sizes or any(n not in SIZES for n in sizes):
        raise ValueError("sizes must be a nonempty subset of frozen sizes")
    radii_ref = reference_radii()
    design = {
        "executed_D1_sizes": list(sizes),
        "executed_stages": list(stages),
        "design_seed": DESIGN_SEED, "domain_m": DOMAIN_M,
        "k_blocks": K_BLOCKS, "n_repeats": N_REPEATS,
        "sizes": list(SIZES), "geometries": list(GEOMETRIES),
        "class_ratio": 0.5, "test_density_note": "1/K = 20% per fold",
        "methods": list(METHODS), "floor": FLOOR,
        "radius_rule": "p10/p50/p90 of the nearest-test-distance "
                       "distribution of the n=10^4 uniform reference "
                       "(seed 20261121), first scattered fold of repeat 0",
        "radii": radii_ref,
        "loads": {"D1": "single [p50] + batch [0, p50]",
                  "D2": "single at each quantile, n=10^4"},
        "reps": {"D1_small": REPS_SMALL, "D1_big": REPS_BIG, "D2": REPS_D2,
                 "pretrial": PRE_REPS, "spread_rule": SPREAD_RULE},
        "budget": {"over_budget_ms": OVER_BUDGET_MS,
                   "memory_child_sizes": list(MEMORY_CHILD_SIZES)},
        "stop_rule": "Full/B1 >= 8x at 10^5 AND monotone worsening AND no "
                     "breakdown component >= 50% of the excess -> no "
                     "distinguishable mechanism -> stop scaling",
    }
    design_path = run_dir / "design_d1.json"
    design_path.write_text(json.dumps(design, indent=1), encoding="utf-8")
    design_sha = hashlib.sha256(design_path.read_bytes()).hexdigest()

    p50 = radii_ref["p50"]
    d1_configs = []
    if "D1" in stages:
        for n in sizes:
            for geometry in GEOMETRIES:
                for mode, radii in (("single", [p50]),
                                    ("batch", [0.0, p50])):
                    for m in METHODS:
                        d1_configs.append(("D1", n, geometry, mode, m,
                                           radii))
    d2_configs = []
    if "D2" in stages:
        for geometry in GEOMETRIES:
            for q, r in (("p10", radii_ref["p10"]),
                         ("p50", radii_ref["p50"]),
                         ("p90", radii_ref["p90"])):
                for m in METHODS:
                    d2_configs.append(("D2", 10000, geometry,
                                       "single_%s" % q, m, [r]))

    rng = random.Random(DESIGN_SEED)
    shuffled = list(d1_configs + d2_configs)
    rng.shuffle(shuffled)
    # per-stage repetition bookkeeping
    def reps_for(stage, size):
        if stage == "D2":
            return REPS_D2
        return REPS_BIG if size >= 100000 else reps_small

    # pretrial on the smallest configs (n=10^3, both geoms, all methods,
    # both modes) to record the spread that the rule consumed
    pre_rows, formal_rows = [], []
    pre_state = {}
    t_all = time.perf_counter()
    pre_configs = [c for c in shuffled if c[1] == 1000 and c[0] == "D1"]
    for rep in range(1, PRE_REPS + 1):
        for cfg in pre_configs:
            stage, n, geometry, mode, m, radii = cfg
            ct, folds = make_city(n, geometry,
                                  np.random.default_rng(DESIGN_SEED))
            rec = ProfileRec()
            try:
                res, st, total, ro, bo, pk, ns = _one_run(
                    ct, folds, radii, m, "cold", None, run_dir, rec)
                r = _row_from_rec(stage, n, geometry, mode, m, "cold",
                                  "pre%d" % rep, radii, res, rec, total, ro,
                                  bo, pk, ns)
            except MemoryError:
                r = {"stage": stage, "size": n, "geometry": geometry,
                     "mode": mode, "method": m, "variant": "cold",
                     "rep": "pre%d" % rep, "status": "out_of_memory",
                     "ms_total": ""}
            pre_rows.append(r)
    spreads = {}
    by_cfg = defaultdict(list)
    for r in pre_rows:
        if r["ms_total"]:
            by_cfg[(r["stage"], r["size"], r["geometry"], r["mode"],
                    r["method"])].append(float(r["ms_total"]))
    for k, vs in by_cfg.items():
        if len(vs) == PRE_REPS:
            m_v = statistics.median(vs)
            spreads["%s" % (k,)] = (max(vs) - min(vs)) / m_v if m_v else 0
    if pre_configs and len(spreads) != len(pre_configs):
        raise RuntimeError("incomplete pretrial: cannot freeze repetition rule")
    reps_small = reps_override if reps_override is not None else (
        REPS_SMALL if not spreads or max(spreads.values()) < SPREAD_RULE
        else REPS_SMALL + 2)
    design_frozen = json.loads(design_path.read_text(encoding="utf-8"))
    design_frozen["reps"]["D1_small_effective"] = reps_small
    effective_path = run_dir / "design_d1_effective.json"
    effective_path.write_text(json.dumps(design_frozen, indent=1),
                              encoding="utf-8")
    design_sha_final = hashlib.sha256(effective_path.read_bytes()).hexdigest()

    all_rows = list(pre_rows)
    for rep in range(1, max(reps_small, REPS_D2) + 1):
        for cfg in (c for c in shuffled if c[1] < 100000):
            stage, n, geometry, mode, m, radii = cfg
            reps_here = reps_for(stage, n)
            if rep > reps_here:
                continue
            ct, folds = make_city(n, geometry,
                                  np.random.default_rng(DESIGN_SEED))
            rec = ProfileRec()
            try:
                res, st, total, ro, bo, pk, ns = _one_run(
                    ct, folds, radii, m, "cold", None, run_dir, rec)
                r = _row_from_rec(stage, n, geometry, mode, m, "cold",
                                  str(rep), radii, res, rec, total, ro, bo,
                                  pk, ns)
            except MemoryError:
                r = {"stage": stage, "size": n, "geometry": geometry,
                     "mode": mode, "method": m, "variant": "cold",
                     "rep": str(rep), "status": "out_of_memory",
                     "ms_total": ""}
            all_rows.append(r)
    # big-size configs: exactly REPS_BIG formal runs each
    for cfg in (c for c in shuffled if c[1] >= 100000):
        stage, n, geometry, mode, m, radii = cfg
        for rep in range(1, REPS_BIG + 1):
            ct, folds = make_city(n, geometry,
                                  np.random.default_rng(DESIGN_SEED))
            rec = ProfileRec()
            try:
                res, st, total, ro, bo, pk, ns = _one_run(
                    ct, folds, radii, m, "cold", None, run_dir, rec)
                r = _row_from_rec(stage, n, geometry, mode, m, "cold",
                                  str(rep), radii, res, rec, total, ro, bo,
                                  pk, ns)
            except MemoryError:
                r = {"stage": stage, "size": n, "geometry": geometry,
                     "mode": mode, "method": m, "variant": "cold",
                     "rep": str(rep), "status": "out_of_memory",
                     "ms_total": ""}
            all_rows.append(r)
            print("  %s n=%d %s %s %s rep%d: %s ms (%s)"
                  % (stage, n, geometry, mode, m, rep, r["ms_total"],
                     r["status"]), flush=True)

    out_csv = run_dir / "gate_d_breakdown.csv"
    with out_csv.open("w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=GATE_D_COLS)
        w.writeheader()
        for r in all_rows:
            w.writerow({k: r.get(k, "") for k in GATE_D_COLS})

    counts = defaultdict(list)
    for r in all_rows:
        if str(r["rep"]).isdigit():
            counts[(r["stage"], r["size"], r["geometry"], r["mode"],
                    r["method"])].append(int(r["rep"]))
    for stage, n, geometry, mode, method, _ in shuffled:
        key = (stage, n, geometry, mode, method)
        expected = list(range(1, reps_for(stage, n) + 1))
        if sorted(counts[key]) != expected:
            raise AssertionError("formal repetition mismatch %s: %s != %s"
                                 % (key, sorted(counts[key]), expected))

    manifest = {
        "run_id": run_dir.name, "design_sha256_frozen": design_sha,
        "design_sha256_final": design_sha_final,
        "reps_effective": {"D1_small": reps_small, "D1_big": REPS_BIG,
                           "D2": REPS_D2},
        "pretrial_spread_max": round(max(spreads.values()), 4) if spreads else None,
        "reps_override": reps_override,
        "formal_counts": {"|".join(map(str, k)): len(v) for k, v in counts.items()},
        "formal_status_counts": dict(__import__("collections").Counter(
            r["status"] for r in all_rows if str(r["rep"]).isdigit())),
        "rows": len(all_rows),
        "elapsed_s": round(time.perf_counter() - t_all, 1),
        "note": "design_d1.json frozen before pretrial; design_d1_effective.json "
                "records the pretrial decision before formal timing", 
    }
    (run_dir / "gate_d_manifest.json").write_text(
        json.dumps(manifest, indent=1, ensure_ascii=False),
        encoding="utf-8")
    if with_memory:
        run_gate_d_memory(run_dir, radii_ref)
    return {"manifest": manifest, "rows": all_rows,
            "design": design_frozen, "radii": radii_ref}


def run_gate_d_memory(run_dir, radii_ref):
    """Run each synthetic memory workload in a separate process and path."""
    import subprocess
    child = Path(__file__).with_name("profile_memchild.py")
    rows = []
    path = run_dir / "gate_d_memory.csv"
    if path.exists():
        raise FileExistsError("memory results already exist; use a new run")
    for n in MEMORY_CHILD_SIZES:
        for geometry in GEOMETRIES:
            for mode in ("single", "batch"):
                radii = ([radii_ref["p50"]] if mode == "single"
                         else [0.0, radii_ref["p50"]])
                for method in METHODS:
                    out_dir = run_dir / "memory_outputs" / str(n) / geometry / mode / method
                    cmd = [sys.executable, "-B", str(child), "--run", str(run_dir),
                           "--dataset", "syn", "--city", geometry + str(n),
                           "--method", method, "--mode", mode,
                           "--synthetic", "%s,%s" % (n, geometry),
                           "--radii-json", json.dumps(radii), "--writer", "split",
                           "--output-dir", str(out_dir)]
                    row = {"size": n, "geometry": geometry, "mode": mode,
                           "method": method, "radii_json": json.dumps(radii),
                           "writer": "split", "output_dir": str(out_dir)}
                    try:
                        proc = subprocess.run(cmd, capture_output=True, text=True,
                                              encoding="utf-8", errors="replace",
                                              timeout=600)
                        lines = [x for x in proc.stdout.splitlines() if x.startswith("{")]
                        if proc.returncode or not lines:
                            row.update(status="child_failed", error=proc.stderr[-1000:])
                        else:
                            row.update(json.loads(lines[-1]), status="ok", error="")
                    except subprocess.TimeoutExpired:
                        row.update(status="timeout", error="child exceeded 600 seconds")
                    rows.append(row)
    cols = ["size", "geometry", "mode", "method", "status", "error", "radii_json",
            "writer", "output_dir", "baseline_rss_mb", "pre_rss_mb", "peak_rss_mb",
            "pre_exit_rss_mb", "interval_ms", "samples", "ms_total", "rows_out",
            "bytes_out"]
    with path.open("x", encoding="utf-8", newline="") as fh:
        w = _csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    return rows


# ---------------------------------------------------------------------------
# Gate D3 (staged): test density (K), class ratio, mask reuse count.
# Representative point from D1/D2: n = 10^4, radius = p50, both geometries.
# Repetitions are a pre-registered constant (3); no memory children.
# ---------------------------------------------------------------------------
D3_K = (5, 10)
D3_POS_RATIO = (0.3, 0.7)
D3_REPEATS = (1, 5)
D3_REPS = 3


def run_gate_d3(run_dir: Path, reps: int = D3_REPS) -> dict:
    """Stage D3 under its own frozen design (design_d3.json)."""
    radii_ref = reference_radii()
    p50 = radii_ref["p50"]
    configs = []
    for geometry in GEOMETRIES:                     # D3a: density via K
        for k in D3_K:
            for m in METHODS:
                configs.append(("D3a", geometry, "single", m, [p50],
                                {"k_blocks": k, "pos_ratio": 0.5,
                                 "n_repeats": N_REPEATS}))
    for geometry in GEOMETRIES:                     # D3b: class ratio
        for pr in D3_POS_RATIO:
            for m in METHODS:
                configs.append(("D3b", geometry, "single", m, [p50],
                                {"k_blocks": K_BLOCKS, "pos_ratio": pr,
                                 "n_repeats": N_REPEATS}))
    for geometry in GEOMETRIES:                     # D3c: mask reuse
        for nr in D3_REPEATS:
            for m in METHODS:
                configs.append(("D3c", geometry, "batch", m, [0.0, p50],
                                {"k_blocks": K_BLOCKS, "pos_ratio": 0.5,
                                 "n_repeats": nr}))
    design = {
        "design_seed": DESIGN_SEED,
        "representative_point": "n=10^4, radius=p50, both geometries "
                                "(from D1/D2)",
        "stages": {"D3a": "K in (5,10), pos_ratio 0.5, repeats 5, single",
                   "D3b": "pos_ratio in (0.3,0.7), K 5, repeats 5, single",
                   "D3c": "repeats in (1,5), K 5, pos_ratio 0.5, batch "
                          "[0, p50]"},
        "methods": list(METHODS), "floor": FLOOR, "reps": reps,
        "budget": {"over_budget_ms": OVER_BUDGET_MS,
                   "memory_children": "none (size axis already covered in "
                                      "D1)"},
        "stop_rule": "report whether any D3 config has Full < B1 "
                     "(end-to-end or compute-only); if none, the "
                     "deliverable is the explicit no-crossing conclusion",
    }
    design_path = run_dir / "design_d3.json"
    design_path.write_text(json.dumps(design, indent=1), encoding="utf-8")
    design_sha = hashlib.sha256(design_path.read_bytes()).hexdigest()

    import zlib
    all_rows = []
    t_all = time.perf_counter()
    for stage, geometry, mode, m, radii, fac in configs:
        # seed excludes the method: all five methods must see the SAME city
        seed = DESIGN_SEED + zlib.crc32(("%s|%s|%s|%s|%s|%s" % (
            stage, geometry, mode, fac["k_blocks"], fac["pos_ratio"],
            fac["n_repeats"])).encode()) % 1000000
        rng = np.random.default_rng(seed)
        ct, folds = make_city(10000, geometry, rng,
                              k_blocks=fac["k_blocks"],
                              n_repeats=fac["n_repeats"],
                              pos_ratio=fac["pos_ratio"])
        for rep in range(1, reps + 1):
            rec = ProfileRec()
            try:
                res, st, total, ro, bo, pk, ns = _one_run(
                    ct, folds, radii, m, "cold", None, run_dir, rec)
                r = _row_from_rec(stage, 10000, geometry, mode, m, "cold",
                                  str(rep), radii, res, rec, total, ro, bo,
                                  pk, ns)
            except MemoryError:
                r = {"stage": stage, "size": 10000, "geometry": geometry,
                     "mode": mode, "method": m, "variant": "cold",
                     "rep": str(rep), "status": "out_of_memory",
                     "ms_total": ""}
            r.update({"k_blocks": fac["k_blocks"],
                      "pos_ratio": fac["pos_ratio"],
                      "n_repeats": fac["n_repeats"]})
            all_rows.append(r)
            print("  %s %s %s %s rep%d: %.1f ms"
                  % (stage, geometry, mode, m, rep, total), flush=True)

    out_csv = run_dir / "gate_d3_breakdown.csv"
    with out_csv.open("w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=GATE_D_COLS)
        w.writeheader()
        for r in all_rows:
            w.writerow({k: r.get(k, "") for k in GATE_D_COLS})
    manifest = {
        "run_id": run_dir.name, "design_sha256": design_sha,
        "rows": len(all_rows),
        "elapsed_s": round(time.perf_counter() - t_all, 1),
        "reps": reps,
    }
    (run_dir / "gate_d3_manifest.json").write_text(
        json.dumps(manifest, indent=1, ensure_ascii=False),
        encoding="utf-8")
    return {"manifest": manifest, "rows": all_rows}


def run_gate_d3_seeds(run_dir: Path, seeds=5, reps=3):
    """Seed-robustness check for the D3a crossing (cluster, K=5, single
    p50): the D3 run sampled ONE city draw per config and found Full < B1,
    while the D1 draw of the same nominal config did not cross -- the ratio
    is city-draw sensitive.  This pass measures the c/b1 ratio distribution
    over independent city seeds before any crossing claim."""
    radii_ref = reference_radii()
    p50 = radii_ref["p50"]
    rows = []
    t_all = time.perf_counter()
    for geometry in GEOMETRIES:
        for k in (5,):
            for si in range(1, seeds + 1):
                seed = DESIGN_SEED + si * 7919
                rng = np.random.default_rng(seed)
                ct, folds = make_city(10000, geometry, rng, k_blocks=k)
                for rep in range(1, reps + 1):
                    per = {}
                    for m in ("b1", "c"):
                        rec = ProfileRec()
                        res, st, total, ro, bo, pk, ns = _one_run(
                            ct, folds, [p50], m, "cold", None, run_dir, rec)
                        per[m] = total
                        rows.append({
                            "seed_index": si, "seed": seed,
                            "geometry": geometry, "k_blocks": k,
                            "method": m, "rep": str(rep),
                            "ms_total": round(total, 2),
                            "quota_pos": int(res.quota[p50][0][0])})
                    print("  seed%d %s: b1 %.1f c %.1f ratio %.2f"
                          % (si, geometry, per["b1"], per["c"],
                             per["c"] / per["b1"]), flush=True)
    out = run_dir / "gate_d3_seeds.csv"
    with out.open("w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for r in rows:
            w.writerow(r)
    (run_dir / "gate_d3_seeds_manifest.json").write_text(json.dumps(
        {"run_id": run_dir.name, "seeds": seeds, "reps": reps,
         "elapsed_s": round(time.perf_counter() - t_all, 1),
         "note": "seed-robustness of the D3a crossing claim"},
        indent=1), encoding="utf-8")
    return rows


def main(argv=None) -> int:
    import argparse as _ap
    from .settings import ROOT
    ap = _ap.ArgumentParser(prog="splitbench gate_d")
    ap.add_argument("--run", required=True)
    ap.add_argument("--stages", default="D1,D2")
    ap.add_argument("--reps", type=int, default=None,
                    help="override the D1 small-size repetition count")
    ap.add_argument("--no-memory", action="store_true")
    ap.add_argument("--sizes", default=None,
                    help="comma-separated subset of D1 sizes; recorded as partial scope")
    ap.add_argument("--stage", default="D1,D2",
                    choices=["D1,D2", "D3", "D3seeds"])
    args = ap.parse_args(argv)
    run_dir = ROOT / "runs" / args.run
    if not run_dir.is_dir():
        print("run directory not found: %s" % run_dir)
        return 2
    if args.stage == "D3":
        res = run_gate_d3(run_dir, reps=args.reps or D3_REPS)
    elif args.stage == "D3seeds":
        res = {"manifest": {"rows": len(run_gate_d3_seeds(run_dir))}}
    else:
        res = run_gate_d(run_dir, stages=tuple(args.stages.split(",")),
                         reps_override=args.reps, with_memory=not args.no_memory,
                         sizes=[int(n) for n in args.sizes.split(",")] if args.sizes else None)
    print("gate_d: %d rows" % res["manifest"]["rows"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
