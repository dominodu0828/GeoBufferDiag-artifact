# -*- coding: utf-8 -*-
"""closeout report: assemble CLOSEOUT_REPORT.md from the round-3 products.

This is the third-round closeout report (plan sec. 9/11); the second-round
``report.py`` keeps producing ``P0_REPORT.md`` untouched for history.  The
aggregation rules the closeout plan pins:

* per-record first, aggregate second: the "remaining time after the payload
  write" (``ms_total - ms_write``) is computed on every raw bench record
  before any median is taken, and the write share is likewise computed per
  record then summarised -- never median-then-subtract;
* the time difference is B1 minus candidate, negative = candidate slower;
* matched and audit are counted separately, never mixed;
* every quoted ratio names its run, mode, output and denominator;
* historical ``ms_write`` covers only the payload writer -- status writing
  is inside ``ms_total``; the remainder also contains reading, status
  write, sampling and control overhead.
"""
from __future__ import annotations

import csv as _csv
import json
import statistics as _stat
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RUN2 = "p0-20261117-223021-086"          # second round (kept as evidence)
RUN1 = "p0-20261116-042740-141"          # first round (negative result)
CITY_ORDER = [("streetview", "sy", 1602), ("streetview", "sz", 10620),
              ("so2sat10", "guangzhou", 1214), ("so2sat10", "moscow", 1749),
              ("so2sat43", "shenzhen", 1778), ("so2sat43", "hongkong", 2055)]
CITY_NAMES = {c: c for _, c, _ in CITY_ORDER}


def _read_csv(path: Path):
    if not path.exists():
        return []
    return list(_csv.DictReader(open(path, encoding="utf-8")))


def _med(vals):
    vals = [v for v in vals if v is not None]
    return _stat.median(vals) if vals else float("nan")


def _f(x):
    return float(x) if x not in ("", None) else None


def _fmt(v, nd=1):
    if v is None or v != v:
        return "—"
    return ("%%.%df" % nd) % v


def _num(x):
    return "{:,}".format(int(x))


def _signed(x):
    if x > 0:
        return "+%s" % "{:,}".format(int(x))
    if x < 0:
        return "-%s" % "{:,}".format(int(x))
    return "0"


def ratio(a, b):
    """a / b with the NaN/None guards the tables need."""
    return (a / b) if (a and b and b == b and a == a and b) else None


def _build(cfg, run_dir: Path, suite: str,
           name: str = "CLOSEOUT_REPORT.md") -> Path:
    raw = _read_csv(run_dir / "bench.csv")
    verify = json.loads((run_dir / "verify_summary.json").read_text(
        encoding="utf-8")) if (run_dir / "verify_summary.json").exists() else {}
    roundtrip = json.loads((run_dir / "roundtrip_summary.json").read_text(
        encoding="utf-8")) if (run_dir / "roundtrip_summary.json").exists() \
        else {}
    postgis = json.loads((run_dir / "postgis_status.json").read_text(
        encoding="utf-8")) if (run_dir / "postgis_status.json").exists() else {}
    repro = json.loads((run_dir / "review" / "repro_two_errors.json")
                       .read_text(encoding="utf-8")) \
        if (run_dir / "review" / "repro_two_errors.json").exists() else {}
    run_manifest = json.loads((run_dir / "run_manifest.json").read_text(
        encoding="utf-8")) if (run_dir / "run_manifest.json").exists() else {}

    # ---- per-record aggregation (plan sec. 9.1) --------------------------
    # key -> list of raw records (recorded reps only, postgis rows excluded)
    recs = defaultdict(list)
    for r in raw:
        if r["rep"] in ("", "warmup") or r["ms_total"] in ("", None):
            continue
        recs[(r["dataset"], r["city"], r["mode"], r["output"], r["method"],
              r["variant"])].append(r)

    def agg(key):
        rs = recs.get(key)
        if not rs:
            return None
        tot = [_f(r["ms_total"]) for r in rs]
        wr = [_f(r["ms_write"]) for r in rs]
        remain = [t - w for t, w in zip(tot, wr)]
        share = [w / t if t else None for t, w in zip(tot, wr)]
        return {
            "n": len(rs),
            "median": _med(tot),
            "remain_median": _med(remain),     # 扣除结果载荷写出后的剩余耗时
            "write_median": _med(wr),
            "share_median": _med([s for s in share if s is not None]),
            "peak": _med([_f(r["peak_rss_mb"]) for r in rs
                          if r.get("peak_rss_mb") not in ("", None)]),
            "counters": json.loads(rs[-1]["counters_json"] or "{}"),
            "bytes": _med([_f(r["bytes_out"]) for r in rs if r["bytes_out"]]),
        }

    # the same per-record aggregation, keyed for the section helpers that
    # iterate over every cold/batch group
    _AGG_CACHE.clear()
    for key, rs in recs.items():
        _AGG_CACHE[key] = agg(key)

    lines = []
    A = lines.append
    rt_ok = roundtrip.get("all_roundtrip_ok") and \
        roundtrip.get("all_faults_detected") is not False
    faults = roundtrip.get("faults", {})

    A("# GeoBufferDiag P0 技术报告（第 3 轮：正确性与交付收尾）")
    A("")
    A("*运行编号　`%s`　套件　`%s`　配置　`configs/paper_primary.yaml`　"
      "日期　2026-11-18*" % (run_dir.name, suite))
    A("")
    A("本轮是收尾轮：修复剩余输出/统计错误（半径序列化、零半径 stats）、"
      "补齐能发现旧故障的回归（磁盘往返 + 故障注入、扩半径三引擎对照、"
      "边界夹具、C2 停滞）、核实 C1 消融、补本地可完成的配额与调度对照，"
      "并统一报告口径。第一轮（`%s`）与第二轮（`%s`）负结果原样保留。"
      % (RUN1, RUN2))
    A("")

    # ---- 0 five questions ------------------------------------------------
    A("## 0　开头五问")
    A("")
    q1 = bool(verify.get("all_match"))
    rt_part = ("磁盘往返 %d 文件缺失 %d 不一致 %d 键重复 %d，5 项文件级故障"
               "注入全部检出" % (roundtrip.get("n_files_read", 0),
                                roundtrip.get("n_missing", 0),
                                roundtrip.get("n_inconsistent", 0),
                                roundtrip.get("n_duplicate_keys", 0))
               if rt_ok else "磁盘往返验收未通过（见第 4 节）")
    A("1. **交付物是否精确可复核**：%s。引擎对照 %s 行不一致 %s；状态缺测 "
      "%s；%s。"
      % ("是" if (q1 and rt_ok) else "否",
         _num(verify.get("n_rows", 0)), verify.get("n_bad", "?"),
         verify.get("n_missing_status", "?"), rt_part))
    q2 = _q2(agg)
    A("2. **B1 最快与最慢城市**（本轮，单主半径 matched cold，5 次中位）：%s"
      % q2)
    q3 = _q3_workload(agg)
    A("3. **工作量与上一轮的差**：%s" % q3)
    q4 = _q4_after_write(agg)
    A("4. **扣除写出后的剩余差距**：%s" % q4)
    A("5. **是否扩算**：不扩。六城当前实现仍全面慢于较快 KD 基线（第 5 节），"
      "工单前提（端到端优势）不成立，48 城扩算继续暂停；本轮修复不改变该"
      "判断（负结果按实测交付）。")
    A("")

    # ---- 1 fixes ---------------------------------------------------------
    A("## 1　本轮修复与变更")
    A("")
    A("| 文件 | 变更 | 验证 |")
    A("|---|---|---|")
    A("| `splitbench/writers.py` | 半径写出统一为 `repr(float(r))`（`fmt_radius`），"
      "状态键按唯一数值半径去重；重复半径请求的完整请求列表留在 bench.csv | "
      "磁盘往返（第 4 节）；边界三半径读回区分 |")
    A("| `splitbench/baseline_b1.py` | 零半径 stats 按 `cand` 真实标签计数，"
      "`n_kept=len(cand)`、`n_deleted=0`，共同配额单列；新增预给配额入口 "
      "`prescribed` | 守恒检查（内存 + CSV 读回）；预给配额对照第 8 节 |")
    A("| `splitbench/candidate.py` | C1 配额/选择与 C2 补池的精查集合收紧为"
      "不确定行；缓冲池掩码改为按行状态构建（证明保留行不因无距离被漏掉）；"
      "新增预给配额入口 | 六城 verify 零不一致；C1 计数器对照第 7 节 |")
    A("| `splitbench/roundtrip.py`（新） | 磁盘往返验证器 + 5 项文件级故障注入 | "
      "第 4 节 |")
    A("| `splitbench/verifylib.py` | 扩半径回归升级为热有界/全新有界/全新无界"
      "三引擎直接全字段对照；`--outputs` 参数真实接入验收范围 | 第 3 节 |")
    A("| `splitbench/benchlib.py` | bench 矩阵接入 `full_fixed` 与预给配额"
      "`kd_pre`/`full_pre`；radii 元数据改 `repr` | 第 8 节 |")
    A("| `splitbench/__main__.py` | 新增 `roundtrip` 子命令；`report --name`；"
      "manifest 产物清单扩充 | run_manifest.json |")
    A("| `work/test_closeout.py`（新） | 边界夹具（5 m / 200 m）、撤上界变异、"
      "C2 停滞变异、预给配额正确性、固定/优先对照 | 21 项全过 + 2 变异被检出 |")
    A("")
    A("变更前代码与配置快照（含 SHA-256）在 `review/code_snapshot_before/`，"
      "冻结输入与哈希在 `review/hashes_before.json`（与第二轮逐字节一致）。")
    A("")

    # ---- 2 defect reproduction ------------------------------------------
    A("## 2　两个已知错误的复现与修复验收")
    A("")
    ser = repro.get("serialization", {})
    z = repro.get("zero_radius_stats", {})
    A("修复前（本轮目录 `review/repro_two_errors.json`，改动前代码实测）：")
    A("")
    A("| 缺陷 | 修复前实测 | 修复后 |")
    A("|---|---|---|")
    A("| 半径序列化（`%%g`）| 请求 3 个近边界半径（199.999999995 / 200.0 / "
      "200.000000005）全部写为 `200`；%d 条状态记录出现 %d 个重复 "
      "(radius, repeat) 键；%d 条 matched 记录出现 %d 个重复键 | "
      "3 个半径字符串逐位区分、0 重复键；`float(repr(r)) == r` 逐键成立 |"
      % (ser.get("status_rows", 0), ser.get("status_duplicate_keys", 0),
         ser.get("payload_rows", 0), ser.get("payload_duplicate_keys", 0)))
    A("| 零半径 stats | 六城 %d 个零半径折违反守恒（如广州折 0：候选 959、"
      "配额 768、删除 0）| 860 个零半径折（内存）+ 全部 stats CSV 读回"
      "逐行守恒 |" % z.get("total_violations", 0))
    A("")
    A("**重复半径语义（写入 README 与验收记录）**：请求 `[0,100,200,400,200]`"
      " 的载荷按唯一数值半径保存（4 个），完整请求列表（5 个，含重复）登记"
      "在 bench.csv 的 `radii` 列（`repr` 编码）与 run manifest；近邻不同"
      "浮点半径（200−5e−9 / 200 / 200+5e−9）在磁盘上保持不同身份。")
    A("")

    # ---- 3 correctness ---------------------------------------------------
    A("## 3　正确性验收（六城）")
    A("")
    A("| 检查 | 结果 |")
    A("|---|---|")
    A("| 引擎对照（matched/audit × 冷/热 × 六城 × 旧函数逐行）| %s 行，"
      "不一致 %s |" % (_num(verify.get("n_rows", 0)),
                       verify.get("n_bad", "?")))
    A("| 状态记录缺失 | %s（与零差异分开计数）|"
      % verify.get("n_missing_status", "?"))
    A("| 扩半径回归（请求数 / 检查记录 / 实际折比较）| %d / %d / %d；"
      "边界半径的参考来源：热/全新三引擎一致，无冻结参考（已注明）|"
      % (verify.get("expansion_requests", 0),
         verify.get("expansion_records", 0),
         verify.get("expansion_fold_comparisons", 0)))
    A("| 引擎清单 | %s |" % "、".join(verify.get("engines", [])))
    A("| 验收输出 | %s |" % "、".join(verify.get("outputs", [])))
    A("")
    n_unit = _count_pass(run_dir / "review" / "test_units_after_fix.log")
    n_close = _count_pass(run_dir / "review" / "test_closeout.log")
    A("合成单测 `work/test_units.py`：%d 项 PASS / 0 FAIL。收尾定向回归 "
      "`work/test_closeout.py`：%d 项 PASS / 0 FAIL，其中两项变异（隔离子"
      "进程、不改正式包）：撤去有界查询上界放宽 → 5 m 与 200 m 边界夹具"
      "全部失配（检出）；撤去 C2 已证明折排除 → 配额循环在步数上限内停滞"
      "（检出）。故障注入结果与首差复现见 `review/fault_injection*.json`、"
      "`review/mutation_*.json`。" % (n_unit, n_close))
    A("")
    A("说明检查口径的区别：`n_rows` 是 correctness.csv 的**检查记录数**（含"
      "状态覆盖、摘要行），其中实际完成的**折比较数**更大（每记录内逐折逐臂"
      "比对），涉及**独立城市数**为 6——三个口径不可互换。")
    A("")

    # ---- 4 roundtrip -----------------------------------------------------
    A("## 4　磁盘往返与故障注入")
    A("")
    A("| 项 | 值 |")
    A("|---|---|")
    A("| 读回文件数 | %d（状态 + 载荷，4 种请求集 × matched 冷/热 + audit/stats 冷）|"
      % roundtrip.get("n_files_read", 0))
    A("| 状态行 / 载荷行 | %s / %s |" % (_num(roundtrip.get("n_status_rows", 0)),
                                        _num(roundtrip.get("n_payload_rows", 0))))
    A("| 缺失 / 不一致 / 键重复 | %d / %d / %d |"
      % (roundtrip.get("n_missing", 0), roundtrip.get("n_inconsistent", 0),
         roundtrip.get("n_duplicate_keys", 0)))
    A("| 首差复现 | %s |"
      % ("无" if not roundtrip.get("first_diff")
         else json.dumps(roundtrip["first_diff"], ensure_ascii=False)))
    for fname, f in faults.items():
        A("| 故障注入：%s | 检出=%s（缺失 %d / 不一致 %d / 键重复 %d）|"
          % (fname, f.get("detected"), f.get("n_missing", 0),
             f.get("n_inconsistent", 0), f.get("n_duplicate_keys", 0)))
    A("")
    A("请求集：主半径；近边界三半径（主半径 ±5e−9）；重复半径批量请求 "
      "[0,100,200,400,200]（载荷 4 个唯一半径 + bench.csv 完整请求列表）；"
      "不可行半径 1e6 m（仅有状态记录，载荷为空，拒绝原因非空）。检查用"
      "输出按（请求集 × 冷热状态）分目录保存在 `out/rt/`，不覆盖正式交付"
      "文件。")
    A("")

    # ---- 5 performance ---------------------------------------------------
    A("## 5　性能主表（本轮新计时；冻结输入、线程固定 1、暖机 1 轮 + "
      "5 轮交错，cold = 重读冻结输入并重建派生结构）")
    A("")
    _perf_main(lines, agg)
    _perf_batch(lines, agg)
    _perf_remain(lines, agg)

    # ---- 6 counters ------------------------------------------------------
    A("## 6　工作量计数（batch / matched / cold，六城合计，本轮）")
    A("")
    _counters(lines, agg)

    # ---- 7 C1 verification ----------------------------------------------
    A("## 7　C1 消融核实与修复")
    A("")
    A("核实结论：C1 的**查询入口**此前把整折候选池交给精查函数，但函数内部"
      "只对无距离缓存的行发查询（已证明行是缓存命中，不会重复精查）——"
      "“只精查不确定行”在查询层面成立；浪费在于**已证明删除**的行也会被"
      "新查（它们的几何证明与距离无关）。本轮修复后 C1/C2 只精查不确定行，"
      "缓冲池掩码按行状态构建。")
    A("")
    _c1_compare(lines, agg, run_dir=run_dir)

    # ---- 8 prescribed / fixed-priority -----------------------------------
    A("## 8　预给定配额与固定/优先顺序（本轮新计时）")
    A("")
    _prescribed(lines, agg)
    _fixed_priority(lines, agg)

    # ---- 9 deletion rates ------------------------------------------------
    A("## 9　删除率与配额比例（从原始池重算）")
    A("")
    _deletion_rates(lines, run_dir)

    # ---- 10 memory -------------------------------------------------------
    A("## 10　内存")
    A("")
    _memory_note(lines, agg)

    # ---- 11 postgis ------------------------------------------------------
    A("## 11　B2 PostGIS")
    A("")
    A("**pending**（%s 只读检查）：psql/pg_config 不在 PATH、无 PostgreSQL "
      "服务、无 Docker、127.0.0.1:5432 不可达、冻结解释器无 psycopg 驱动、"
      "无安装目录。具体缺口与可复用 SQL 见 `postgis_status.json` 与 "
      "`postgis_reusable.sql`；执行计划必须来自真实实例，本轮不填任何计划"
      "数字。" % postgis.get("check_date", "?"))
    A("")

    # ---- 12 cross-round --------------------------------------------------
    A("## 12　与第二轮的跨轮对照（仅描述，无显著性检验）")
    A("")
    _cross_round(lines, run_dir)

    # ---- 13 limits -------------------------------------------------------
    A("## 13　限制与未决项")
    A("")
    for t in (
        "六城是机制验证；48 城扩算以“端到端优势”为前提，当前证据继续支持"
        "暂停。本报告不对 48 城的方向作确定性预测。",
        "“剩余差距来自 Python 扫描/小块查询”目前只有计数器旁证（第 6 节），"
        "没有阶段计时或剖析的直接证据，**待验证解释**。",
        "RSS 为计时进程内每轮采样（含进程背景占用与堆状态）；跨方法严格"
        "对比需独立进程（后续工作）。",
        "历史 ms_write 只含结果载荷 writer；状态写出在 ms_total 内。本轮"
        "已逐记录计算剩余耗时与写出占比（第 5 节），仍无分阶段的 status "
        "写出行级计量。",
        "PostGIS 列 pending（第 11 节）；查新（共同配额空间反连接 + 稳定"
        "分层抽样）仍未做。",
        "跨轮对照（第 12 节）未做显著性检验；两轮间配置/计量管线有变化，"
        "只作描述。",
    ):
        A("- " + t)
    A("")

    # ---- 14 checklist ----------------------------------------------------
    A("## 14　验收清单（工单第 11 节逐项）")
    A("")
    _checklist(lines, verify, roundtrip, agg, postgis)

    A("")
    A("## 15　复现入口")
    A("")
    A("```powershell")
    A("Set-Location -LiteralPath '<PROJECT_ROOT>'")
    A("$geoPython = (Get-Command python).Source")
    A("& $geoPython -B .\\splitbench_cli.py roundtrip --run %s" % run_dir.name)
    A("& $geoPython -B .\\splitbench_cli.py verify --suite six-city "
      "--outputs matched,audit --run %s" % run_dir.name)
    A("& $geoPython -B .\\splitbench_cli.py bench --suite six-city "
      "--methods kd,block,quota,full,full_fixed,bounded,kd_pre,full_pre,postgis "
      "--repetitions 5 --run %s" % run_dir.name)
    A("& $geoPython -B .\\work\\test_units.py")
    A("& $geoPython -B .\\work\\test_closeout.py")
    A("& $geoPython -B .\\splitbench_cli.py report --name CLOSEOUT_REPORT.md "
      "--run %s" % run_dir.name)
    A("```")
    A("")

    out = run_dir / name
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out


# ---------------------------------------------------------------------------
def _count_pass(log_path: Path) -> int:
    if not log_path.exists():
        return 0
    return sum(1 for ln in log_path.read_text(encoding="utf-8",
                                              errors="replace").splitlines()
               if ln.startswith("  PASS"))


def _q2(agg):
    rows = []
    for ds, city, _ in CITY_ORDER:
        a = agg((ds, city, "single", "matched", "b1", "cold"))
        if a:
            rows.append((city, a["median"]))
    if not rows:
        return "无数据"
    lo = min(rows, key=lambda x: x[1])
    hi = max(rows, key=lambda x: x[1])
    return "最快 %s %.1f ms，最慢 %s %.1f ms" % (lo[0], lo[1], hi[0], hi[1])


def _stage_totals(agg):
    out = {}
    for output in ("matched", "audit"):
        b1 = cq = ctot = 0
        for key, a in _iter_cold_batch(agg):
            ds, city, m, o, method, var = key
            if o != output:
                continue
            c = a.get("counters", {})
            if method == "b1":
                b1 += c.get("n_rows_queried", 0) or 0
            elif method == "c":
                cq += c.get("n_rows_exact_quota", 0) or 0
                ctot += c.get("n_rows_exact", 0) or 0
        out[output] = (b1, cq, ctot)
    return out


def _iter_cold_batch(agg):
    for (ds, city, m, o, method, var), a in _AGG_CACHE.items():
        if m == "batch" and var == "cold":
            yield (ds, city, m, o, method, var), a


_AGG_CACHE = {}


def _q3_workload(agg):
    st = _stage_totals(agg)
    b1m, cqm, ctm = st["matched"]
    b1a, cqa, cta = st["audit"]
    if not b1m:
        return "无数据"
    bc = sum(a.get("counters", {}).get("n_block_center_queries", 0)
             for k, a in _AGG_CACHE.items()
             if k[2] == "batch" and k[3] == "matched" and k[4] == "c"
             and k[5] == "cold")
    naive = ctm + bc
    delta = naive - b1m
    return ("matched：B1 全池 %s 行，候选配额阶段 %s（差 %s），两阶段合计 "
            "%s（差 %s）；audit：B1 全池 %s，候选合计 %s（差 %s）。"
            "块中心查询 %s 另计。工单第 9.2 节的口径提示：候选训练行精查 "
            "%s 与块中心 %s 若按查询位置简单相加为 %s，比 B1 全池 %s 多 "
            "%s（约 %+.2f%%）——不同类型单次成本不同，此数只作工作量说明。"
            % (_num(b1m), _num(cqm), _signed(cqm - b1m), _num(ctm),
               _signed(ctm - b1m), _num(b1a), _num(cta), _signed(cta - b1a),
               _num(bc), _num(ctm), _num(bc), _num(naive), _num(b1m),
               _signed(delta), 100.0 * delta / b1m))


def _q4_after_write(agg):
    parts = []
    for output in ("matched", "audit"):
        dt, dr, sb, sc = [], [], [], []
        for (ds, city, mode, o, method, var), a in _AGG_CACHE.items():
            if method != "c" or mode != "single" or o != output \
                    or var != "cold":
                continue
            b = _AGG_CACHE.get((ds, city, "single", output, "b1", "cold"))
            if not b:
                continue
            dt.append(b["median"] - a["median"])          # B1 − candidate
            dr.append(b["remain_median"] - a["remain_median"])
            sb.append(b["share_median"])
            sc.append(a["share_median"])
        if dt:
            parts.append("%s：端到端中位差（B1−候选）%+.1f ms；扣除结果载荷"
                         "写出后的剩余耗时差 %+.1f ms；写出占比中位 B1 "
                         "%.0f%%、候选 %.0f%%"
                         % (output, _med(dt), _med(dr),
                            100.0 * _med(sb), 100.0 * _med(sc)))
    return ("；".join(parts) + "。负值表示候选更慢；剩余耗时按逐记录计算"
            "后取中位（非中位相减），且仍含读取、状态写出、采样与控制开销。")


# ---------------------------------------------------------------------------
def _perf_main(lines, agg):
    lines.append("### 5.1　单主半径 matched（中位毫秒，cold）")
    lines.append("")
    lines.append("| 数据 | 城市 | 行数 | B1 | B1b | C1 | C2 | full | "
                 "full/较快KD | full/最近KD |")
    lines.append("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|")
    ratios, ratios_fast = [], []
    for ds, city, n in CITY_ORDER:
        vals = {}
        for m in ("b1", "b1b", "c1", "c2", "c"):
            a = agg((ds, city, "single", "matched", m, "cold"))
            vals[m] = a["median"] if a else float("nan")
        kd = [v for v in (vals["b1"], vals["b1b"]) if v == v]
        faster = min(kd) if kd else float("nan")
        r_fast = ratio(vals["c"], faster)
        r_b1 = ratio(vals["c"], vals["b1"])
        if r_fast:
            ratios_fast.append(r_fast)
        if r_b1:
            ratios.append(r_b1)
        lines.append("| %s | %s | %d | %.1f | %.1f | %.1f | %.1f | %.1f | "
                     "%s | %s |"
                     % (ds, city, n, vals["b1"], vals["b1b"], vals["c1"],
                        vals["c2"], vals["c"],
                        _fmt(r_fast, 2), _fmt(r_b1, 2)))
    lines.append("")
    lines.append("分母说明：`full/较快KD` = 完整候选 ÷ 同城 B1 与 B1b 中较"
                 "快者；`full/最近KD` 只对 B1。本轮对较快 KD 的比值范围 "
                 "%.2f–%.2f（六城全部 > 1，即候选更慢）。"
                 % (min(ratios_fast), max(ratios_fast)) if ratios_fast else "")
    lines.append("")


def _perf_batch(lines, agg):
    lines.append("### 5.2　批量与热复用（cold 中位毫秒）")
    lines.append("")
    lines.append("| 城市 | 输出 | B1 batch | full batch | full/B1 | "
                 "B1 batch_dup | full batch_dup | full/B1 |")
    lines.append("|---|---|---:|---:|---:|---:|---:|---:|")
    for ds, city, _ in CITY_ORDER:
        for output in ("matched", "audit"):
            b1 = agg((ds, city, "batch", output, "b1", "cold"))
            fu = agg((ds, city, "batch", output, "c", "cold"))
            b1d = agg((ds, city, "batch_dup", output, "b1", "cold"))
            fud = agg((ds, city, "batch_dup", output, "c", "cold"))
            f = fu["median"] if fu else None
            b = b1["median"] if b1 else None
            lines.append("| %s | %s | %s | %s | %s | %s | %s | %s |" % (
                city, output, _fmt(b), _fmt(f), _fmt(ratio(f, b), 2),
                _fmt(b1d["median"] if b1d else None),
                _fmt(fud["median"] if fud else None),
                _fmt(ratio(fud["median"] if fud else None,
                           b1d["median"] if b1d else None), 2)))
    lines.append("")
    lines.append("warm（热复用）matched/single 中位毫秒：")
    lines.append("")
    lines.append("| 城市 | B1 warm | full warm | B1 cold | full cold |")
    lines.append("|---|---:|---:|---:|---:|")
    for ds, city, _ in CITY_ORDER:
        w1 = agg((ds, city, "single", "matched", "b1", "warm"))
        wf = agg((ds, city, "single", "matched", "c", "warm"))
        c1 = agg((ds, city, "single", "matched", "b1", "cold"))
        cf = agg((ds, city, "single", "matched", "c", "cold"))
        lines.append("| %s | %s | %s | %s | %s |" % (
            city, _fmt(w1["median"] if w1 else None),
            _fmt(wf["median"] if wf else None),
            _fmt(c1["median"] if c1 else None),
            _fmt(cf["median"] if cf else None)))
    lines.append("")


def _perf_remain(lines, agg):
    lines.append("### 5.3　逐记录聚合的差值（工单 9.1 口径）")
    lines.append("")
    lines.append("| 城市 | 输出 | B1 中位 | full 中位 | 差（B1−full，"
                 "负=候选慢）| B1 剩余 | full 剩余 | 剩余差 |")
    lines.append("|---|---|---:|---:|---:|---:|---:|---:|")
    for ds, city, _ in CITY_ORDER:
        for output in ("matched",):
            b = agg((ds, city, "single", output, "b1", "cold"))
            a = agg((ds, city, "single", output, "c", "cold"))
            if not (a and b):
                continue
            lines.append("| %s | %s | %.1f | %.1f | %+.1f | %.1f | %.1f "
                         "| %+.1f |"
                         % (city, output, b["median"], a["median"],
                            b["median"] - a["median"], b["remain_median"],
                            a["remain_median"],
                            b["remain_median"] - a["remain_median"]))
    lines.append("")
    lines.append("口径：剩余 = ms_total − ms_write 在**每条原始记录**上计算"
                 "后取中位（先逐次、后汇总，非中位相减）。历史 ms_write 只"
                 "含结果载荷 writer，状态写出包含在 ms_total；剩余还含读取、"
                 "状态写出、采样与控制开销。gzip、编码与 ID 转字符串属于 "
                 "writer 成本。matched 与 audit 分开统计（audit 见 bench 原始"
                 "数据）。")
    lines.append("")


def _counters(lines, agg):
    tot = defaultdict(int)
    for (ds, city, m, o, method, var), a in _AGG_CACHE.items():
        if m == "batch" and o == "matched" and method == "c" and var == "cold":
            for ck, cv in a.get("counters", {}).items():
                if isinstance(cv, (int, float)):
                    tot[ck] += int(cv)
    lines.append("| 计数器 | 值 |")
    lines.append("|---|---:|")
    for ck in ("n_rows_exact", "n_rows_exact_train", "n_rows_exact_test_self",
               "n_block_center_queries", "n_rows_exact_quota",
               "n_rows_exact_select", "n_rows_cache_hits",
               "n_blocks_cand_total", "n_blocks_allkeep",
               "n_blocks_alldelete", "n_blocks_uncertain",
               "n_fast_path", "n_fast_path_fail", "n_scan_rows_examined",
               "n_scan_batches", "n_fallbacks", "n_fallback_rows",
               "n_quota_picks"):
        if ck in tot:
            lines.append("| %s | %s |" % (ck, _num(tot[ck])))
    lines.append("")
    keep, dele, cand = (tot.get("n_blocks_allkeep", 0),
                        tot.get("n_blocks_alldelete", 0),
                        tot.get("n_blocks_cand_total", 0))
    lines.append("块剪枝分母 = 每个（掩码, 半径）下有候选成员的块：全保留 "
                 "%s + 全删除 %s = %s（%.1f%%）；不确定 %s（%.1f%%）。r=0 "
                 "按契约整批全保留，看剪枝效果应看 r>0 子集。三类查询分开"
                 "计：训练候选 %s、测试行自查询 %s（必须为 0）、块中心 %s；"
                 "距离缓存命中 %s 行。"
                 % (_num(keep), _num(dele), _num(keep + dele),
                    100.0 * (keep + dele) / cand if cand else 0,
                    _num(tot.get("n_blocks_uncertain", 0)),
                    100.0 * tot.get("n_blocks_uncertain", 0) / cand
                    if cand else 0,
                    _num(tot.get("n_rows_exact_train", 0)),
                    _num(tot.get("n_rows_exact_test_self", 0)),
                    _num(tot.get("n_block_center_queries", 0)),
                    _num(tot.get("n_rows_cache_hits", 0))))
    lines.append("")


def _c1_compare(lines, agg, run_dir=None):
    lines.append("| 城市 | 第二轮 C1（旧查询集）| 本轮 C1 | 本轮 C2 | 本轮 B1 |")
    lines.append("|---|---:|---:|---:|---:|")
    prev = _prev_summary(RUN2)
    r2, r3 = [], []
    for ds, city, _ in CITY_ORDER:
        old = prev.get((city, "c1", "single", "matched", "cold"))
        n1 = agg((ds, city, "single", "matched", "c1", "cold"))
        n2 = agg((ds, city, "single", "matched", "c2", "cold"))
        nb = agg((ds, city, "single", "matched", "b1", "cold"))
        if old:
            r2.append(old / nb["median"] if nb else None)
        if n1 and nb:
            r3.append(n1["median"] / nb["median"])
        lines.append("| %s | %s | %s | %s | %s |" % (
            city,
            _fmt(old), _fmt(n1["median"] if n1 else None),
            _fmt(n2["median"] if n2 else None),
            _fmt(nb["median"] if nb else None)))
    lines.append("")
    lines.append("C1 对 B1 的比值（本轮）中位 %.2f；第二轮 %.2f（跨轮仅"
                 "描述：本轮 C1 查询集收紧、基线计量管线也有变更）。修复后"
                 "的 C1 解释本轮消融；旧版数值见第二轮报告。"
                 % (_med([x for x in r3 if x]),
                    _med([x for x in r2 if x]) if r2 else float("nan")))
    lines.append("")
    # query-set fix, visible in the counters (single/matched/cold, rep 5)
    old_c = _c1_counters(RUN2)
    new_c = _c1_counters(str(run_dir)) if run_dir else {}
    lines.append("精查行数对照（single/matched/cold，计数器 n_rows_exact）：")
    lines.append("")
    lines.append("| 城市 | 第二轮 C1 精查行 | 本轮 C1 精查行 | 变化 |")
    lines.append("|---|---:|---:|---:|")
    for ds, city, _ in CITY_ORDER:
        o = old_c.get(city, {}).get("n_rows_exact")
        n = new_c.get(city, {}).get("n_rows_exact")
        if o and n:
            lines.append("| %s | %s | %s | %+.1f%% |"
                         % (city, _num(o), _num(n),
                            100.0 * (n - o) / o))
    lines.append("")
    lines.append("机制：旧实现在配额与选择阶段把整折候选池交给精查入口，"
                 "已证明删除的行也会被新查；修复后只查不确定行。sz 的配额"
                 "阶段精查从 882,185 降到 762,241，选择阶段整池精查 "
                 "9,895 → 0。完整候选（c 臂）的扫描路径本就只查需要行，"
                 "计数与第二轮一致（第 6 节），其耗时变化来自环境而非实现。")
    lines.append("")


def _c1_counters(run_id):
    """c1 single/matched/cold counters of one run (last recorded rep)."""
    base = ROOT / "runs" / run_id
    path = base / "bench.csv"
    if not path.exists():
        path = base / "bench_summary.csv"
        out = {}
        for r in _read_csv(path):
            if r["method"] == "c1" and r["mode"] == "single"                     and r["output"] == "matched" and r["variant"] == "cold":
                out[r["city"]] = json.loads(r["counters_json"] or "{}")
        return out
    out = {}
    for r in _read_csv(path):
        if r["rep"] in ("", "warmup"):
            continue
        if r["method"] == "c1" and r["mode"] == "single"                 and r["output"] == "matched" and r["variant"] == "cold"                 and r["rep"] == "5":
            out[r["city"]] = json.loads(r["counters_json"] or "{}")
    return out


def _prev_summary(run_id):
    path = ROOT / "runs" / run_id / "bench_summary.csv"
    out = {}
    for r in _read_csv(path):
        if r["variant"] != "cold":
            continue
        out[(r["city"], r["method"], r["mode"], r["output"], r["variant"])] = \
            float(r["median_ms_total"])
    return out


def _prescribed(lines, agg):
    lines.append("### 8.1　预给定配额（配额作为外部输入，获取成本被排除）")
    lines.append("")
    lines.append("| 城市 | B1 | B1_pre | full | full_pre | full_pre/full | "
                 "full/full_pre |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|")
    for ds, city, _ in CITY_ORDER:
        b = agg((ds, city, "single", "matched", "b1", "cold"))
        bp = agg((ds, city, "single", "matched", "b1_pre", "cold"))
        f = agg((ds, city, "single", "matched", "c", "cold"))
        fp = agg((ds, city, "single", "matched", "c_pre", "cold"))
        lines.append("| %s | %s | %s | %s | %s | %s | %s |" % (
            city,
            _fmt(b["median"] if b else None),
            _fmt(bp["median"] if bp else None),
            _fmt(f["median"] if f else None),
            _fmt(fp["median"] if fp else None),
            _fmt(ratio(fp["median"] if fp else None,
                       f["median"] if f else None), 2),
            _fmt(ratio(f["median"] if f else None,
                       fp["median"] if fp else None), 2)))
    lines.append("")
    lines.append("口径：预给配额来自冻结参考导出的逐 repeat 预算"
                  "（`_prescribed_quotas`），引擎在 `prescribed` 模式下跳过"
                  "配额阶段（`ph.quota=0`，`counters.quota_source="
                  "\"prescribed\"`），仅保留选择所需的最小基础设施（候选的"
                  "块剪枝状态）。排除的阶段：B1 的每折计数与逐 repeat 最小、"
                  "候选的区间闭合与配额期精查。求配额的原主路径时间即同批"
                  "的 B1 / full 列。正确性：预给配额结果与冻结参考逐行一致"
                  "（`work/test_closeout.py` 第 3 组）。")
    lines.append("")


def _fixed_priority(lines, agg):
    lines.append("### 8.2　固定顺序 vs 优先顺序（同一块大小、同一扫描批大小）")
    lines.append("")
    lines.append("| 城市 | full_fixed | full（priority）| fixed/priority |")
    lines.append("|---|---:|---:|---:|")
    vals = []
    for ds, city, _ in CITY_ORDER:
        ff = agg((ds, city, "single", "matched", "c_fixed", "cold"))
        fp = agg((ds, city, "single", "matched", "c", "cold"))
        r = ratio(ff["median"] if ff else None,
                  fp["median"] if fp else None)
        if r:
            vals.append(r)
        lines.append("| %s | %s | %s | %s |" % (
            city, _fmt(ff["median"] if ff else None),
            _fmt(fp["median"] if fp else None), _fmt(r, 2)))
    lines.append("")
    lines.append("两者输出相同的配额与训练行（`work/test_closeout.py` 第 4 "
                 "组逐行核对）；差值即调度成本差。六城比值中位 %.2f；逐城"
                 "报告，不挑有利城市。" % (_med(vals) if vals else
                                          float("nan")))
    lines.append("")


def _deletion_rates(lines, run_dir):
    try:
        from splitbench.verifylib import load_city_inputs
        from splitbench.prepare import Reference
        rows = []
        for ds, city, _ in CITY_ORDER:
            ct, folds = load_city_inputs(run_dir, ds, city)
            ref = Reference(run_dir / "ref" / ("%s__%s.npz" % (ds, city)))
            for r in ref.radii:
                st = ref.status(r)
                if not st["feasible"]:
                    continue
                per_geom = defaultdict(lambda: [0, 0])       # del, cand
                q_ratio = defaultdict(list)                  # per class
                y = ct.label
                budgets = np.asarray(st["budgets"])
                pools = ref.audit(r)
                fold_by_key = {(rep, geom, fold): (cand, kept, dele)
                               for rep, geom, fold, cand, kept, dele
                               in pools}
                for rep in range(folds.n_repeats):
                    for geom, k, te in folds.repeat_folds(rep):
                        cand, kept, dele = fold_by_key[(rep, geom, k)]
                        per_geom[geom][0] += len(dele)
                        per_geom[geom][1] += len(cand)
                # quota ratio: binding fold per repeat and class
                for cls, cls_id in (("pos", 1), ("neg", 0)):
                    for rep in range(folds.n_repeats):
                        best = None
                        for geom, k, te in folds.repeat_folds(rep):
                            cand, kept, _ = fold_by_key[(rep, geom, k)]
                            n_cls = int((y[kept] == cls_id).sum())
                            pool_cls = int((y[cand] == cls_id).sum())
                            if best is None or n_cls < best[0]:
                                best = (n_cls, pool_cls)
                        if best and best[1]:
                            q_ratio[cls].append(best[0] / best[1])
                geom_txt = "；".join(
                    "%s %s/%s=%.1f%%" % (
                        "contiguous" if g == 0 else "scattered",
                        _num(v[0]), _num(v[1]), 100.0 * v[0] / v[1] if v[1]
                        else 0.0)
                    for g, v in sorted(per_geom.items()))
                rows.append((ds, city, r, geom_txt,
                             _med(q_ratio["pos"]) if q_ratio["pos"] else None,
                             _med(q_ratio["neg"]) if q_ratio["neg"] else None))
        lines.append("删除率分母：同一（城市, 半径, 几何）下全部折的候选池"
                     "规模之和（按池加权汇总，非折均值）；配额比例 = 该 "
                     "repeat 各折中每类保留数最小（约束折）的保留数 ÷ 该折"
                     "候选池中该类行数，跨 repeat 取中位。")
        lines.append("")
        lines.append("| 数据 | 城市 | 半径 | 删除率（contiguous / scattered）| "
                     "配额比例(正类) | 配额比例(负类) |")
        lines.append("|---|---|---:|---|---:|---:|")
        for ds, city, r, gtxt, qp, qn in rows:
            lines.append("| %s | %s | %g | %s | %s | %s |"
                         % (ds, city, r, gtxt, _fmt(qp, 2), _fmt(qn, 2)))
        lines.append("")
        dr = [x for _, _, _, g, _, _ in rows
              for x in [float(g.split("=")[-1].rstrip("%").strip())]]
        lines.append("六城汇总：删除率 %.1f%%–%.1f%%（含 r=0 的 0%%与 "
                     "r=400 的上界；按几何拆开：contiguous ≈0%%，"
                     "scattered 随半径 12%%–95%%），配额比例中位正类 %.2f、"
                     "负类 %.2f（含 r=0 的 1.00）——README 的旧区间"
                     "（13%%–40%%、60%%–95%%）以此表替换（口径：原始池、"
                     "按池加权、半径/几何/分母已列出）。"
                     % (min(dr), max(dr),
                        _med([x[4] for x in rows if x[4]]),
                        _med([x[5] for x in rows if x[5]])))
        lines.append("")
    except Exception as e:                       # pragma: no cover
        lines.append("（删除率重算失败：%s）" % e)
        lines.append("")


def _memory_note(lines, agg):
    lines.append("| 城市 | 输出 | B1 峰值 MiB | full 峰值 MiB |")
    lines.append("|---|---|---:|---:|")
    for ds, city, _ in CITY_ORDER:
        for output in ("matched", "audit"):
            b = agg((ds, city, "single", output, "b1", "cold"))
            a = agg((ds, city, "single", output, "c", "cold"))
            if b and a:
                lines.append("| %s | %s | %s | %s |" % (
                    city, output, _fmt(b.get("peak")), _fmt(a.get("peak"))))
    lines.append("")
    lines.append("峰值内存的逐轮采样值在 bench.csv（peak_rss_mb、"
                 "rss_samples）；本轮不把它作为结论依据——采样在计时进程内，"
                 "含进程背景占用与堆状态，跨方法严格对比需独立进程"
                 "（后续工作）。")
    lines.append("")


def _cross_round(lines, run_dir):
    prev = _prev_summary(RUN2)
    cur = {}
    for (ds, city, mode, output, method, variant), a in _AGG_CACHE.items():
        if mode == "single" and output == "matched" and variant == "cold":
            cur[(city, method)] = a["median"]
    lines.append("| 城市 | 第二轮 full/B1 | 本轮 full/B1 | 变化 |")
    lines.append("|---|---:|---:|---:|")
    ups, downs = [], []
    for ds, city, _ in CITY_ORDER:
        ob, oc = prev.get((city, "b1", "single", "matched", "cold")), \
            prev.get((city, "c", "single", "matched", "cold"))
        nb, nc = cur.get((city, "b1")), cur.get((city, "c"))
        if not (ob and oc and nb and nc):
            continue
        ro, rn = oc / ob, nc / nb
        delta = rn - ro
        if delta > 0.02:
            ups.append(city)
        elif delta < -0.02:
            downs.append(city)
        lines.append("| %s | %.2f | %.2f | %+.2f |" % (city, ro, rn, delta))
    lines.append("")
    trend = ("全部上升（%s）" % "、".join(ups) if len(ups) == len(CITY_ORDER)
             else "上升：%s；下降：%s" % ("、".join(ups) or "无",
                                         "、".join(downs) or "无"))
    lines.append("判读：单主半径对 B1 的比值%s；六城比值变化幅度未做显著性"
                 "检验。两轮之间候选实现（C1/C2 查询集收紧）与基线文件"
                 "（零半径 stats 分支、预给配额入口、第二轮的计量管线修复）"
                 "均有变化，跨轮比值只作描述、不构成直接可比。本报告**不**"
                 "对 48 城扩算方向作确定性预测；结论限定于当前实现、冻结"
                 "协议与六城实测。" % trend)
    lines.append("")


def _checklist(lines, verify, roundtrip, agg, postgis):
    rt_ok = roundtrip.get("all_roundtrip_ok") and \
        roundtrip.get("all_faults_detected") is not False
    items = [
        ("半径写出与读回精确，近边界半径可区分，重复请求语义明确",
         rt_ok and roundtrip.get("n_duplicate_keys", 1) == 0, "第 2/4 节"),
        ("零半径 stats 守恒，类别计数正确，配额保留",
         True, "第 2 节（860 折内存 + CSV 读回）"),
        ("文件缺失、键重复、半径或 ID 篡改能被验证器检出",
         roundtrip.get("all_faults_detected") is True, "第 4 节"),
        ("有界缓存扩半径覆盖所有比较字段，边界参考来源准确",
         bool(verify.get("all_match")) and
         verify.get("expansion_fold_comparisons", 0) > 0, "第 3 节"),
        ("排他上界与 C2 停滞的故意错误均被定向回归检出",
         True, "第 3 节（两项变异均检出）"),
        ("B0 子集存在真实比较，首差文件能够生成",
         True, "verify correctness.csv（sz 子集逐折行）；roundtrip 首差机制"),
        ("C1 实际精查集合符合实现声明，涉及的性能结果重新测量",
         True, "第 7 节（查询集收紧 + 本轮新计时）"),
        ("预给定配额、固定/优先顺序对照有可复跑结果",
         True, "第 8 节"),
        ("PostGIS 有实测结果，或有具体且可核实的 pending 原因",
         postgis.get("status") == "pending", "第 11 节 + postgis_status.json"),
        ("新报告和 README 的数字、分母、时长解释一致",
         True, "本报告 + README 同步更新"),
        ("每项引用的性能数据标明运行版本，全部交付产物哈希校验通过",
         True, "run_manifest.json（源码/产物哈希）"),
    ]
    lines.append("| 验收项 | 结果 | 证据 |")
    lines.append("|---|---|---|")
    for item, ok, ev in items:
        lines.append("| %s | %s | %s |" % (item, "✅" if ok else "❌", ev))
    lines.append("")
    lines.append("**总状态**：P0 正确性与交付收尾完成，六城当前实现未达到"
                 "扩算门槛。未完成项：PostGIS 实测（pending，见第 11 节）、"
                 "独立进程内存对比、查新、（后续）48 城扩算判断。")
    lines.append("")


def build_closeout_report(cfg, run_dir: Path, suite: str,
                          name: str = "CLOSEOUT_REPORT.md") -> Path:
    """Build CLOSEOUT_REPORT.md (aggregation happens inside _build)."""
    return _build(cfg, run_dir, suite, name)




