# -*- coding: utf-8 -*-
"""Bridge to the frozen ICLR27 implementation (read-only import).

The old tree is an input: import with ``-B`` so no ``__pycache__`` is written
into it, and never call entry points that write into the old ``results/``
directory.  Only pure computation entries are used here:

  * ``analysis.common``  -- CityData, _city_seed, _keys_for, contiguous_units,
    scattered_units, scattered_repeats, buffered_pool, common_budget, subsample
  * ``analysis.primary_action_strata.classify_city`` -- independent replay of
    the contiguous-block strata (used as the regression oracle)
  * ``bufferdiag.project.to_utm`` -- per-city UTM projection for street view

Nothing here mutates the old tree.
"""
from __future__ import annotations

import sys
from pathlib import Path

OLD_ROOT = Path(__file__).resolve().parents[1] / "vendor" / "frozen_old"

_loaded = False


def load_old():
    """Import the frozen modules once; returns the analysis.common module."""
    global _loaded
    if not _loaded:
        sys.path.insert(0, str(OLD_ROOT))
        import warnings
        warnings.filterwarnings("ignore")   # KMeans deprecation noise only
        import analysis.common as C
        import analysis.primary_action_strata as PAS  # noqa: F401
        from bufferdiag import project as _proj  # noqa: F401
        _loaded = True
        globals()["C"] = C
        globals()["PAS"] = PAS
        globals()["_proj"] = _proj
    return globals()["C"]


def classify_city(cd, radius: float, n_rep: int) -> dict:
    """Pure computation entry of analysis/primary_action_strata.py.

    classify_city fits no model and writes nothing; the module's main() would
    write results/primary_action_strata.json, so main() is never called.
    """
    load_old()
    return PAS.classify_city(cd, radius, n_rep)


def to_utm(lon, lat):
    """Per-city WGS84 -> UTM exactly as the frozen loader does it."""
    load_old()
    return _proj.to_utm(lon, lat)

