# -*- coding: utf-8 -*-
"""C: spatial block pruning + shared-quota interval closing + ordered scan.

Three arms share one implementation (work order sec. 4, P0-C):

* ``c1``  -- C1 only.  City points are partitioned into a rectangular grid.
  Per fold the candidate members per block are counted by class.  A block is
  *all-keep* when its conservative lower bound exceeds the radius,

      d(center_B, nearest test) - covering_radius_B > r + margin,

  (triangle inequality; the margin has an absolute floor and a
  scale-dependent float64 guard; blocks near the boundary fall back to exact
  checking instead of being pruned), and *all-delete* when
  ``d(center_B, nearest test) + covering_radius_B <= r - margin``.  Non-finite
  derived bounds are uncertain as well. Every remaining row is exactly
  checked; the common
  quota is the plain min of exact per-fold counts; selection is the
  vectorised prefix over the complete kept mask.

* ``c2``  -- C1 + C2 shared-quota intervals.  Per fold and class the kept
  count is bracketed as [L, U], L the proven-kept rows, U additionally
  counting undecided rows; the shared quota lies in [min_f L_f, min_f U_f].
  Folds are exacted one at a time (fixed order, or "most likely binding
  first" = smallest U sum) until both ends coincide; any fold whose U drops
  below the floor proves the whole city-radius cell infeasible immediately.
  Selection tries the fast path first (unbuffered prefix fully qualified ->
  identical buffered selection, usable only because the quota is already
  fixed); only a failing fold's mask is completed.

* ``c``   -- the complete implementation: c2 plus the ordered scan with
  backfill.  With the exact quota fixed, each class walks its (key, row)
  rank order; rows in proven-keep blocks are accepted without distances,
  undecided rows are exactly checked in small batches, deleted rows are
  skipped, and the walk stops as soon as the quota is met -- rows beyond the
  prefix are never touched.  If the empirical qualification rate makes the
  scan look more expensive than one vectorised query of the fold's undecided
  rows, the fold falls back to the B1-style batch; the fallback and its cost
  are counted, never silent.  ``audit``/``stats`` exact every remaining row
  of a fold -- saved scans are a matched-path effect only and are never
  reported as audit savings.

Distance cache: every exactly-computed nearest-test distance is stored per
test mask (radius-independent), so batch radii and duplicate radii reuse it.
The cache key is the frozen test mask identity together with the frozen
coordinate version of the run; a changed mask or coordinates recomputes.

Candidate-only scan order: the class rank order is pre-filtered to the rows
that are *candidates of this fold* (``~T``) before any proof or selection
scan uses it.  The filtered order is the original stable order with the test
rows removed, so it selects the same prefix; the point is that the scan can
never query a test row against the tree built from itself (distance zero,
pure waste -- 321,012 such queries in the first P0 run).  The pre-filter is
built once per (mask, class) and its cost is part of the timed index phase.
"""
from __future__ import annotations

import time

import numpy as np
from scipy.spatial import cKDTree

from .contract import class_orders, roundoff_margin, select_prefix
from .inputs import _validate_radius
from .writers import EngineResult, Phases

ST_KEEP, ST_DELETE, ST_UNCERTAIN = 0, 1, 2


class BlockIndex:
    """Rectangular grid with dense storage for occupied blocks only."""

    def __init__(self, xy: np.ndarray, side: float):
        self.side = float(side)
        lo = xy.min(0)
        gx = np.floor((xy[:, 0] - lo[0]) / side).astype(np.int64)
        gy = np.floor((xy[:, 1] - lo[1]) / side).astype(np.int64)
        self.n_grid_cells = (int(gx.max()) + 1) * (int(gy.max()) + 1)
        _, self.block_id = np.unique(np.column_stack([gx, gy]), axis=0,
                                     return_inverse=True)
        nb = int(self.block_id.max()) + 1
        self.n_blocks = nb
        self.has_members = np.ones(nb, dtype=bool)
        sx = np.bincount(self.block_id, weights=xy[:, 0], minlength=nb)
        sy = np.bincount(self.block_id, weights=xy[:, 1], minlength=nb)
        cnt = np.bincount(self.block_id, minlength=nb).astype(np.float64)
        self.centroid = np.column_stack([sx, sy]) / np.maximum(cnt, 1)[:, None]
        with np.errstate(over="ignore", invalid="ignore"):
            d2 = ((xy - self.centroid[self.block_id]) ** 2).sum(1)
        order = np.argsort(self.block_id, kind="stable")
        bs = self.block_id[order]
        starts = np.flatnonzero(np.r_[True, bs[1:] != bs[:-1]])
        block_of_run = bs[starts]
        maxd2 = np.maximum.reduceat(d2[order], starts)
        self.cover_r = np.zeros(nb)
        self.cover_r[block_of_run] = np.sqrt(np.maximum(maxd2, 0.0))

    def counts(self, y: np.ndarray):
        nb = self.n_blocks
        pos = np.bincount(self.block_id[y == 1], minlength=nb)
        neg = np.bincount(self.block_id[y == 0], minlength=nb)
        return pos, neg, pos + neg


class CandidateEngine:
    """arm in {'c1','c2','c'}; policy in {'fixed','priority'} (c2/c only)."""

    def __init__(self, arm: str = "c", side: float = 500.0,
                 margin: float = 1e-6, batch_rows: int = 256,
                 policy: str = "priority"):
        assert arm in ("c1", "c2", "c")
        self.arm = arm
        self.side = float(side)
        self.margin = float(margin)
        self.batch_rows = int(batch_rows)
        self.policy = policy
        self.name = arm

    # ------------------------------------------------------------------
    def _ensure_blocks(self, ct, state):
        key = ("blocks", self.side)
        if key not in state:
            state[key] = BlockIndex(ct.xy, self.side)
        return state[key]

    def _ensure_mask(self, ct, state, key, te, blocks):
        m = state["masks"].setdefault(key, {})
        if "cand" not in m:
            m["cand"] = np.flatnonzero(~te)
            m["d_arr"] = np.full(len(ct), np.nan)
            m["tree"] = None
            labels = ct.label[m["cand"]]
            bid = blocks.block_id[m["cand"]]
            m["cc_pos"] = np.bincount(bid[labels == 1],
                                      minlength=blocks.n_blocks)
            m["cc_neg"] = np.bincount(bid[labels == 0],
                                      minlength=blocks.n_blocks)
            flag = np.zeros(len(ct), dtype=bool)
            flag[m["cand"]] = True
            m["is_cand"] = flag
        if "ord_c" not in m:
            # class rank order restricted to this fold's candidates; the
            # subsequence of the (key, row) order keeps the stable order
            flag = m["is_cand"]
            m["ord_c"] = [o[flag[o]] for o in state["orders"]]
        return m

    def _ensure_tree(self, ct, key, te, m):
        if m["tree"] is None:
            m["tree"] = cKDTree(ct.xy[te])
        return m["tree"]

    def _ensure_dcenter(self, ct, key, te, m, blocks, counters):
        if "d_center" in m:
            return m["d_center"]
        tree = self._ensure_tree(ct, key, te, m)
        present = np.flatnonzero((m["cc_pos"] + m["cc_neg"] > 0)
                                 & np.isfinite(blocks.centroid).all(axis=1)
                                 & np.isfinite(blocks.cover_r))
        dc = np.full(blocks.n_blocks, np.nan)
        if len(present):
            dc[present] = tree.query(blocks.centroid[present], k=1)[0]
        counters["n_block_center_queries"] += int(len(present))
        counters["n_blocks_with_candidates"] += int(len(present))
        m["d_center"] = dc
        return dc

    def _prune(self, state, key, radius, blocks, m, counters):
        """Per-block keep/delete/uncertain at this radius (cached per
        (mask, radius); duplicate radii hit the cache)."""
        pc = state.setdefault("prune", {})
        ck = (key, radius)
        if ck in pc:
            return pc[ck]
        dc = m["d_center"]
        status = np.full(blocks.n_blocks, ST_UNCERTAIN, dtype=np.uint8)
        if radius > 0:
            scale = np.maximum(np.maximum(np.abs(dc), np.abs(blocks.cover_r)),
                               abs(radius))
            slack = roundoff_margin(scale, self.margin)
            with np.errstate(over="ignore", invalid="ignore"):
                keep = ((dc - blocks.cover_r) > radius + slack)
                dele = ((dc + blocks.cover_r) <= radius - slack)
            keep &= np.isfinite(dc) & np.isfinite(blocks.cover_r)
            dele &= np.isfinite(dc) & np.isfinite(blocks.cover_r)
            status[keep] = ST_KEEP
            status[dele & ~keep] = ST_DELETE
        else:
            status[:] = ST_KEEP           # r = 0 keeps everything by contract
        # Count only blocks that actually hold candidates of this mask: the
        # grid has many empty positions (Moscow: 276 of 5,703 cells carry
        # city samples), and a ratio over the whole grid says nothing.
        present = (m["cc_pos"] + m["cc_neg"]) > 0
        st_present = status[present]
        counters["n_blocks_allkeep"] += int((st_present == ST_KEEP).sum())
        counters["n_blocks_alldelete"] += int((st_present == ST_DELETE).sum())
        counters["n_blocks_uncertain"] += int(
            (st_present == ST_UNCERTAIN).sum())
        counters["n_blocks_cand_total"] += int(present.sum())
        row_status = status[blocks.block_id]
        pc[ck] = (status, row_status)
        return status, row_status

    def _exact_rows(self, ct, key, te, m, rows, counters, stage="select"):
        """Exact NN distances for rows still unknown; counts the cache hits
        and attributes the work to the quota or the select stage.

        Rows are split by kind: training candidate rows (the only rows a
        correct implementation ever queries) and test rows of this same fold
        (a self-query: the test row is in its own tree, so the answer is
        always 0 and the query is pure waste).  The test-row counter is part
        of the acceptance -- it must stay 0."""
        d_arr = m["d_arr"]
        rows = np.asarray(rows)
        if len(rows) == 0:
            return 0
        unknown = rows[~np.isfinite(d_arr[rows])]
        # rows handed in that already carry a distance are cache reuse, even
        # when the caller pre-filtered nothing: counting only the fully
        # redundant calls would report 0 while the cache is doing its job
        counters["n_rows_cache_hits"] += int(len(rows) - len(unknown))
        if len(unknown) == 0:
            return 0
        n_test = int((~m["is_cand"][unknown]).sum())
        counters["n_rows_exact_train"] += int(len(unknown) - n_test)
        counters["n_rows_exact_test_self"] += n_test
        tree = self._ensure_tree(ct, key, te, m)
        d_arr[unknown] = tree.query(ct.xy[unknown], k=1)[0]
        counters["n_rows_exact"] += int(len(unknown))
        counters["n_rows_exact_%s" % stage] += int(len(unknown))
        counters["n_query_batches"] += 1
        return int(len(unknown))

    def _fold_intervals(self, key, radius, m, row_status):
        """[L_pos, U_pos, L_neg, U_neg] for one fold at one radius."""
        cand = m["cand"]
        y = self._y
        st_c = row_status[cand]
        d_c = m["d_arr"][cand]
        known = np.isfinite(d_c)
        pos_c = y[cand] == 1
        neg_c = ~pos_c
        lp = int(((st_c == ST_KEEP) & pos_c).sum()) + \
            int(((st_c == ST_UNCERTAIN) & known & (d_c > radius) & pos_c).sum())
        up_ = lp + int(((st_c == ST_UNCERTAIN) & ~known & pos_c).sum())
        ln = int(((st_c == ST_KEEP) & neg_c).sum()) + \
            int(((st_c == ST_UNCERTAIN) & known & (d_c > radius) & neg_c).sum())
        un_ = ln + int(((st_c == ST_UNCERTAIN) & ~known & neg_c).sum())
        return [lp, up_, ln, un_]

    def _fold_exact_counts(self, key, radius, m, row_status):
        """Exact kept counts of one fold as a collapsed interval
        [p, p, n, n] (after exacting, L == U == the true count)."""
        cand = m["cand"]
        y = self._y
        st_c = row_status[cand]
        d_c = m["d_arr"][cand]
        pos_c = y[cand] == 1
        kept_c = (st_c == ST_KEEP) | ((st_c == ST_UNCERTAIN) & (d_c > radius))
        p = int((kept_c & pos_c).sum())
        ng = int((kept_c & ~pos_c).sum())
        return [p, p, ng, ng]

    # ------------------------------------------------------------------
    def run_city(self, ct, folds, radii, output, state=None, floor: int = 5,
                 prescribed=None):
        """``prescribed`` (closeout 8.1): optional {radius: [(qp, qn), ...]}
        or {radius: None} supplying the per-repeat common quotas as an
        external input; the interval-closing quota stage is skipped entirely
        (its acquisition cost is excluded by construction) but the per-block
        prune state selection needs is still built."""
        t_start = time.perf_counter()
        ph = Phases()
        counters = {"engine": self.name, "arm": self.arm,
                    "block_side_m": self.side, "policy": self.policy,
                    "n_blocks_grid": 0, "n_blocks_total": 0,
                    "n_blocks_cand_total": 0, "n_blocks_allkeep": 0,
                    "n_blocks_alldelete": 0, "n_blocks_uncertain": 0,
                    "n_blocks_with_candidates": 0,
                    "n_block_center_queries": 0,
                    "n_rows_exact": 0, "n_rows_cache_hits": 0,
                    "n_rows_exact_train": 0, "n_rows_exact_test_self": 0,
                    "n_rows_exact_quota": 0, "n_rows_exact_select": 0,
                    "n_query_batches": 0, "n_quota_picks": 0,
                    "n_quota_folds_deferred_max": 0, "n_fast_path": 0,
                    "n_fast_path_fail": 0, "n_scan_rows_examined": 0,
                    "n_scan_batches": 0, "n_fallbacks": 0,
                    "n_fallback_rows": 0, "n_scan_direct_exhaust": 0}
        self._y = ct.label
        radii = [_validate_radius(r) for r in radii]

        state = {} if state is None else state
        if "orders" not in state:
            state["orders"] = class_orders(ct.label, ct.keys)
        state.setdefault("masks", {})

        # ---- index: blocks + per-mask candidate counts + block-test dists ----
        t0 = time.perf_counter()
        blocks = self._ensure_blocks(ct, state)
        counters["n_blocks_grid"] = int(blocks.n_grid_cells)
        counters["n_blocks_total"] = int(blocks.has_members.sum())
        for rep in range(folds.n_repeats):
            for geom, k, te in folds.repeat_folds(rep):
                key = ("b", k) if geom == 0 else ("s", rep, k)
                m = self._ensure_mask(ct, state, key, te, blocks)
                self._ensure_dcenter(ct, key, te, m, blocks, counters)
        ph.index = time.perf_counter() - t0

        res = EngineResult(dataset=ct.dataset, city=ct.city,
                           phases=ph, counters=counters)
        usable = bool(folds.usable)

        for radius in radii:
            t_quota = t_exact = t_select = 0.0
            quotas = []
            feasible_all = usable
            note = "" if usable else "no usable units"
            if prescribed is not None:
                # external quotas: prune state for selection is still built,
                # but no interval is computed and no fold is exacted for the
                # quota -- that acquisition cost is what this mode excludes
                counters["quota_source"] = "prescribed"
                pres = prescribed.get(radius)
                quotas = ([(int(qp), int(qn)) for qp, qn in pres]
                          if pres is not None
                          else [(-1, -1)] * folds.n_repeats)
                feasible_all = usable and pres is not None and all(
                    qp >= floor and qn >= floor for qp, qn in pres)
                if usable and pres is None:
                    note = "prescribed quota missing"
                elif not feasible_all and usable:
                    note = "prescribed quota infeasible"
                for rep in range(folds.n_repeats):
                    for geom, k, te in folds.repeat_folds(rep):
                        key = ("b", k) if geom == 0 else ("s", rep, k)
                        m = state["masks"][key]
                        self._prune(state, key, radius, blocks, m, counters)
            else:
                for rep in range(folds.n_repeats):
                    tq0 = time.perf_counter()
                    fold_keys, intervals = [], {}
                    for geom, k, te in folds.repeat_folds(rep):
                        key = ("b", k) if geom == 0 else ("s", rep, k)
                        m = state["masks"][key]
                        self._prune(state, key, radius, blocks, m, counters)
                        fold_keys.append((key, te, m))
                        intervals[key] = self._fold_intervals(
                            key, radius, m, state["prune"][(key, radius)][1])
                    q_rep, feasible = self._close_quota(
                        ct, state, radius, floor, fold_keys, intervals,
                        counters)
                    t_quota += time.perf_counter() - tq0
                    quotas.append(q_rep)
                    if not feasible:
                        feasible_all = False
                        note = "budget infeasible"
            res.quota[radius] = quotas
            res.status[radius] = {"feasible": feasible_all,
                                  "budgets": quotas if feasible_all else None,
                                  "note": note}
            ph.quota += t_quota

            if not feasible_all:
                res.matched[radius] = []
                if output == "audit":
                    res.audit[radius] = []
                if output == "stats":
                    res.stats[radius] = []
                continue

            comps, auds, stats = [], [], []
            for rep in range(folds.n_repeats):
                qp, qn = quotas[rep]
                for geom, k, te in folds.repeat_folds(rep):
                    key = ("b", k) if geom == 0 else ("s", rep, k)
                    m = state["masks"][key]
                    row_status = state["prune"][(key, radius)][1]
                    if output in ("stats", "audit"):
                        # audit/stats need an exact decision only for rows the
                        # block bounds could not decide; proven-keep rows are
                        # kept and proven-delete rows deleted without a query
                        te0 = time.perf_counter()
                        undecided = m["cand"][
                            row_status[m["cand"]] == ST_UNCERTAIN]
                        self._exact_rows(ct, key, te, m, undecided, counters)
                        t_exact += time.perf_counter() - te0
                    ts0 = time.perf_counter()
                    comp, aud, st = self._comparison(
                        ct, state, key, te, m, radius, qp, qn, row_status,
                        output, counters)
                    t_select += time.perf_counter() - ts0
                    comp.update({"rep": rep, "geom": geom, "fold": k})
                    if aud is not None:
                        aud.update({"rep": rep, "geom": geom, "fold": k})
                    if st is not None:
                        st.update({"rep": rep, "geom": geom, "fold": k})
                    comps.append(comp)
                    if aud is not None:
                        auds.append(aud)
                    if st is not None:
                        stats.append(st)
            res.matched[radius] = comps
            if output == "audit":
                res.audit[radius] = auds
            if output == "stats":
                res.stats[radius] = stats
            ph.exact += t_exact
            ph.select += t_select

        ph.total = time.perf_counter() - t_start
        return res, state

    # ------------------------------------------------------------------
    def _close_quota(self, ct, state, radius, floor, fold_keys, intervals,
                     counters):
        """Exact shared quota via C2 intervals (c1: exact everything)."""
        if not fold_keys:
            return (-1, -1), False              # no usable fold this repeat
        if radius == 0:
            for v in intervals.values():
                v[1] = v[0]
                v[3] = v[2]
            lp = min(v[0] for v in intervals.values())
            ln = min(v[2] for v in intervals.values())
            return (lp, ln), (lp >= floor and ln >= floor)

        if self.arm == "c1":
            # only undecided rows need a distance: proven-keep rows stay kept
            # and proven-delete rows stay deleted regardless of their exact
            # distance, so handing the whole pool to _exact_rows (the old
            # call) silently queried proven-delete rows the ablation never
            # declared
            for key, te, m in fold_keys:
                row_status = state["prune"][(key, radius)][1]
                if intervals[key][0] != intervals[key][1] or \
                        intervals[key][2] != intervals[key][3]:
                    undecided = m["cand"][
                        row_status[m["cand"]] == ST_UNCERTAIN]
                    self._exact_rows(ct, key, te, m, undecided, counters,
                                     "quota")
                    intervals[key] = self._fold_exact_counts(
                        key, radius, m, row_status)
                counters["n_quota_picks"] += 1
            lp = min(v[0] for v in intervals.values())
            ln = min(v[2] for v in intervals.values())
            return (lp, ln), (lp >= floor and ln >= floor)

        exacted = set()
        while True:
            lp = min(v[0] for v in intervals.values())
            up_ = min(v[1] for v in intervals.values())
            ln = min(v[2] for v in intervals.values())
            un_ = min(v[3] for v in intervals.values())
            if up_ < floor or un_ < floor:
                return (-1, -1), False          # proven infeasible
            if lp == up_ and ln == un_:
                return (lp, ln), (lp >= floor and ln >= floor)
            # pending = folds neither collapsed nor already proven to hold at
            # least the current candidate quota in BOTH classes; a proven
            # fold can never bind the quota below the current bound and the
            # bound only decreases, so its exclusion stays valid
            pending = [i for i, (key, _, _) in enumerate(fold_keys)
                       if key not in exacted
                       and not (intervals[key][0] >= up_
                                and intervals[key][2] >= un_)]
            if not pending:
                # every fold is collapsed or proven -> the interval is closed
                return (lp, ln), (lp >= floor and ln >= floor)
            if self.policy == "priority":
                pick = min(pending, key=lambda i: (
                    intervals[fold_keys[i][0]][1]
                    + intervals[fold_keys[i][0]][3],
                    intervals[fold_keys[i][0]][0]
                    + intervals[fold_keys[i][0]][2], i))
            else:
                pick = pending[0]
            key, te, m = fold_keys[pick]
            row_status = state["prune"][(key, radius)][1]
            # prove-or-collapse by ordered scan: a fold is deferred as soon
            # as its scan finds at least the current candidate quota ("其他
            # 折一旦证实已有至少该上界数量的合格行，可暂缓其余检查")
            itv = self._prove_fold_by_scan(ct, key, te, m, radius, row_status,
                                           up_, un_, counters)
            intervals[key] = itv
            if itv[0] == itv[1] and itv[2] == itv[3]:
                exacted.add(key)
            counters["n_quota_picks"] += 1
            counters["n_quota_folds_deferred_max"] = max(
                counters["n_quota_folds_deferred_max"],
                len(fold_keys) - len(exacted))

    def _unknown_rows(self, m, key, radius, state):
        cand = m["cand"]
        row_status = state["prune"][(key, radius)][1]
        return cand[(row_status[cand] == ST_UNCERTAIN)
                    & ~np.isfinite(m["d_arr"][cand])]

    def _prove_fold_by_scan(self, ct, key, te, m, radius, row_status,
                            bound_pos, bound_neg, counters):
        """Prove a fold holds >= bound qualifying rows per class by scanning
        its (key, row) rank order -- the same primitive the selection scan
        uses.  A scan that finds the target proves L >= target ("证实已有
        至少该上界数量的合格行"); a scan that exhausts the order yields the
        exact kept count and collapses the interval.  Distances exacted
        along the way are cached for every later radius and selection.

        The order scanned is the fold's candidate-only order (``m["ord_c"]``):
        the fold's own test rows are not pool members and must never be
        queried, let alone counted as qualifying."""
        Lp, Up, Ln, Un = self._fold_intervals(key, radius, m, row_status)
        for cls, oi, target in ((1, 0, bound_pos), (0, 1, bound_neg)):
            if target <= 0 or target <= (Lp if cls == 1 else Ln):
                continue                       # already proven or vacuous
            sel = self._scan_class(ct, key, te, m, radius, oi, target,
                                   row_status, counters, stage="quota")
            if len(sel) >= target:
                if cls == 1:
                    Lp = max(Lp, target)
                else:
                    Ln = max(Ln, target)
            else:                              # exhausted -> exact count
                if cls == 1:
                    Lp = Up = len(sel)
                else:
                    Ln = Un = len(sel)
        return [Lp, Up, Ln, Un]

    # ------------------------------------------------------------------
    def _comparison(self, ct, state, key, te, m, radius, qp, qn,
                    row_status, output, counters):
        """One fold's matched comp (+ audit/stats payloads on request)."""
        y = ct.label
        cand = m["cand"]
        d_arr = m["d_arr"]
        n = len(y)
        pool_u = np.zeros(n, dtype=bool)
        pool_u[cand] = True
        u = np.concatenate([select_prefix(state["orders"][0], pool_u, qp),
                            select_prefix(state["orders"][1], pool_u, qn)])
        if radius == 0:
            buf, fast = u, True
        elif self.arm == "c1":
            # only undecided rows need exacting; the buffered pool is built
            # from the row status, not a raw distance test, so proven-keep
            # rows qualify by their block proof even before any distance is
            # known (and proven-delete rows never enter, query or no query)
            undecided = cand[row_status[cand] == ST_UNCERTAIN]
            self._exact_rows(ct, key, te, m, undecided, counters, "select")
            kept_c = ((row_status[cand] == ST_KEEP)
                      | ((row_status[cand] == ST_UNCERTAIN)
                         & (d_arr[cand] > radius)))
            pool_b = np.zeros(n, dtype=bool)
            pool_b[cand[kept_c]] = True
            fast = bool(pool_b[u].all()) if len(u) else True
            buf = u if fast else np.concatenate(
                [select_prefix(state["orders"][0], pool_b, qp),
                 select_prefix(state["orders"][1], pool_b, qn)])
        elif self.arm == "c2":
            buf, fast = self._c2_select(ct, state, key, te, m, radius,
                                        qp, qn, row_status, u, counters)
        else:
            buf = self._scan_buffered(ct, state, key, te, m, radius, qp, qn,
                                      row_status, u, counters)
            fast = bool(np.array_equal(buf, u))
        if fast:
            counters["n_fast_path"] += 1
        else:
            counters["n_fast_path_fail"] += 1

        up, un = u[y[u] == 1], u[y[u] == 0]
        bp, bn = buf[y[buf] == 1], buf[y[buf] == 0]
        comp = {"quota": (qp, qn), "fast_path": fast,
                "unbuf_pos": up, "unbuf_neg": un,
                "buf_pos": bp, "buf_neg": bn}

        aud = st = None
        if output in ("audit", "stats"):
            keep_cand = ((row_status[cand] == ST_KEEP)
                         | ((row_status[cand] == ST_UNCERTAIN)
                            & (d_arr[cand] > radius)))
            kept_idx = cand[keep_cand]
            del_idx = cand[~keep_cand]
            labels = y[kept_idx]
            if output == "audit":
                aud = {"kept_idx": kept_idx, "del_idx": del_idx,
                       "n_kept": len(kept_idx), "n_deleted": len(del_idx),
                       "n_cand": len(cand), "cand_idx": cand}
            else:
                st = {"quota": (qp, qn), "n_cand": len(cand),
                      "n_kept": len(kept_idx),
                      "n_deleted": len(del_idx),
                      "kept_pos": int((labels == 1).sum()),
                      "kept_neg": int((labels == 0).sum())}
        return comp, aud, st

    # ------------------------------------------------------------------
    def _c2_select(self, ct, state, key, te, m, radius, qp, qn,
                   row_status, u, counters):
        """c2 arm: fast path per class; a failing class completes the fold's
        kept mask and selects by the vectorised prefix (no ordered scan)."""
        y = ct.label
        d_arr = m["d_arr"]
        cand = m["cand"]
        n = len(y)
        pool_b = None
        fast = True
        parts = []
        for cls, oi, q in ((1, 0, qp), (0, 1, qn)):
            if q == 0:
                parts.append(np.zeros(0, dtype=np.int64))
                continue
            u_cls = u[y[u] == cls]
            st_u = row_status[u_cls]
            d_u = d_arr[u_cls]
            need = (st_u == ST_UNCERTAIN) & ~np.isfinite(d_u)
            if need.any():
                self._exact_rows(ct, key, te, m, u_cls[need], counters,
                                 "select")
                d_u = d_arr[u_cls]
                st_u = row_status[u_cls]
            ok = ((st_u == ST_KEEP)
                  | ((st_u == ST_UNCERTAIN) & np.isfinite(d_u)
                     & (d_u > radius)))
            if ok.all():
                parts.append(u_cls)              # fast path
                continue
            fast = False
            if pool_b is None:
                # same rule as the c1 arm: exact undecided rows only, and
                # build the pool from the row status so proven-keep rows
                # qualify by proof even when no distance was ever computed
                # for them (a NaN distance must not drop them from the pool)
                undecided = cand[row_status[cand] == ST_UNCERTAIN]
                self._exact_rows(ct, key, te, m, undecided, counters,
                                 "select")
                kept_c = ((row_status[cand] == ST_KEEP)
                          | ((row_status[cand] == ST_UNCERTAIN)
                             & (d_arr[cand] > radius)))
                pool_b = np.zeros(n, dtype=bool)
                pool_b[cand[kept_c]] = True
            parts.append(select_prefix(state["orders"][oi], pool_b, q))
        return np.concatenate(parts), fast

    # ------------------------------------------------------------------
    def _scan_buffered(self, ct, state, key, te, m, radius, qp, qn,
                       row_status, u, counters):
        """Ordered scan with backfill; per class, stops at the quota."""
        y = ct.label
        d_arr = m["d_arr"]
        out_parts = []
        for oi, q in ((0, qp), (1, qn)):
            if q == 0:
                out_parts.append(np.zeros(0, dtype=np.int64))
                continue
            u_cls = u[y[u] == (1 - oi)]     # order 0 = positives, 1 = negatives
            st_u = row_status[u_cls]
            d_u = d_arr[u_cls]
            need = (st_u == ST_UNCERTAIN) & ~np.isfinite(d_u)
            if need.any():
                self._exact_rows(ct, key, te, m, u_cls[need], counters)
                d_u = d_arr[u_cls]
                st_u = row_status[u_cls]
            ok = ((st_u == ST_KEEP)
                  | ((st_u == ST_UNCERTAIN) & np.isfinite(d_u)
                     & (d_u > radius)))
            if ok.all():
                out_parts.append(u_cls)          # fast path
                continue
            sel = self._scan_class(ct, key, te, m, radius, oi, q,
                                   row_status, counters)
            out_parts.append(sel)
        return np.concatenate(out_parts)

    def _scan_class(self, ct, key, te, m, radius, oi, q, row_status,
                    counters, stage="select"):
        """Walk the class rank order (candidates of this fold only); stop at
        q qualifying rows.

        ``oi`` is 0 for positives and 1 for negatives; the order used is
        ``m["ord_c"][oi]`` -- the whole-city class order with this fold's test
        rows removed, order preserved.  Undecided rows are exacted
        window-by-window (one vectorised query per window of
        ``self.batch_rows`` order positions), never row by row; rows beyond
        the stop position stay cached for later radii and are counted as
        prefetch work.  Rows in proven-keep blocks (and undecided rows already
        carrying a cached distance above the radius) qualify for free, so the
        fallback estimate subtracts them before comparing against one
        whole-fold vectorised query.  The fallback and its cost are counted,
        never silent."""
        order = m["ord_c"][oi]
        d_arr = m["d_arr"]
        cand = m["cand"]
        st_o = row_status[order]
        d_o = d_arr[order]
        keep_total = int((st_o == ST_KEEP).sum())
        cached_total = int(((st_o == ST_UNCERTAIN) & np.isfinite(d_o)
                            & (d_o > radius)).sum())
        unknown_in_class = int(((st_o == ST_UNCERTAIN)
                                & ~np.isfinite(d_o)).sum())
        if q > keep_total + cached_total + unknown_in_class:
            # the target is unreachable in this class: the scan would exhaust
            # anyway, so exact everything in one vectorised query and return
            # the complete qualifying prefix (the exact kept count)
            counters["n_scan_direct_exhaust"] += 1
            unk_rows = order[(st_o == ST_UNCERTAIN) & ~np.isfinite(d_o)]
            self._exact_rows(ct, key, te, m, unk_rows, counters, stage)
            d_o = d_arr[order]
            st_o = row_status[order]
            qual = ((st_o == ST_KEEP)
                    | ((st_o == ST_UNCERTAIN) & np.isfinite(d_o)
                       & (d_o > radius)))
            return order[qual]
        keep_seen = 0
        cached_seen = 0
        found = 0
        parts = []
        pos = 0
        inspected = 0
        checked_unknown = 0
        qual_unknown = 0
        N = len(order)
        while found < q and pos < N:
            window = slice(pos, min(pos + self.batch_rows, N))
            w_rows = order[window]
            w_unknown = (row_status[w_rows] == ST_UNCERTAIN) & \
                ~np.isfinite(d_arr[w_rows])
            if w_unknown.any():
                rate = (qual_unknown / checked_unknown) if checked_unknown \
                    else 1.0
                free_remaining = ((keep_total - keep_seen)
                                  + (cached_total - cached_seen))
                est_checks = max(q - found - free_remaining, 0) \
                    / max(rate, 0.05)
                unknown_left_fold = int(
                    ((row_status[cand] == ST_UNCERTAIN)
                     & ~np.isfinite(d_arr[cand])).sum())
                if est_checks > unknown_left_fold:
                    counters["n_fallbacks"] += 1
                    counters["n_fallback_rows"] += self._exact_rows(
                        ct, key, te, m, cand, counters, stage)
                else:
                    counters["n_scan_batches"] += 1
                    self._exact_rows(ct, key, te, m, w_rows[w_unknown],
                                     counters, stage)
            # walk this window with all its distances available
            end = window.stop
            while pos < end and found < q:
                chunk = order[pos:min(pos + 256, end)]
                st_c = row_status[chunk]
                d_c = d_arr[chunk]
                qual = ((st_c == ST_KEEP)
                        | ((st_c == ST_UNCERTAIN) & np.isfinite(d_c)
                           & (d_c > radius)))
                newly = (st_c == ST_UNCERTAIN) & np.isfinite(d_c)
                if newly.any():
                    checked_unknown += int(newly.sum())
                    qual_unknown += int((newly & (d_c > radius)).sum())
                keep_seen += int((st_c == ST_KEEP).sum())
                cached_seen += int(((st_c == ST_UNCERTAIN) & np.isfinite(d_c)
                                    & (d_c > radius)).sum())
                positions = np.flatnonzero(qual)
                need = q - found
                take = min(need, len(positions))
                if take:
                    parts.append(chunk[positions[:take]])
                    found += take
                    inspected = pos + int(positions[take - 1]) + 1
                pos += 256
                if found >= q:
                    break
            if found < q:
                inspected = max(inspected, end)
            # rows exacted in the window beyond the stop position count as
            # prefetch (cached for the next radius), never as savings
        counters["n_scan_rows_examined"] += inspected
        return (np.concatenate(parts) if parts
                else np.zeros(0, dtype=np.int64))
