# -*- coding: utf-8 -*-
"""verify: row-by-row comparison of every engine against the old functions.

The oracle is the reference export from prepare (produced by the frozen
``analysis.common`` functions themselves: ``buffered_pool``, ``common_budget``,
``subsample``).  For every city, sweep radius, repeat, geometry and usable
fold, verify compares:

* the common budgets (quotas) and cell feasibility, and
* both arms' ordered training IDs -- sequence equality over positions and
  multiplicities, plus the multiset symmetric difference, and
* the audit pools -- complete kept/deleted ID sequences and sets, and
* the contiguous-block action counts of the reference export against the
  frozen ``results/primary_action_strata.json`` golden numbers.

Acceptance is aligned with what is actually delivered: every engine is run
for **both outputs** (``matched`` and ``audit``) and from **both** an empty
state and a reused (hot) state, because the hot path is a different code path
(the bounded KD-tree cache lives there).  Per radius the comparison also
checks that the output's fold keys are complete and unique, and that a status
record exists for every requested radius and repeat.

Two outcomes are kept apart on purpose:

* ``n_bad`` -- a row, quota, pool or cell disagrees with the old functions;
* ``n_missing_status`` -- the run produced no status record (or a rejection
  without a reason) for a requested radius.  A run summary of "zero diff" is
  not the same finding as "the cell was never recorded".

The bounded-KD-tree hot-cache regression (radius raised on a reused state) is
part of the suite: cheap to run, and it is the case the first P0 run got
wrong.

First mismatch wins: verify writes a minimal reproduction of the first
difference to ``first_diff_repro.json`` and exits nonzero.
"""
from __future__ import annotations

import csv as _csv
import json
from pathlib import Path

import numpy as np

from .baseline_b1 import B1Engine
from .candidate import CandidateEngine
from .ref_b0 import B0Engine
from .prepare import Reference
from .contract import CityFolds
from .inputs import CityTable
from .settings import ROOT, suite_cities
from .writers import GEOM_NAMES

BOUNDARY_EPS = 5e-9      # half the bounded-query margin (1e-8), in metres


def load_city_inputs(run_dir: Path, ds: str, city: str):
    """Rebuild (CityTable, CityFolds) from the frozen input export."""
    z = np.load(run_dir / "inputs" / ("%s__%s.npz" % (ds, city)))
    ct = CityTable(dataset=ds, city=city, manifest=None, manifest_sha256="",
                   orig_row=z["orig_row"], biz_id=z["biz_id"],
                   label=z["y"], xy=z["xy"], keys=z["keys"],
                   zone=int(z["zone"]) if int(z["zone"]) > 0 else None,
                   southern=bool(z["southern"]), provenance={})
    blocks = [z["blocks"][k] for k in range(int(z["n_blocks"]))]
    per_rep = [int(v) for v in z["n_scatter_per_rep"].tolist()]
    flat = z["scatter"]
    scatter, o = [], 0
    for cnt in per_rep:
        scatter.append([flat[o + i] for i in range(cnt)])
        o += cnt
    return ct, CityFolds(blocks, scatter)


def _arm_diff(a: np.ndarray, b: np.ndarray) -> tuple[int, int]:
    """(ordered position diffs incl. length gap, multiset symmetric diff)."""
    ordered = int(sum(1 for i in range(min(len(a), len(b))) if a[i] != b[i]))
    ordered += abs(len(a) - len(b))
    sa, sb = np.sort(np.asarray(a)), np.sort(np.asarray(b))
    multiset, i, j = 0, 0, 0
    while i < len(sa) and j < len(sb):
        if sa[i] == sb[j]:
            i += 1
            j += 1
        elif sa[i] < sb[j]:
            multiset += 1
            i += 1
        else:
            multiset += 1
            j += 1
    multiset += (len(sa) - i) + (len(sb) - j)
    return ordered, int(multiset)


def _mk_engines(eng_cfg: dict, policy="priority"):
    side = float(eng_cfg["block_grid_side_m"])
    margin = float(eng_cfg["block_float_margin_m"])
    batch = int(eng_cfg["scan_batch_rows"])
    return [
        B1Engine(),
        B1Engine(bounded=True),
        CandidateEngine(arm="c1", side=side, margin=margin, batch_rows=batch),
        CandidateEngine(arm="c2", side=side, margin=margin, batch_rows=batch,
                        policy=policy),
        CandidateEngine(arm="c", side=side, margin=margin, batch_rows=batch,
                        policy=policy),
    ]


# ---------------------------------------------------------------------------
# status coverage: a distinct acceptance outcome, never folded into n_bad
# ---------------------------------------------------------------------------
def _status_gaps(folds, res, radii) -> list[str]:
    gaps = []
    for r in radii:
        r = float(r)
        st = res.status.get(r)
        if st is None:
            gaps.append("r=%g:no_status" % r)
            continue
        q = res.quota.get(r)
        if q is None:
            gaps.append("r=%g:no_quota" % r)
        elif len(q) != folds.n_repeats:
            gaps.append("r=%g:repeats=%d/%d" % (r, len(q), folds.n_repeats))
        if st.get("feasible"):
            if not st.get("budgets"):
                gaps.append("r=%g:feasible_without_budget" % r)
        else:
            if not st.get("note"):
                gaps.append("r=%g:rejected_without_reason" % r)
    return gaps


def _concludable_no_rows(folds, res, radii) -> list[str]:
    """Feasible radii that produced no comparison rows at all."""
    bad = []
    for r in radii:
        r = float(r)
        if (res.status.get(r) or {}).get("feasible") and not res.matched.get(r):
            bad.append("r=%g" % r)
    return bad


def _compare_result(ct, folds, ref, eng, res, radii, output, repro, tag,
                    subset, missing_status):
    """Compare one completed engine run against the reference."""
    rows = []
    n_ok = n_bad = 0
    for r in radii:
        r = float(r)
        base = dict(dataset=ct.dataset, city=ct.city, radius=r,
                    geometry="*", repeat=-1, fold=-1,
                    method=eng.name + tag, arm="status")
        if subset is not None:
            # B0 spot check on a subset of folds: the cell quota is computed
            # from the subset alone and is therefore not comparable, but the
            # audited pool of a fold does not depend on the quota at all.
            rows.append(dict(base, match=True, ordered_diff=0,
                             multiset_diff=0, pool_kept_diff=0,
                             pool_del_diff=0, quota_old="", quota_new="",
                             note="subset mode: cell status and arms skipped"))
            old_a = {(rep, geom, fold): (cand, kept, dele)
                     for rep, geom, fold, cand, kept, dele in ref.audit(r)}
            new_a = {(a["rep"], a["geom"], a["fold"]): a
                     for a in res.audit.get(r, [])}
            for key in sorted(k for k in old_a if k in subset):
                a_old, a_new = old_a[key], new_a.get(key)
                if a_new is None:
                    rows.append(dict(base, match=False, ordered_diff=-1,
                                     multiset_diff=-1, pool_kept_diff=-1,
                                     pool_del_diff=-1, quota_old="",
                                     quota_new="",
                                     note="audited fold missing for %s"
                                          % (key,)))
                    n_bad += 1
                    continue
                kd = _arm_diff(a_new["kept_idx"], a_old[1])
                dd = _arm_diff(a_new["del_idx"], a_old[2])
                total = kd[0] + kd[1] + dd[0] + dd[1]
                rows.append(dict(base, geometry=GEOM_NAMES[key[1]],
                                 repeat=key[0], fold=key[2], arm="pool",
                                 match=(total == 0),
                                 ordered_diff=kd[0], multiset_diff=kd[1],
                                 pool_kept_diff=kd[0] + kd[1],
                                 pool_del_diff=dd[0] + dd[1],
                                 quota_old="", quota_new="",
                                 note="subset pool check (quota-free)"))
                n_ok += total == 0
                n_bad += total != 0
            continue
        rst, ost = res.status[r], ref.status(r)
        if rst["feasible"] != ost["feasible"]:
            rows.append(dict(base, match=False, ordered_diff=-1,
                             multiset_diff=-1, pool_kept_diff=-1,
                             pool_del_diff=-1, quota_old="", quota_new="",
                             note="feasible old=%s new=%s"
                                  % (ost["feasible"], rst["feasible"])))
            n_bad += 1
            _dump_repro(repro, ct, r, -1, -1, -1, "feasibility",
                        "old=%s new=%s" % (ost["feasible"], rst["feasible"]))
            continue
        if not ost["feasible"]:
            rows.append(dict(base, match=True, ordered_diff=0,
                             multiset_diff=0, pool_kept_diff=0,
                             pool_del_diff=0, quota_old="", quota_new="",
                             note="both infeasible"))
            n_ok += 1
            continue
        old_b = np.asarray(ost["budgets"])
        new_b = np.asarray(rst["budgets"])
        if not np.array_equal(old_b, new_b):
            rows.append(dict(base, match=False, ordered_diff=-1,
                             multiset_diff=-1, pool_kept_diff=-1,
                             pool_del_diff=-1,
                             quota_old=str(old_b.tolist()),
                             quota_new=str(new_b.tolist()),
                             note="budget mismatch"))
            n_bad += 1
            _dump_repro(repro, ct, r, -1, -1, -1, "budgets",
                        "old=%s new=%s" % (old_b.tolist(), new_b.tolist()))
            continue
        old_m = {(rep, geom, fold): (up, un, bp, bn)
                 for rep, geom, fold, up, un, bp, bn in ref.matched(r)}
        new_m = {(c["rep"], c["geom"], c["fold"]): c
                 for c in res.matched[r]}
        old_a = {(rep, geom, fold): (cand, kept, dele)
                 for rep, geom, fold, cand, kept, dele in ref.audit(r)}
        new_a = {(a["rep"], a["geom"], a["fold"]): a
                 for a in res.audit.get(r, [])}
        # fold keys must be complete and unique: one comparison per
        # (repeat, geometry, fold), no duplicates, nothing missing
        expected = {(rep, geom, k) for rep in range(folds.n_repeats)
                    for geom, k, te in folds.repeat_folds(rep)}
        dupes = len(res.matched[r]) - len(new_m)
        if set(new_m) != expected or dupes:
            rows.append(dict(base, match=False, ordered_diff=-1,
                             multiset_diff=-1, pool_kept_diff=-1,
                             pool_del_diff=-1, quota_old=str(len(expected)),
                             quota_new=str(len(new_m)),
                             note="fold keys missing=%d duplicate=%d"
                                  % (len(expected - set(new_m)), dupes)))
            n_bad += 1
            _dump_repro(repro, ct, r, -1, -1, -1, "fold_keys",
                        "missing=%s duplicate=%d"
                        % (sorted(expected - set(new_m))[:3], dupes))
        keys = sorted(old_m) if subset is None else \
            sorted(k for k in old_m if k in subset)
        for key in keys:
            up, un, bp, bn = old_m[key]
            c = new_m.get(key)
            if c is None:
                rows.append(dict(base, match=False, ordered_diff=-1,
                                 multiset_diff=-1, pool_kept_diff=-1,
                                 pool_del_diff=-1, quota_old="", quota_new="",
                                 note="comparison missing for %s" % (key,)))
                n_bad += 1
                continue
            d1 = _arm_diff(c["unbuf_pos"], up)
            d2 = _arm_diff(c["unbuf_neg"], un)
            d3 = _arm_diff(c["buf_pos"], bp)
            d4 = _arm_diff(c["buf_neg"], bn)
            kd = dd = (0, 0)
            if output == "audit":
                a_old, a_new = old_a[key], new_a[key]
                kd = _arm_diff(a_new["kept_idx"], a_old[1])
                dd = _arm_diff(a_new["del_idx"], a_old[2])
            total = sum(x[0] + x[1] for x in (d1, d2, d3, d4, kd, dd))
            rows.append(dict(
                dataset=ct.dataset, city=ct.city, radius=r,
                geometry=GEOM_NAMES[key[1]], repeat=key[0], fold=key[2],
                method=eng.name + tag, arm="both",
                match=(total == 0),
                ordered_diff=d1[0] + d2[0] + d3[0] + d4[0] + kd[0],
                multiset_diff=d1[1] + d2[1] + d3[1] + d4[1] + dd[1],
                pool_kept_diff=kd[0] + kd[1],
                pool_del_diff=dd[0] + dd[1],
                quota_old="%d/%d" % (old_b[key[0]][0], old_b[key[0]][1]),
                quota_new="%d/%d" % tuple(c["quota"]), note=""))
            if total == 0:
                n_ok += 1
            else:
                n_bad += 1
                _dump_repro(repro, ct, r, key[0], key[1], key[2], "ids",
                            "arms=%s%s%s%s kept=%s del=%s"
                            % (d1, d2, d3, d4, kd, dd))
    if subset is None:
        gaps = _status_gaps(folds, res, radii)
        missing = _concludable_no_rows(folds, res, radii)
        for g in gaps:
            missing_status.append("%s/%s %s r-%s" % (ct.dataset, ct.city,
                                                     eng.name + tag, g))
        rows.append(dict(dataset=ct.dataset, city=ct.city, radius=-1,
                         geometry="*", repeat=-1, fold=-1,
                         method=eng.name + tag, arm="status_coverage",
                         match=(not gaps and not missing),
                         ordered_diff=len(gaps), multiset_diff=len(missing),
                         pool_kept_diff=0, pool_del_diff=0,
                         quota_old="", quota_new="",
                         note=("status gaps: " + "|".join(gaps + missing))
                              if (gaps or missing)
                              else "radii=%d repeats=%d recorded"
                                   % (len(radii), folds.n_repeats)))
    rows.append(dict(dataset=ct.dataset, city=ct.city, radius=-1,
                     geometry="*", repeat=-1, fold=-1,
                     method=eng.name + tag, arm="summary",
                     match=(n_bad == 0), ordered_diff=n_bad,
                     multiset_diff=0, pool_kept_diff=0, pool_del_diff=0,
                     quota_old="", quota_new="",
                     note="ok=%d bad=%d" % (n_ok, n_bad)))
    return rows


def _dump_repro(repro, ct, radius, rep, geom, fold, what, detail):
    if repro is not None and len(repro) == 0:
        repro.append(dict(dataset=ct.dataset, city=ct.city, radius=radius,
                          repeat=rep, geom=geom, fold=fold, what=what,
                          detail=detail))


def _compare_city(ct, folds, ref, engines, radii, outputs=("matched", "audit"),
                  warm=True, repro=None, tag_suffix="", subset=None,
                  missing_status=None):
    """Run every engine for every output, cold and (optionally) hot."""
    import time as _t
    rows = []
    missing_status = missing_status if missing_status is not None else []
    radii = [float(r) for r in radii]
    for eng in engines:
        for output in outputs:
            t0 = _t.perf_counter()
            res, st = eng.run_city(ct, folds, radii, output)
            dt_ms = (_t.perf_counter() - t0) * 1000.0
            got = _compare_result(ct, folds, ref, eng, res, radii, output,
                                  repro, tag_suffix, subset, missing_status)
            for row in got:
                if row["arm"] == "summary":
                    row["note"] += " engine_ms=%.1f state=empty" % dt_ms
            rows += got
            if warm and st is not None:
                t0 = _t.perf_counter()
                res2, _ = eng.run_city(ct, folds, radii, output, state=st)
                dt2 = (_t.perf_counter() - t0) * 1000.0
                got = _compare_result(ct, folds, ref, eng, res2, radii, output,
                                      repro, tag_suffix + "@warm", subset,
                                      missing_status)
                for row in got:
                    if row["arm"] == "summary":
                        row["note"] += " engine_ms=%.1f state=reused" % dt2
                rows += got
    return rows


# ---------------------------------------------------------------------------
# bounded KD-tree hot-cache regression (radius raised on a reused state)
# ---------------------------------------------------------------------------
def _b1b_expansion_rows(ct, folds, ref, repro=None):
    """The first P0 run's counterexample, now part of the acceptance suite.

    A bounded engine caches the distance array of a mask up to the largest
    radius it was queried with.  Reusing that state for a *larger* radius
    must re-query the truncated rows; the cached answer must equal a fresh
    bounded run and the unbounded B1 fold by fold.

    Closeout sec. 6.1: for *every* requested radius the three runs -- hot
    bounded, fresh bounded, fresh unbounded B1 -- are compared directly on
    feasibility, per-repeat quotas, complete-and-unique fold keys, both
    arms' ordered training IDs and the audit candidate/kept/deleted pools.
    A radius that also exists in the frozen old-function reference gets the
    additional reference comparison; boundary radii (r -+ 5e-9) are NOT in
    the frozen sweep, so there the fresh-run equality *is* the oracle and
    the note says exactly that (the reference source must be accurate).

    Returns (rows, info); info carries the request / record / fold
    comparison counts the report lists separately."""
    r_primary = 200.0
    cases = [("expand100-200", [100.0], [200.0]),
             ("expand200-100", [200.0], [100.0]),
             ("dup200-200", [200.0], [200.0]),
             ("boundary200", [100.0], [r_primary - BOUNDARY_EPS, r_primary,
                                       r_primary + BOUNDARY_EPS])]
    rows = []
    info = {"n_requests": 0, "n_check_records": 0, "n_fold_comparisons": 0,
            "ref_radii": 0, "direct_only_radii": 0}
    for label, first, second in cases:
        eng = B1Engine(bounded=True)
        _, st = eng.run_city(ct, folds, first, "audit")
        warm, _ = eng.run_city(ct, folds, second, "audit", state=st)
        fresh, _ = eng.run_city(ct, folds, second, "audit")
        unb, _ = B1Engine().run_city(ct, folds, second, "audit")
        for r in second:
            info["n_requests"] += 1
            ref_st = ref_r = None
            for rr in ref.radii:
                if abs(rr - r) < 1e-9:
                    ref_r, ref_st = rr, ref.status(rr)
            has_ref = ref_r is not None
            info["ref_radii" if has_ref else "direct_only_radii"] += 1

            def _row(arm, match, diff, note, quota_old="", quota_new=""):
                if not match and repro is not None and len(repro) == 0:
                    repro.append(dict(dataset=ct.dataset, city=ct.city,
                                      radius=r, case=label, arm=arm,
                                      what="expansion mismatch",
                                      detail=note))
                info["n_check_records"] += 1
                return dict(dataset=ct.dataset, city=ct.city, radius=r,
                            geometry="*", repeat=-1, fold=-1,
                            method="b1b@%s" % label, arm=arm, match=match,
                            ordered_diff=diff, multiset_diff=0,
                            pool_kept_diff=0, pool_del_diff=0,
                            quota_old=quota_old, quota_new=quota_new,
                            note=note)

            # -- feasibility + per-repeat quotas among the three runs -----
            qw = np.asarray(warm.quota[r])
            qf = np.asarray(fresh.quota[r])
            qu = np.asarray(unb.quota[r])
            same = bool(np.array_equal(qw, qf) and np.array_equal(qw, qu))
            feas = (warm.status[r]["feasible"] == fresh.status[r]["feasible"]
                    == unb.status[r]["feasible"])
            n_rep_bad = int((qw != qu).any(axis=1).sum())
            rows.append(_row(
                "tri_budget", same and feas, n_rep_bad,
                "hot bounded vs fresh bounded vs fresh unbounded B1; "
                "repeats differing=%d/%d" % (n_rep_bad, len(qw)),
                str(qu[:1].tolist()), str(qw[:1].tolist())))

            if not (feas and warm.status[r]["feasible"]):
                # infeasible cell: no run may have produced comparisons
                # (the main acceptance also checks this); the fold-key /
                # id / pool checks below are defined for feasible radii
                if any(res_x.matched.get(r) for res_x in (warm, fresh, unb)):
                    rows.append(_row(
                        "tri_keys", False, 1,
                        "infeasible radius but comparisons were produced"))
                continue

            # -- fold keys complete and unique in each of the three -------
            expected = {(rep, geom, k) for rep in range(folds.n_repeats)
                        for geom, k, te in folds.repeat_folds(rep)}
            keys_bad = 0
            for res_x in (warm, fresh, unb):
                new_m = {(c["rep"], c["geom"], c["fold"]): c
                         for c in res_x.matched[r]}
                dupes = len(res_x.matched[r]) - len(new_m)
                if set(new_m) != expected or dupes:
                    keys_bad += 1
            rows.append(_row(
                "tri_keys", keys_bad == 0, keys_bad,
                "fold keys complete+unique in all three runs "
                "(%d folds)" % len(expected)))

            # -- per-fold: both arms' ordered ids + audit pools ------------
            wm = {(c["rep"], c["geom"], c["fold"]): c for c in warm.matched[r]}
            fm = {(c["rep"], c["geom"], c["fold"]): c for c in fresh.matched[r]}
            um = {(c["rep"], c["geom"], c["fold"]): c for c in unb.matched[r]}
            wa = {(c["rep"], c["geom"], c["fold"]): c for c in warm.audit[r]}
            fa = {(c["rep"], c["geom"], c["fold"]): c for c in fresh.audit[r]}
            ua = {(c["rep"], c["geom"], c["fold"]): c for c in unb.audit[r]}
            bad_ids = bad_pools = n_cmp = 0
            for key in sorted(expected):
                cw, cf, cu = wm[key], fm[key], um[key]
                n_cmp += 1
                for f in ("unbuf_pos", "unbuf_neg", "buf_pos", "buf_neg"):
                    if not (np.array_equal(cw[f], cf[f])
                            and np.array_equal(cw[f], cu[f])):
                        bad_ids += 1
                aw, af, au = wa[key], fa[key], ua[key]
                for f in ("cand_idx", "kept_idx", "del_idx"):
                    if not (np.array_equal(aw[f], af[f])
                            and np.array_equal(aw[f], au[f])):
                        bad_pools += 1
            info["n_fold_comparisons"] += n_cmp
            rows.append(_row(
                "tri_folds", bad_ids == 0, bad_ids,
                "both arms' ordered ids, hot/fresh-bounded/fresh-unbounded; "
                "fold_comparisons=%d" % n_cmp))
            rows.append(_row(
                "tri_pool", bad_pools == 0, bad_pools,
                "audit cand/kept/del pools, hot/fresh-bounded/"
                "fresh-unbounded; fold_comparisons=%d" % n_cmp))

            # -- frozen old-function reference, only where it exists -------
            if not has_ref:
                rows.append(_row(
                    "ref_source", True, 0,
                    "no frozen reference at r=%g (boundary radius): the "
                    "fresh-run equality above is the oracle" % r))
                continue
            if ref_st["feasible"] != warm.status[r]["feasible"]:
                rows.append(_row(
                    "budget_vs_old", False, 1,
                    "frozen old-function feasibility",
                    str(ref_st["feasible"]),
                    str(warm.status[r]["feasible"])))
            elif ref_st["feasible"]:
                rows.append(_row(
                    "budget_vs_old",
                    bool(np.array_equal(np.asarray(ref_st["budgets"]), qw)),
                    0, "frozen old-function budgets",
                    str(np.asarray(ref_st["budgets"])[:1].tolist()),
                    str(qw[:1].tolist())))
                old_m = {(rep, geom, fold): (up, un, bp, bn)
                         for rep, geom, fold, up, un, bp, bn
                         in ref.matched(ref_r)}
                old_a = {(rep, geom, fold): (cand, kept, dele)
                         for rep, geom, fold, cand, kept, dele
                         in ref.audit(ref_r)}
                bad_old = 0
                for key, (up, un, bp, bn) in old_m.items():
                    c = wm[key]
                    for a, b in ((c["unbuf_pos"], up), (c["unbuf_neg"], un),
                                 (c["buf_pos"], bp), (c["buf_neg"], bn)):
                        d = _arm_diff(a, b)
                        bad_old += d[0] + d[1]
                    ac, ak, ad = old_a[key]
                    aw2 = wa[key]
                    for a, b in ((aw2["cand_idx"], ac), (aw2["kept_idx"], ak),
                                 (aw2["del_idx"], ad)):
                        d = _arm_diff(a, b)
                        bad_old += d[0] + d[1]
                rows.append(_row(
                    "both_vs_old", bad_old == 0, bad_old,
                    "reused-state ids+pools vs frozen old functions "
                    "(fold_comparisons=%d)" % len(old_m)))
    return rows, info


def _golden_counts(run_dir, cities) -> list:
    """Reference contiguous action counts vs the frozen JSON golden numbers."""
    fz = json.loads((Path(__file__).resolve().parents[1] / "vendor" / "frozen_old" / "results"
                     / "primary_action_strata.json").read_text(
                         encoding="utf-8"))["cells"]
    cell_by_ds = {"streetview": 0, "so2sat10": 1, "so2sat43": 2}
    manifest = json.loads((run_dir / "input_manifest.json").read_text(
        encoding="utf-8"))
    rows = []
    for ds, city in cities:
        gold = fz[cell_by_ds[ds]]["per_city"][city]
        info = manifest["cities"]["%s/%s" % (ds, city)]
        act = info.get("actions", {}).get(
            str(info["primary_radius"]), {}).get("contiguous", {})
        for field in ("n_comparisons", "n_pool_actions", "n_training_actions"):
            rows.append(dict(
                dataset=ds, city=city, radius=-1, geometry="contiguous",
                repeat=-1, fold=-1, method="golden", arm=field,
                match=(act.get(field) == gold[field]),
                ordered_diff=-1, multiset_diff=-1, pool_kept_diff=-1,
                pool_del_diff=-1, quota_old=str(gold[field]),
                quota_new=str(act.get(field)),
                note="frozen primary_action_strata.json (contiguous, primary radius)"))
    return rows


def run_verify(cfg, run_dir: Path, suite: str,
               outputs=("matched", "audit")) -> dict:
    """Full verify pass; writes correctness.csv (+ repro on first mismatch).

    ``outputs`` (CLI ``--outputs``) really controls the acceptance scope:
    it is filtered to the deliverable payloads and drives the engine
    comparison loop -- the closeout plan required wiring it, because the
    argument used to be accepted and silently ignored."""
    outs = tuple(o for o in outputs if o in ("matched", "audit"))
    if not outs:
        outs = ("matched", "audit")
    sweep = [float(r) for r in cfg["radii"]["sweep"]]
    primary = dict((k, float(v)) for k, v in cfg["radii"]["primary"].items())
    eng_cfg = dict(cfg["engine"])
    eng_cfg["block_grid_side_m"] = float(
        cfg["engine"].get("block_grid_side_m",
                          cfg["engine"]["block_grid_sides_m"][1]))
    cities = suite_cities(cfg, suite)
    rows, repro, missing_status = [], [], []
    expansion_info = {}

    for ds, city in cities:
        ct, folds = load_city_inputs(run_dir, ds, city)
        ref = Reference(run_dir / "ref" / ("%s__%s.npz" % (ds, city)))
        # every engine, both outputs, cold and hot -- the deliverable is what
        # the bench and the writer actually produce
        rows += _compare_city(ct, folds, ref, _mk_engines(eng_cfg), sweep,
                              outputs=outs, warm=True,
                              repro=repro, missing_status=missing_status)
        # B0 spot: full sweep for every city except the largest, which gets
        # one contiguous and one scattered fold over the first five repeats
        # at the primary and the largest radius
        if len(ct) > 2100 and ds == "streetview":
            subset = set()
            for rep in range(min(5, folds.n_repeats)):
                for geom, k, te in folds.repeat_folds(rep):
                    if k < 1:
                        subset.add((rep, geom, k))
            rows += _compare_city(ct, folds, ref,
                                  [B0Engine(subset=subset)],
                                  [primary[ds], max(sweep)], ("audit",),
                                  warm=False, repro=repro, subset=subset,
                                  missing_status=missing_status)
        else:
            rows += _compare_city(ct, folds, ref, [B0Engine()], sweep,
                                  ("audit",), warm=False, repro=repro,
                                  missing_status=missing_status)
        # bounded-KD-tree hot-cache regression (the 100 m -> 200 m case),
        # upgraded to the direct three-engine comparison incl. audit pools
        exp_rows, exp_info = _b1b_expansion_rows(ct, folds, ref, repro=repro)
        rows += exp_rows
        expansion_info["%s/%s" % (ds, city)] = exp_info
        # batch-with-duplicate-radius workload vs the same reference
        dup = [float(r) for r in cfg["radii"]["batch_with_duplicate"]]
        for eng in _mk_engines(eng_cfg):
            if eng.name not in ("b1", "c"):
                continue
            hit_key = ("n_selection_cache_hits" if eng.name == "b1"
                       else "n_rows_cache_hits")
            res, _ = eng.run_city(ct, folds, dup, "audit")
            for r in sorted(set(dup)):
                ost, rst = ref.status(r), res.status[r]
                note = "batch-duplicate workload"
                if ost["feasible"] != rst["feasible"]:
                    rows.append(dict(dataset=ds, city=city, radius=r,
                                     geometry="*", repeat=-1, fold=-1,
                                     method=eng.name + "@batch", arm="status",
                                     match=False, ordered_diff=-1,
                                     multiset_diff=-1, pool_kept_diff=-1,
                                     pool_del_diff=-1, quota_old="",
                                     quota_new="", note=note + " feasibility"))
                    continue
                bad = 0
                if ost["feasible"]:
                    old_m = {(rep, geom, fold): (up, un, bp, bn)
                             for rep, geom, fold, up, un, bp, bn
                             in ref.matched(r)}
                    new_m = {(c["rep"], c["geom"], c["fold"]): c
                             for c in res.matched[r]}
                    for key, (up, un, bp, bn) in old_m.items():
                        c = new_m[key]
                        for a, b in ((c["unbuf_pos"], up),
                                     (c["unbuf_neg"], un),
                                     (c["buf_pos"], bp),
                                     (c["buf_neg"], bn)):
                            d = _arm_diff(a, b)
                            bad += d[0] + d[1]
                rows.append(dict(dataset=ds, city=city, radius=r,
                                 geometry="*", repeat=-1, fold=-1,
                                 method=eng.name + "@batch", arm="both",
                                 match=(bad == 0), ordered_diff=bad,
                                 multiset_diff=0, pool_kept_diff=0,
                                 pool_del_diff=0, quota_old="", quota_new="",
                                 note=note))
            hits = res.counters.get(hit_key, 0)
            rows.append(dict(dataset=ds, city=city, radius=-1, geometry="*",
                             repeat=-1, fold=-1, method=eng.name + "@batch",
                             arm="cache", match=(hits > 0), ordered_diff=0,
                             multiset_diff=0, pool_kept_diff=0,
                             pool_del_diff=0, quota_old="", quota_new="",
                             note="%s=%d (duplicate radius reused the cache)"
                                  % (hit_key, hits)))

    rows += _golden_counts(run_dir, cities)

    out = run_dir / "correctness.csv"
    cols = ["dataset", "city", "radius", "geometry", "repeat", "fold",
            "method", "arm", "match", "ordered_diff", "multiset_diff",
            "pool_kept_diff", "pool_del_diff", "quota_old", "quota_new",
            "note"]
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for row in rows:
            w.writerow(row)
    if repro:
        (run_dir / "first_diff_repro.json").write_text(
            json.dumps(repro[0], indent=1, ensure_ascii=False),
            encoding="utf-8")
    else:
        # a clean pass must not leave a repro from an earlier failed run
        stale = run_dir / "first_diff_repro.json"
        if stale.exists():
            stale.unlink()
    # two outcomes, counted apart
    bad = sum(1 for row in rows
              if not row["match"] and row["arm"] != "status_coverage")
    n_missing = sum(1 for row in rows
                    if row["arm"] == "status_coverage" and not row["match"])
    summary = {"n_rows": len(rows), "n_bad": bad, "all_match": bad == 0,
               "n_missing_status": n_missing,
               "status_complete": n_missing == 0 and not missing_status,
               "n_cities": len(cities),
               "engines": ["b1", "b1b", "c1", "c2", "c", "b0",
                           "b1b@expand/dup/boundary (3-engine direct)",
                           "*@batch"],
               "outputs": list(outs),
               "states": ["empty", "reused"],
               "sweep_radii": sweep,
               "expansion_requests": sum(v["n_requests"]
                                         for v in expansion_info.values()),
               "expansion_records": sum(v["n_check_records"]
                                        for v in expansion_info.values()),
               "expansion_fold_comparisons": sum(
                   v["n_fold_comparisons"]
                   for v in expansion_info.values()),
               "status_gap_examples": missing_status[:10]}
    (run_dir / "verify_summary.json").write_text(
        json.dumps(summary, indent=1, ensure_ascii=False), encoding="utf-8")
    return summary

