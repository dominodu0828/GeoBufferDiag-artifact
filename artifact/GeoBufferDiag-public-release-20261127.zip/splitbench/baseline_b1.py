# -*- coding: utf-8 -*-
"""B1: batched cKDTree baseline -- the opponent every candidate must beat.

Work order sec. 4, B1: for every *distinct* test mask build the test tree
once and run one exact nearest-neighbour query for all training points; the
resulting distance array is radius-independent, so a batch of radii costs
one query plus one threshold comparison per radius.  Contiguous-block masks
are reused across repeats.  Class-wise random keys are pre-sorted once per
city; a selection is a masked filter over the sorted order.  Selections for
identical (mask, radius, quota) are cached, so duplicate radii in a batch
hit the cache.  Both arms' outputs go through the same writer as the
candidate's.

Variant 'bounded' re-runs the query with a relaxed
``distance_upper_bound``: rows returned as ``inf`` have no test point within
the largest radius of the batch and survive every radius, so they are never
thresholded individually. The relaxation and boundary recheck margin have an
absolute floor and a scale-dependent float64 guard, because adding a small
constant to a large radius can be a floating-point no-op and the tree bound
is exclusive. The tree pruning never decides a threshold comparison; the
re-check count is reported. Equal-distance ties cannot
affect the decision because only the NN *distance* is thresholded.

A cached mask remembers the largest radius its distance array is valid for
(``vmax``).  ``inf`` rows are only known to be *beyond* ``vmax``, so when a
later request raises the radius above ``vmax`` those rows must be queried
again -- reusing the array as-is silently truncates every distance between
``vmax`` and the new radius and yields wrong kept counts (the Moscow
100 m -> 200 m counterexample).  Reuse therefore extends the array in place
(only the ``inf`` rows are re-queried, boundary rows re-checked) before any
quota is computed; the extension is counted.

Phases (same vocabulary for every engine): index = test trees; exact = NN
queries (B1's pool computation); quota = per-fold kept counts and the
per-repeat min; select = arm selections; write = writer.
"""
from __future__ import annotations

import time

import numpy as np
from scipy.spatial import cKDTree

from .contract import class_orders, roundoff_margin, select_prefix
from .inputs import _validate_radius
from .writers import EngineResult, Phases

BOUNDARY_MARGIN_M = 1e-8      # absolute floor; roundoff_margin adds scale


def _mask_keys(folds):
    """Distinct test masks with keys; contiguous blocks repeat across repeats."""
    seen = {}
    for rep in range(folds.n_repeats):
        for geom, k, te in folds.repeat_folds(rep):
            key = ("b", k) if geom == 0 else ("s", rep, k)
            seen.setdefault(key, te)
    return seen


class B1Engine:
    name = "b1"

    def __init__(self, bounded: bool = False):
        self.bounded = bounded
        if bounded:
            self.name = "b1b"

    # ------------------------------------------------------------------
    def _bounded_distance(self, xy, te, tree, rows, rmax, radii, counters):
        """Exact NN distance under a cKDTree upper bound.

        The exclusive tree bound is widened by an absolute floor and a
        scale-dependent roundoff guard. Rows near any requested boundary are
        recomputed explicitly rather than classified by the tree search."""
        radii = np.asarray(radii, dtype=float)
        margins = roundoff_margin(radii, BOUNDARY_MARGIN_M)
        query_margin = float(roundoff_margin(rmax, BOUNDARY_MARGIN_M))
        query_bound = np.nextafter(rmax + query_margin, np.inf)
        d, _ = tree.query(xy[rows], k=1, distance_upper_bound=query_bound)
        near = np.isfinite(d) & (
            np.abs(d[:, None] - radii[None, :]) <= margins[None, :]).any(axis=1)
        if near.any():
            test_xy = xy[te]
            rr = rows[near]
            with np.errstate(over="ignore", invalid="ignore"):
                d[near] = np.sqrt(
                    ((test_xy[None, :, :] - xy[rr][:, None, :]) ** 2)
                    .sum(-1)).min(1)
            counters["n_boundary_rechecks"] += int(near.sum())
        d[~np.isfinite(d)] = np.inf
        return d

    def _fresh_mask(self, xy, te, tree, cand, rmax, radii, counters):
        if self.bounded and rmax > 0:
            d = self._bounded_distance(xy, te, tree, cand, rmax, radii,
                                       counters)
            vmax = float(rmax)
        else:
            d, _ = tree.query(xy[cand], k=1)
            vmax = float("inf")            # every distance is exact
        counters["n_rows_queried"] += int(len(cand))
        return {"cand": cand, "d": d, "vmax": vmax, "tree": tree}

    def _extend_mask(self, xy, te, m, rmax, radii, counters):
        """Raise a cached distance array's validity radius to ``rmax``.

        Only the rows stored as ``inf`` (i.e. known merely to be beyond the
        old validity radius) are queried again; the rest are exact already."""
        old = m["vmax"]
        if not self.bounded or rmax <= old:
            return
        trunc = m["cand"][~np.isfinite(m["d"])]
        counters["n_masks_expanded"] += 1
        if len(trunc):
            m["d"][~np.isfinite(m["d"])] = self._bounded_distance(
                xy, te, m["tree"], trunc, rmax, radii, counters)
            counters["n_rows_requeried_expansion"] += int(len(trunc))
            counters["n_rows_queried"] += int(len(trunc))
            # boundary re-checks are already counted inside the query helper
        m["vmax"] = float(rmax)

    def run_city(self, ct, folds, radii, output, state=None, floor: int = 5,
                 prescribed=None):
        """``prescribed`` (closeout 8.1): optional {radius: [(qp, qn), ...]}
        or {radius: None} supplying the per-repeat common quotas as an
        external input (from the frozen reference export).  The quota stage
        then only validates feasibility -- its acquisition cost is excluded
        from ``ph.quota`` by construction; selection is unchanged."""
        t_start = time.perf_counter()
        ph = Phases()
        counters = {"engine": self.name, "n_masks": 0, "n_masks_reused": 0,
                    "n_rows_queried": 0, "n_boundary_rechecks": 0,
                    "n_selection_cache_hits": 0, "n_masks_expanded": 0,
                    "n_rows_requeried_expansion": 0}
        radii = [_validate_radius(r) for r in radii]
        y, xy, keys = ct.label, ct.xy, ct.keys
        n = len(ct)

        # ---- index + exact: one tree & one NN array per distinct mask ----
        state = {} if state is None else state
        if "orders" not in state:
            state["orders"] = class_orders(y, keys)
        orders = state["orders"]
        masks = state.setdefault("masks", {})
        rmax = max(radii) if radii else 0.0
        t_index = t_exact = 0.0
        for key, te in _mask_keys(folds).items():
            counters["n_masks"] += 1
            if key in masks:
                counters["n_masks_reused"] += 1
                m = masks[key]
                if self.bounded and rmax > m["vmax"]:
                    t0 = time.perf_counter()
                    self._extend_mask(xy, te, m, rmax, radii, counters)
                    t_exact += time.perf_counter() - t0
                continue
            cand = np.flatnonzero(~te)
            t0 = time.perf_counter()
            tree = cKDTree(xy[te])
            t_index += time.perf_counter() - t0
            t0 = time.perf_counter()
            masks[key] = self._fresh_mask(xy, te, tree, cand, rmax, radii,
                                          counters)
            t_exact += time.perf_counter() - t0
        ph.index, ph.exact = t_index, t_exact

        # ---- quota: per-fold kept counts, per-repeat min ----
        t0 = time.perf_counter()
        res = EngineResult(dataset=ct.dataset, city=ct.city,
                           phases=ph, counters=counters)
        quota_by_radius = {}
        usable = bool(folds.usable)
        if prescribed is not None:
            counters["quota_source"] = "prescribed"
            for radius in radii:
                quotas = prescribed.get(radius)
                feasible = usable and quotas is not None and all(
                    qp >= floor and qn >= floor for qp, qn in quotas)
                note = "" if feasible else (
                    "no usable units" if not usable
                    else "prescribed quota infeasible")
                entry = ([(int(qp), int(qn)) for qp, qn in quotas]
                         if feasible else [(-1, -1)] * folds.n_repeats)
                quota_by_radius[radius] = (entry, feasible)
                res.status[radius] = {"feasible": feasible,
                                      "budgets": entry if feasible else None,
                                      "note": note}
        else:
            for radius in radii:
                quotas = []
                feasible = usable
                note = "" if usable else "no usable units"
                if usable:
                    for rep in range(folds.n_repeats):
                        qp = qn = None
                        for geom, k, te in folds.repeat_folds(rep):
                            key = ("b", k) if geom == 0 else ("s", rep, k)
                            cand, d = masks[key]["cand"], masks[key]["d"]
                            labels = y[cand]
                            if radius == 0:
                                p, ng = int((labels == 1).sum()), \
                                    int((labels == 0).sum())
                            else:
                                keep = d > radius
                                p = int(((labels == 1) & keep).sum())
                                ng = int(((labels == 0) & keep).sum())
                            qp = p if qp is None else min(qp, p)
                            qn = ng if qn is None else min(qn, ng)
                        quotas.append((qp, qn))
                        if qp < floor or qn < floor:
                            feasible = False
                            note = "budget infeasible"
                else:
                    quotas = [(-1, -1)] * folds.n_repeats
                quota_by_radius[radius] = (quotas, feasible)
                res.status[radius] = {"feasible": feasible,
                                      "budgets": quotas if feasible else None,
                                      "note": note}
        res.quota = {r: quota_by_radius[r][0] for r in radii}
        ph.quota = time.perf_counter() - t0

        # ---- select (+ audit materialisation; skipped for stats) ----
        t0 = time.perf_counter()
        sel_cache = state.setdefault("sel_cache", {})
        for radius in radii:
            quotas, feasible = quota_by_radius[radius]
            if not feasible:
                res.matched[radius] = []
                if output == "audit":
                    res.audit[radius] = []
                continue
            comps, auds, stats = [], [], []
            for rep in range(folds.n_repeats):
                qp, qn = quotas[rep]
                for geom, k, te in folds.repeat_folds(rep):
                    key = ("b", k) if geom == 0 else ("s", rep, k)
                    cand, d = masks[key]["cand"], masks[key]["d"]
                    ckey = (key, radius, qp, qn)
                    if ckey in sel_cache:
                        counters["n_selection_cache_hits"] += 1
                        up, un, bp, bn, fast = sel_cache[ckey]
                    else:
                        pool_u = np.zeros(n, dtype=bool)
                        pool_u[cand] = True
                        u = np.concatenate([
                            select_prefix(orders[0], pool_u, qp),
                            select_prefix(orders[1], pool_u, qn)])
                        if radius == 0:
                            fast, buf = True, u
                        else:
                            pool_b = np.zeros(n, dtype=bool)
                            pool_b[cand[d > radius]] = True
                            prefix_ok = bool(pool_b[u].all()) if len(u) else True
                            if prefix_ok:
                                fast, buf = True, u
                            else:
                                fast = False
                                buf = np.concatenate([
                                    select_prefix(orders[0], pool_b, qp),
                                    select_prefix(orders[1], pool_b, qn)])
                        up, un = u[y[u] == 1], u[y[u] == 0]
                        bp, bn = buf[y[buf] == 1], buf[y[buf] == 0]
                        sel_cache[ckey] = (up, un, bp, bn, fast)
                    comps.append({"rep": rep, "geom": geom, "fold": k,
                                  "quota": (qp, qn), "fast_path": fast,
                                  "unbuf_pos": up, "unbuf_neg": un,
                                  "buf_pos": bp, "buf_neg": bn})
                    if output == "audit":
                        if radius == 0:
                            keep_idx, del_idx = cand, cand[:0]
                        else:
                            keep = d > radius
                            keep_idx = cand[keep]
                            del_idx = cand[~keep]
                        auds.append({"rep": rep, "geom": geom, "fold": k,
                                     "cand_idx": cand, "kept_idx": keep_idx,
                                     "del_idx": del_idx,
                                     "n_kept": len(keep_idx),
                                     "n_deleted": len(del_idx),
                                     "n_cand": len(cand)})
                    if output == "stats":
                        labels = y[cand]
                        if radius == 0:
                            # r = 0 keeps the whole pool: kept counts come
                            # from the pool's real labels, NOT from the
                            # common quota -- the quota can sit below the
                            # pool size (guangzhou fold 0: cand 959,
                            # quota 768), and reporting kept=quota,
                            # deleted=0 broke n_kept + n_deleted = n_cand
                            # (795 folds across the six cities).
                            kp = int((labels == 1).sum())
                            kn = int((labels == 0).sum())
                            nd = 0
                            n_kept = len(cand)
                        else:
                            keep = d > radius
                            kp = int(((labels == 1) & keep).sum())
                            kn = int(((labels == 0) & keep).sum())
                            nd = len(cand) - kp - kn
                            n_kept = kp + kn
                        stats.append({"rep": rep, "geom": geom, "fold": k,
                                      "quota": (qp, qn), "n_cand": len(cand),
                                      "n_kept": n_kept, "n_deleted": nd,
                                      "kept_pos": kp, "kept_neg": kn})
            res.matched[radius] = comps
            if output == "audit":
                res.audit[radius] = auds
            if output == "stats":
                res.stats[radius] = stats
        ph.select = time.perf_counter() - t0
        ph.total = time.perf_counter() - t_start
        return res, state
