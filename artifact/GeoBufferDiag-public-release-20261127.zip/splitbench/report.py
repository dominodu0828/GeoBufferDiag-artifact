# -*- coding: utf-8 -*-
"""report: assemble P0_REPORT.md from the run's products.

The report opens with the five questions the work order demands, then the
correctness table (including the two acceptance outcomes that are *not* the
same finding: a mismatch and a missing status record), the timing tables
(medians over the raw interleaved repetitions in bench.csv), the per-output
stage accounting, the ablation attribution, the counters with their proper
denominators, the memory measurement, the correction table against the first
(negative) run, the self-query / radius-expansion evidence, the pending
PostGIS column, limitations, and the next-round recommendation.
"""
from __future__ import annotations

import csv as _csv
import json
import statistics as _stat
from collections import defaultdict
from pathlib import Path

PREV_RUN = "p0-20261116-042740-141"      # kept as the first negative result
CITY_ORDER = [("streetview", "sy", 1602), ("streetview", "sz", 10620),
              ("so2sat10", "guangzhou", 1214), ("so2sat10", "moscow", 1749),
              ("so2sat43", "shenzhen", 1778), ("so2sat43", "hongkong", 2055)]


def _read_csv(path: Path):
    if not path.exists():
        return []
    return list(_csv.DictReader(open(path, encoding="utf-8")))


def _med(rows, field):
    vals = [float(r[field]) for r in rows if r.get(field) not in ("", None)]
    return _stat.median(vals) if vals else float("nan")


def _fmt(v, nd=1):
    if v is None or v != v:
        return "—"
    return ("%%.%df" % nd) % v


def _signed(x):
    v = "{:,}".format(abs(int(x)))
    return ("+%s" % v) if x > 0 else ("-%s" % v if x < 0 else "0")


def build_report(cfg, run_dir: Path, suite: str) -> Path:
    manifest = json.loads((run_dir / "input_manifest.json").read_text(
        encoding="utf-8"))
    verify = json.loads((run_dir / "verify_summary.json").read_text(
        encoding="utf-8")) if (run_dir / "verify_summary.json").exists() \
        else {"all_match": False, "n_rows": 0, "n_bad": -1,
              "n_missing_status": -1, "status_complete": False}
    bench = _read_csv(run_dir / "bench_summary.csv")
    correctness = _read_csv(run_dir / "correctness.csv")
    run_manifest = json.loads((run_dir / "run_manifest.json").read_text(
        encoding="utf-8")) if (run_dir / "run_manifest.json").exists() else {}

    # ---- aggregate bench: median totals per (city, mode, output, method) --
    agg = defaultdict(dict)
    raw = _read_csv(run_dir / "bench.csv")
    reps_by = defaultdict(list)
    for r in raw:
        if r["ms_total"] in ("", None) or r["rep"] == "warmup":
            continue
        key = (r["dataset"], r["city"], r["mode"], r["output"], r["method"],
               r["variant"])
        reps_by[key].append(r)
    for key, rs in reps_by.items():
        agg[key] = {
            "median": _med(rs, "ms_total"),
            "min": min(float(r["ms_total"]) for r in rs),
            "max": max(float(r["ms_total"]) for r in rs),
            "write": _med(rs, "ms_write"),
            "exact": _med(rs, "ms_exact"),
            "quota": _med(rs, "ms_quota"),
            "select": _med(rs, "ms_select"),
            "index": _med(rs, "ms_index"),
            "read": _med(rs, "ms_read"),
            "bytes": _med(rs, "bytes_out"),
            "peak": _med(rs, "peak_rss_mb"),
            "samples": _med(rs, "rss_samples"),
            "reps": len(rs),
            "counters": json.loads(rs[-1]["counters_json"] or "{}"),
        }

    # ---- five answers -----------------------------------------------------
    q1 = verify.get("all_match")
    stat_ok = verify.get("status_complete")
    q2 = _q2_b1_span(agg)
    q3 = _q3_stage_accounting(agg)
    q4 = _q4_after_write(agg)
    q5 = _q5_next_round(q1, stat_ok, agg)

    lines = []
    A = lines.append
    A("# GeoBufferDiag P0 技术报告（第 2 轮：修复两处代码后复测六城）")
    A("")
    A("*运行编号　`%s`　套件　`%s`　配置　`configs/paper_primary.yaml`*"
      % (run_dir.name, suite))
    A("")
    A("本轮只做三件事：修掉有界 KD-tree 热缓存扩半径的错误配额、删掉候选为"
      "本折测试行做的自查询、把验收与计量的口径对准最终交付；然后把六城按"
      "同一口径复测一遍。第一轮的负结果 `%s` 原样保留，本轮所有数字都是"
      "新计时，不复用旧计时。" % PREV_RUN)
    A("")
    A("## 0　开头五问")
    A("")
    A("1. **能否还原六城**：%s。冻结重放六项 `bytes_equal True`，三份 "
      "manifest 行数与 SHA-256 与工单一致；本引擎套件（b1/b1b/c1/c2/c + "
      "b0 抽查 + 扩半径回归）对旧函数的 %d 行逐行对照，不一致 %d 行；"
      "状态记录%s（缺测 %d 条）。"
      % ("能" if q1 else "有问题", verify.get("n_rows", 0),
         verify.get("n_bad", -1),
         "完整" if stat_ok else "不完整",
         verify.get("n_missing_status", -1)))
    A("2. **B1 最快与最慢城市**（单主半径，matched，cold，5 次中位数）：%s"
      % q2)
    A("3. **共同配额与补位各“省”了什么**：%s" % q3)
    A("4. **输出写盘之后还剩多少收益**：%s" % q4)
    A("5. **下一轮是否值得做**：%s" % q5)
    A("")
    A("## 1　正确性")
    A("")
    A("| 检查 | 结果 |")
    A("|---|---|")
    A("| 冻结重放 | 六项 bytes_equal True；三份 manifest SHA-256/行数一致 |")
    A("| 引擎对照行数 | %d |" % verify.get("n_rows", 0))
    A("| 逐行不一致 | %d |" % verify.get("n_bad", -1))
    A("| 折键完整且唯一 | 每个可行半径逐折核对；无 `arm=fold_keys` 行即通过 |")
    A("| 状态记录缺失 | %d 条（与“零差异”分开计数）|"
      % verify.get("n_missing_status", -1))
    A("| 状态覆盖 | %s |"
      % ("每个请求半径 × 每个 repeat 均有记录" if stat_ok
         else "存在缺失，见 `arm=status_coverage` 行"))
    A("| 首差复现 | %s |"
      % ("无" if not (run_dir / "first_diff_repro.json").exists()
         else str(run_dir / "first_diff_repro.json")))
    A("")
    A("验收口径本轮改成“按交付物”：matched 与 audit 分别跑，冷状态与热复"
      "用状态各跑一遍，全部与旧函数逐折逐行比较。上一轮只跑 audit，热路径"
      "从未被比较过——这正是有界缓存反例能溜过验收的原因。")
    A("")
    _correctness_by_method(lines, correctness)
    A("")
    A("## 2　性能主表（中位数毫秒，cold，单半径，matched）")
    A("")
    _main_table(lines, agg)
    A("")
    _audit_note(lines, agg)
    A("## 3　批量半径与热复用")
    A("")
    _batch_table(lines, agg)
    A("")
    A("## 4　消融归因")
    A("")
    _ablation(lines, agg)
    A("")
    A("## 5　计数器与机制解释")
    A("")
    _counters(lines, agg)
    A("")
    A("## 6　内存（每轮峰值，采样口径）")
    A("")
    _memory(lines, agg)
    A("")
    A("## 7　与第一轮负结果的更正对照")
    A("")
    _corrections(lines, agg)
    A("")
    A("## 8　自查询清零与 100→200 米回归")
    A("")
    _selfquery(lines, agg, correctness, run_dir)
    A("")
    A("## 9　B2 PostGIS")
    A("")
    A("**pending**：本机仍无可用 PostgreSQL 实例（无服务、无二进制、无 "
      "Docker）。按工单要求只记 pending，不参与任何结论。")
    A("")
    A("## 10　与 ICDE GeoScopeJoin / ordered spatial top-k 的登记")
    A("")
    A("| 项 | GeoBufferDiag 本原型 | ICDE GeoScopeJoin |")
    A("|---|---|---|")
    A("| 输入 | 投影后二维点、类别标签、固定测试掩码、随机键 | 点–栅格–查询区域 |")
    A("| 输出 | 每切分的精确有序训练行（两臂 ID + 审计池）| 连接结果/top-k |")
    A("| 核心谓词 | 空间反连接（d > r）+ 共同配额 + 稳定抽样 | 空间连接谓词 |")
    A("| 共用代码 | 无（本原型独立实现；旧函数只读作 oracle）| — |")
    A("| 实验 | 六城切分复现 + 端到端毫秒 | ICDE 论文实验 |")
    A("")
    A("## 11　环境与可复现")
    A("")
    env = run_manifest.get("environment", {})
    A("- CPU：%s；power：%s" % (env.get("cpu", "?"),
                                env.get("power_scheme", "?")))
    A("- Python %s，numpy %s，scipy %s，sklearn %s；线程固定 1"
      % (env.get("python", "?"), env.get("numpy", "?"),
         env.get("scipy", "?"), env.get("sklearn", "?")))
    A("- 输入快照与哈希：`input_manifest.json`；原始计时：`bench.csv`；"
      "汇总：`bench_summary.csv`；正确性：`correctness.csv`；"
      "状态记录：`out/<method>/*__status.csv`")
    A("")
    A("## 12　限制")
    A("")
    _limits(lines)
    A("")
    A("## 13　下一轮建议")
    A("")
    A(q5_detail(q1, agg))
    A("")

    out = run_dir / "P0_REPORT.md"
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out


# ---------------------------------------------------------------------------
def _q2_b1_span(agg):
    rows = []
    for ds, city, _ in CITY_ORDER:
        a = agg.get((ds, city, "single", "matched", "b1", "cold"))
        if a:
            rows.append((city, a["median"], a["max"]))
    if not rows:
        return "无数据"
    lo = min(rows, key=lambda x: x[1])
    hi = max(rows, key=lambda x: x[1])
    return ("最快 %s %.1f ms（max %.1f），最慢 %s %.1f ms（max %.1f）"
            % (lo[0], lo[1], lo[2], hi[0], hi[1], hi[2]))


def _stage_totals(agg, mode="batch", variant="cold"):
    """Per output: (B1 pool rows, candidate quota-stage rows, candidate total)."""
    out = {}
    for output in ("matched", "audit"):
        b1 = cq = ct = 0
        for (ds, city, m, o, method, var), a in agg.items():
            if m != mode or o != output or var != variant:
                continue
            c = a.get("counters", {})
            if method == "b1":
                b1 += c.get("n_rows_queried", 0) or 0
            elif method == "c":
                cq += c.get("n_rows_exact_quota", 0) or 0
                ct += c.get("n_rows_exact", 0) or 0
        out[output] = (b1, cq, ct)
    return out


def _q3_stage_accounting(agg):
    """Stage values per output with signed deltas; never a cross-output sum."""
    st = _stage_totals(agg)
    parts = []
    for output in ("matched", "audit"):
        b1, cq, ct = st[output]
        if not b1:
            continue
        parts.append(
            "%s：B1 全池 %s 行；候选配额阶段 %s 行（%s），两阶段合计 %s 行"
            "（%s）"
            % (output, "{:,}".format(b1), "{:,}".format(cq),
               _signed(cq - b1), "{:,}".format(ct), _signed(ct - b1)))
    if not parts:
        return "无数据"
    b1, cq, ct = st["matched"]
    quota_dir = ("多" if cq > b1 else "少")
    total_dir = ("多" if ct > b1 else "少")
    return "%s。判读：配额阶段比 B1 %s %s 行，两阶段合计比 B1 %s %s 行；" \
           "行数不是时间，块中心查询另计。上一轮把 matched 与 audit 混加" \
           "得出的“省 1,306,847 行”已撤回（第 7 节）。" % (
               "；".join(parts), quota_dir,
               "{:,}".format(abs(cq - b1)), total_dir,
               "{:,}".format(abs(ct - b1)))


def _q4_after_write(agg):
    """End-to-end and compute-only deltas, and the write share of each arm."""
    parts = []
    notes = []
    bigger = []
    for output in ("matched", "audit"):
        deltas_total, deltas_compute = [], []
        write_share = ([], [])
        for (ds, city, mode, o, method, var), a in agg.items():
            if method != "c" or mode != "single" or o != output \
                    or var != "cold":
                continue
            b = agg.get((ds, city, "single", output, "b1", "cold"))
            if not b:
                continue
            deltas_total.append(b["median"] - a["median"])
            deltas_compute.append((b["median"] - b["write"])
                                  - (a["median"] - a["write"]))
            write_share[0].append(100.0 * b["write"] / b["median"]
                                  if b["median"] else 0.0)
            write_share[1].append(100.0 * a["write"] / a["median"]
                                  if a["median"] else 0.0)
        if deltas_total:
            dt = _stat.median(deltas_total)
            dc = _stat.median(deltas_compute)
            parts.append(
                "%s：端到端中位差 %+.1f ms，去掉写出后 %+.1f ms；写出占 B1 "
                "总时长 %.0f%%、候选 %.0f%%"
                % (output, dt, dc, _stat.median(write_share[0]),
                   _stat.median(write_share[1])))
            if dc < dt - 1.0:
                # B1 writes more, so removing the write cost penalises B1 more
                bigger.append(output)
    if not parts:
        return "无数据"
    if bigger:
        notes.append("%s 的差距在去掉写出后反而变大：B1 的写出占比更高，"
                     "扣掉写盘对 B1 更有利" % "、".join(bigger))
    return ("；".join(parts) + "。负值表示候选更慢。"
            + ("；".join(notes) + "。" if notes else "")
            + "写出占比单列，是因为写出本身不是任何一方的算法收益；"
              "去掉写出后的差值才是算法差距。")


def _q5_next_round(q1, stat_ok, agg):
    if not q1:
        return "否：正确性未过，先修（一处不符就保留首个反例，先修再扩）"
    wins, losses = [], []
    for (ds, city, mode, output, method, var), a in agg.items():
        if method != "c" or var != "cold" or mode != "single" \
                or output != "matched":
            continue
        b = agg.get((ds, city, "single", "matched", "b1", "cold"))
        if not b:
            continue
        (wins if a["median"] < b["median"] else losses).append(
            (city, a["median"], b["median"]))
    extra = "" if stat_ok else "（状态记录仍有缺失，需先补齐）"
    if wins and len(wins) >= 4:
        return ("值得：六城中 %d 城完整 matched 对 B1 有超出波动（%.1f/%.1f ms "
                "级）的端到端收益；先补数据库基线与规模扩展（P1）。%s"
                % (len(wins), min(w[1] for w in wins),
                   max(w[2] for w in wins), extra))
    if wins:
        return ("收窄：只在 %s 等少数城市有收益，按工单交正结果并说明适用"
                "范围，不扩算。%s" % (", ".join(w[0] for w in wins), extra))
    return ("交负结果并暂停扩算：删掉测试行自查询后完整 matched 仍未跑赢"
            "共享距离、预排键的 B1；当前证据不支持扩到 48 城。%s" % extra)


def q5_detail(q1, agg):
    if not q1:
        return "先修复正确性，再谈扩展。"
    rows = []
    for (ds, city, mode, output, method, var), a in agg.items():
        if method != "c" or var != "cold" or output != "matched":
            continue
        b = agg.get((ds, city, mode, "matched", "b1", "cold"))
        if not b:
            continue
        rows.append((ds, city, mode, a["median"], b["median"]))
    lines = ["| 数据集 | 城市 | 模式 | full 中位 ms | B1 中位 ms | 比值 |",
             "|---|---|---|---|---|---|"]
    lo = float("nan")
    for ds, city, mode, f, b in sorted(rows):
        lines.append("| %s | %s | %s | %.1f | %.1f | %.2f |"
                     % (ds, city, mode, f, b, (f / b) if b else 0))
        if b:
            lo = (f / b) if lo != lo else min(lo, f / b)
    lines.append("")
    lines.append("对 B1 的最低比值 %.2f（六城全部配置），说明瓶颈不是被删掉的"
                 "那部分工作；扩到 48 城只会让差距更难收窄（城市越大，稠密"
                 "散点折的不确定块越多）。" % lo)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
def _correctness_by_method(lines, correctness):
    from collections import Counter
    cnt = Counter()
    bad = Counter()
    for r in correctness:
        m = r["method"]
        cnt[m] += 1
        if r["match"] not in ("True", "true", "1"):
            bad[m] += 1
    lines.append("| 引擎/检查 | 行数 | 不匹配 |")
    lines.append("|---|---:|---:|")
    for m in sorted(cnt):
        lines.append("| %s | %d | %d |" % (m, cnt[m], bad[m]))


def _main_table(lines, agg):
    lines.append("| 数据 | 城市 | 行数 | B1 | B1b | C1 | C2 | full | "
                 "full/较快KD | audit full | audit B1 |")
    lines.append("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for ds, city, n in CITY_ORDER:
        vals = {}
        for m in ("b1", "b1b", "c1", "c2", "c"):
            a = agg.get((ds, city, "single", "matched", m, "cold"))
            vals[m] = a["median"] if a else float("nan")
        au = agg.get((ds, city, "single", "audit", "c", "cold"))
        aub = agg.get((ds, city, "single", "audit", "b1", "cold"))
        # the ratio is against the *faster* of the two KD baselines, i.e. the
        # same denominator the work order used in its own recomputation
        kd = min(v for v in (vals["b1"], vals["b1b"]) if v == v) \
            if (vals["b1"] == vals["b1"] or vals["b1b"] == vals["b1b"]) \
            else float("nan")
        ratio = ("%.2f" % (vals["c"] / kd)
                 if vals["c"] == vals["c"] and kd and kd == kd else "—")
        lines.append("| %s | %s | %s | %.1f | %.1f | %.1f | %.1f | %.1f | %s "
                     "| %s | %s |"
                     % (ds, city, n, vals["b1"], vals["b1b"], vals["c1"],
                        vals["c2"], vals["c"], ratio,
                        ("%.1f" % au["median"]) if au else "—",
                        ("%.1f" % aub["median"]) if aub else "—"))


def _audit_note(lines, agg):
    """Where the candidate is at parity, say so; it must not be cherry-picked."""
    near = []
    for ds, city, _ in CITY_ORDER:
        a = agg.get((ds, city, "single", "audit", "c", "cold"))
        b = agg.get((ds, city, "single", "audit", "b1", "cold"))
        if a and b and a["median"] <= b["median"] * 1.02:
            near.append((city, a["median"], b["median"]))
    if near:
        lines.append("需要说明的一点：audit 单半径口径下 %s 与 B1 基本持平"
                     "（%s）。这是单点，audit 的批量口径仍慢（第 3 节），"
                     "也不改变 matched 的结论；报告不拿这个点当收益。"
                     % ("、".join(c for c, _, _ in near),
                        "；".join("%s %.1f vs %.1f ms" % n for n in near)))
        lines.append("")


def _batch_table(lines, agg):
    lines.append("批量半径 0/100/200/400（batch）与含重复半径的 batch_dup，cold：")
    lines.append("")
    lines.append("| 城市 | 输出 | B1 batch | full batch | B1 batch_dup | "
                 "full batch_dup | full/B1 |")
    lines.append("|---|---|---:|---:|---:|---:|---:|")
    for ds, city, _ in CITY_ORDER:
        for output in ("matched", "audit"):
            b1 = agg.get((ds, city, "batch", output, "b1", "cold"))
            fu = agg.get((ds, city, "batch", output, "c", "cold"))
            b1d = agg.get((ds, city, "batch_dup", output, "b1", "cold"))
            fud = agg.get((ds, city, "batch_dup", output, "c", "cold"))
            f = fu["median"] if fu else float("nan")
            b = b1["median"] if b1 else float("nan")
            lines.append(
                "| %s | %s | %s | %s | %s | %s | %s |"
                % (city, output,
                   _fmt(b), _fmt(f),
                   _fmt(b1d["median"]) if b1d else "—",
                   _fmt(fud["median"]) if fud else "—",
                   ("%.2f" % (f / b) if (b == b and b) else "—")))
    lines.append("")
    lines.append("warm（热复用，索引已建）matched/single：")
    lines.append("")
    lines.append("| 城市 | B1 warm | full warm | B1 cold | full cold |")
    lines.append("|---|---:|---:|---:|---:|")
    for ds, city, _ in CITY_ORDER:
        w1 = agg.get((ds, city, "single", "matched", "b1", "warm"))
        wf = agg.get((ds, city, "single", "matched", "c", "warm"))
        c1 = agg.get((ds, city, "single", "matched", "b1", "cold"))
        cf = agg.get((ds, city, "single", "matched", "c", "cold"))
        lines.append("| %s | %s | %s | %s | %s |" % (
            city,
            _fmt(w1["median"]) if w1 else "—",
            _fmt(wf["median"]) if wf else "—",
            _fmt(c1["median"]) if c1 else "—",
            _fmt(cf["median"]) if cf else "—"))


def _ablation(lines, agg):
    lines.append("单半径 matched cold 中位数（每步只应带来它自己的收益）：")
    lines.append("")
    lines.append("| 城市 | B1 | 仅C1 | C1+C2 | +按秩扫描(full) |")
    lines.append("|---|---:|---:|---:|---:|")
    for ds, city, _ in CITY_ORDER:
        row = []
        for m in ("b1", "c1", "c2", "c"):
            a = agg.get((ds, city, "single", "matched", m, "cold"))
            row.append("%.1f" % a["median"] if a else "—")
        lines.append("| %s | %s |" % (city, " | ".join(row)))
    lines.append("")
    lines.append("归因依据：C1 = 块剪枝把候选行分成“全保留/全删除/不确定”，"
                 "只有不确定行需要精查；C2 = 配额区间闭合让部分折不必判完；"
                 "按秩扫描 = 选择阶段按配额提前停下。三者叠加后仍慢于 B1，"
                 "原因是扫描本身要把不确定行逐窗口精查，而六城的不确定行"
                 "接近全池。")


def _counters(lines, agg):
    keys = [k for k in agg
            if k[2] == "batch" and k[3] == "matched" and k[4] == "c"
            and k[5] == "cold"]
    tot = defaultdict(int)
    for k in keys:
        for ck, cv in agg[k].get("counters", {}).items():
            if isinstance(cv, (int, float)):
                tot[ck] += int(cv)
    lines.append("batch / full / cold / matched 的机制计数（六城合计）：")
    lines.append("")
    lines.append("| 计数器 | 值 |")
    lines.append("|---|---:|")
    for ck in ("n_rows_exact", "n_rows_exact_train", "n_rows_exact_test_self",
               "n_block_center_queries", "n_rows_exact_quota",
               "n_rows_exact_select", "n_rows_cache_hits",
               "n_blocks_cand_total", "n_blocks_allkeep",
               "n_blocks_alldelete", "n_blocks_uncertain",
               "n_fast_path", "n_fast_path_fail", "n_scan_rows_examined",
               "n_scan_batches", "n_fallbacks", "n_fallback_rows",
               "n_quota_picks", "n_quota_folds_deferred_max",
               "n_blocks_grid", "n_blocks_total"):
        if ck in tot:
            lines.append("| %s | %d |" % (ck, tot[ck]))
    lines.append("")
    cand = tot.get("n_blocks_cand_total", 0)
    keep = tot.get("n_blocks_allkeep", 0)
    dele = tot.get("n_blocks_alldelete", 0)
    lines.append("块剪枝比例按“该掩码下有候选成员的块”作分母：全保留 %s + "
                 "全删除 %s = %s，占 %s 的 %.1f%%；不确定 %s 块（%.1f%%）。"
                 % ("{:,}".format(keep), "{:,}".format(dele),
                    "{:,}".format(keep + dele), "{:,}".format(cand),
                    100.0 * (keep + dele) / cand if cand else 0.0,
                    "{:,}".format(tot.get("n_blocks_uncertain", 0)),
                    100.0 * tot.get("n_blocks_uncertain", 0) / cand
                    if cand else 0.0))
    lines.append("")
    lines.append("注意 r=0 的掩码按契约“全部保留”，会被整批计进全保留；"
                 "看剪枝效果应看 r>0 的子集，本表是四次半径（0/100/200/400）"
                 "合计后的口径。")
    lines.append("")
    lines.append("网格位置数与有样本的块数不能混用：六城网格位置合计 %s，"
                 "其中含城市样本的只有 %s 个（moscow：5,703 个位置里 276 个）。"
                 "上一轮把整个网格当分母，这一轮的分母是每个（掩码, 半径）"
                 "下有候选成员的块之和。"
                 % ("{:,}".format(tot.get("n_blocks_grid", 0)),
                    "{:,}".format(tot.get("n_blocks_total", 0))))
    lines.append("")
    lines.append("三类查询分开计：训练候选行 %s、测试行自查询 %s（必须为 0）、"
                 "块中心 %s。距离缓存命中 %s 行。"
                 % ("{:,}".format(tot.get("n_rows_exact_train", 0)),
                    "{:,}".format(tot.get("n_rows_exact_test_self", 0)),
                    "{:,}".format(tot.get("n_block_center_queries", 0)),
                    "{:,}".format(tot.get("n_rows_cache_hits", 0))))


def _memory(lines, agg):
    lines.append("每轮峰值工作集（独立采样线程，5 ms 一次；cold，single）：")
    lines.append("")
    lines.append("| 城市 | 输出 | B1 峰值 MiB | full 峰值 MiB | 采样次数 |")
    lines.append("|---|---|---:|---:|---:|")
    any_row = False
    for ds, city, _ in CITY_ORDER:
        for output in ("matched", "audit"):
            b = agg.get((ds, city, "single", output, "b1", "cold"))
            a = agg.get((ds, city, "single", output, "c", "cold"))
            if not b or not a:
                continue
            any_row = True
            lines.append("| %s | %s | %s | %s | %d |"
                         % (city, output, _fmt(b["peak"]), _fmt(a["peak"]),
                            int(b.get("samples") or 0)))
    lines.append("")
    if not any_row:
        lines.append("无可用样本。")
    else:
        lines.append("口径：采样在计时进程内、只覆盖该轮（引擎 + 写出），"
                     "不是进程生命周期峰值；跨方法比较仍受同进程内堆碎片影响，"
                     "若要做严格的峰值对比，应把每个配置放进独立进程。"
                     "上一轮全部 720 条为 0.0，是 ctypes 原型缺失导致查询"
                     "恒失败，这一轮已修复并核对到非零值。")


def _corrections(lines, agg):
    st = _stage_totals(agg)
    lines.append("第一轮报告里“配额阶段省了 1,306,847 行距离计算”这句话**撤回**。"
                 "它的算法是把 B1 的 matched 与 audit 两个输出的全池行数相加"
                 "（2 × 1,364,624 = 2,729,248），却只减了 matched 一个输出的"
                 "配额阶段行数（1,422,401）：两个输出混加，B1 的分母被算成两份。")
    lines.append("")
    lines.append("| 输出 | B1 全池行 | 候选配额阶段行 | 配额阶段差 | 候选全部精查行 | 总值差 |")
    lines.append("|---|---:|---:|---:|---:|---:|")
    for output in ("matched", "audit"):
        b1, cq, ct = st[output]
        if not b1:
            continue
        lines.append("| %s | %s | %s | %s | %s | %s |"
                     % (output, "{:,}".format(b1), "{:,}".format(cq),
                        _signed(cq - b1), "{:,}".format(ct),
                        _signed(ct - b1)))
    lines.append("")
    b1, cq, ct_ = st.get("matched", (0, 0, 0))
    if b1:
        lines.append("更正后的说法：本轮 matched 的配额阶段 %s 行，比 B1 全池 "
                     "%s 行少 %s 行；两阶段合计 %s 行，比 B1 少 %s 行。上一轮"
                     "这两个差值分别是 +57,777 与 +192,582（即“比 B1 多”），"
                     "差额就是被删掉的测试行自查询（321,012 次）及其连带的"
                     "回退决策变化（第 8.1 节）：证明“每折至少 q 个合格行”时，"
                     "旧实现把这些测试行也当候选行判了一遍。"
                     % ("{:,}".format(cq), "{:,}".format(b1),
                        "{:,}".format(b1 - cq), "{:,}".format(ct_),
                        "{:,}".format(b1 - ct_)))
    lines.append("")
    lines.append("结论方向不变：共同配额并不改变量级，删掉自查询后总行数才低于 "
                 "B1，但端到端仍更慢（第 2 节）。行数不是时间，块中心查询"
                 "（%s 行）也另计。"
                 % "{:,}".format(sum(a.get("counters", {}).get(
                     "n_block_center_queries", 0) for k, a in agg.items()
                     if k[2] == "batch" and k[3] == "matched"
                     and k[4] == "c" and k[5] == "cold")))
    lines.append("")
    lines.append("其余撤回/更正项：")
    lines.append("")
    lines.append("- 峰值内存全部 `0.0`：作废，改为每轮采样（第 6 节）。")
    lines.append("- 块剪枝比例的分母：改为有候选成员的块（第 5 节）。")
    lines.append("- “audit 必须判完全部剩余行”导致 audit 精查行数被记成"
                 "全池两倍：已改为只精查未获几何证明的行，audit 与 matched "
                 "的精查行数现在基本一致。")


def _selfquery(lines, agg, correctness, run_dir=None):
    old = {}
    p = Path(__file__).resolve().parents[1] / "work" / "before_counters.json"
    if p.exists():
        try:
            old = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            old = {}
    before = old.get("selfquery_matched_batch", {})
    lines.append("### 8.1　本折测试行的自查询")
    lines.append("")
    lines.append("| 城市 | 改前自查询次数 | 改后自查询次数 | 改前 matched 精查行 | 改后 matched 精查行 |")
    lines.append("|---|---:|---:|---:|---:|")
    tot_before = tot_after = tot_rows_b = tot_rows_a = 0
    for ds, city, _ in CITY_ORDER:
        a = agg.get((ds, city, "batch", "matched", "c", "cold"))
        c = a.get("counters", {}) if a else {}
        b_n = before.get(city, 0)
        a_n = c.get("n_rows_exact_test_self", 0)
        b_r = before.get(city + "_n_rows_exact", 0)
        a_r = c.get("n_rows_exact", 0)
        tot_before += b_n
        tot_after += a_n
        tot_rows_b += b_r
        tot_rows_a += a_r
        lines.append("| %s | %s | %s | %s | %s |"
                     % (city, "{:,}".format(b_n), "{:,}".format(a_n),
                        "{:,}".format(b_r), "{:,}".format(a_r)))
    lines.append("| 合计 | %s | %s | %s | %s |"
                 % ("{:,}".format(tot_before), "{:,}".format(tot_after),
                    "{:,}".format(tot_rows_b), "{:,}".format(tot_rows_a)))
    lines.append("")
    lines.append("改前数字在 `work/legacy_splitbench`（改动前的包快照）上用 "
                 "`work/repro_before.py` 复现，与工单的 321,012 次一致。改后"
                 "逐折为 0：扫描用的类序已按折预过滤为候选行，测试行不再"
                 "进入任何精查路径。总精查行数的下降与自查询数不完全相等，"
                 "差额来自少数折的回退决策被改写（回退次数在计数器 "
                 "`n_fallbacks` 里可见），不是残留的测试行查询。")
    lines.append("")
    lines.append("### 8.2　有界缓存扩半径回归（100→200 米）")
    lines.append("")
    reg = [r for r in correctness
           if r["method"].startswith("b1b@") and "@warm" not in r["method"]]
    cnt = defaultdict(lambda: [0, 0])
    for r in reg:
        k = r["method"]
        cnt[k][0] += 1
        if r["match"] not in ("True", "true", "1"):
            cnt[k][1] += 1
    lines.append("| 用例 | 检查行 | 不一致 |")
    lines.append("|---|---:|---:|")
    for k in sorted(cnt):
        lines.append("| %s | %d | %d |" % (k, cnt[k][0], cnt[k][1]))
    lines.append("")
    lines.append("用例覆盖 100→200、200→100、重复 200、以及 200±5e-9 的边界值；"
                 "判据是热复用状态的逐折配额与有序行必须等于全新无界 B1，"
                 "并与冻结旧函数参考一致。改前该用例在 moscow 上 20 个 "
                 "repeat 全部不一致（首组 (12,978) 对 (12,733)）。此处只是"
                 "回归检查，不是计时；计时见第 3 节。")
    lines.append("")
    lines.append("### 8.3　旧/新候选对同一强基线的时间（单主半径，matched，cold）")
    lines.append("")
    prev_path = ((run_dir.parent / PREV_RUN / "bench_summary.csv")
                 if run_dir is not None else None)
    prev_rows = _read_csv(prev_path) if prev_path is not None else []
    if not prev_rows:
        lines.append("第一轮汇总不可读，跳过本节。")
        return
    prev = {}
    for r in prev_rows:
        if r["mode"] != "single" or r["output"] != "matched" \
                or r["variant"] != "cold":
            continue
        prev[(r["city"], r["method"])] = float(r["median_ms_total"])
    lines.append("| 城市 | 旧 full | 旧 B1 | 旧比值(对 B1) | 新 full | 新 B1 | 新比值(对 B1) |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|")
    ratios = []
    for ds, city, _ in CITY_ORDER:
        ob, oc = prev.get((city, "b1")), prev.get((city, "c"))
        nb = agg.get((ds, city, "single", "matched", "b1", "cold"))
        nc = agg.get((ds, city, "single", "matched", "c", "cold"))
        if not (ob and oc and nb and nc):
            continue
        ratios.append(nc["median"] / nb["median"])
        lines.append("| %s | %.1f | %.1f | %.2f | %.1f | %.1f | %.2f |"
                     % (city, oc, ob, oc / ob, nc["median"], nb["median"],
                        nc["median"] / nb["median"]))
    lines.append("")
    old_ratios = [prev[(c, "c")] / prev[(c, "b1")] for _, c, _ in CITY_ORDER
                  if (c, "c") in prev and (c, "b1") in prev]
    lines.append("两轮的 B1 是同一份实现、同一份输入，可以直接比；候选的绝对"
                 "时间在两轮之间不可逐毫秒对齐（删掉的工作改变了缓存命中与"
                 "回退路径），所以看**对 B1** 的比值：新中位数 %.2f，改前 "
                 "%.2f。"
                 % (_stat.median(ratios) if ratios else float("nan"),
                    _stat.median(old_ratios) if old_ratios else float("nan")))
    tuned = []
    for ds, city, _ in CITY_ORDER:
        ob, oc = prev.get((city, "b1")), prev.get((city, "c"))
        nb = agg.get((ds, city, "single", "matched", "b1", "cold"))
        nc = agg.get((ds, city, "single", "matched", "c", "cold"))
        if not (ob and oc and nb and nc):
            continue
        old_r, new_r = oc / ob, nc["median"] / nb["median"]
        tuned.append((city, old_r, new_r, new_r - old_r))
    better = [t[0] for t in tuned if t[3] < -0.02]
    worse = [t[0] for t in tuned if t[3] > 0.02]
    med_new = _stat.median(ratios) if ratios else float("nan")
    med_old = _stat.median(old_ratios) if old_ratios else float("nan")
    lo = min(ratios) if ratios else float("nan")
    hi = max(ratios) if ratios else float("nan")
    lines.append("")
    if better and not worse:
        trend = ("%d 个城市的比值收窄（%s），没有城市变差，比值中位数从 "
                 "%.2f 降到 %.2f" % (len(better), "、".join(better),
                                    med_old, med_new))
    elif better:
        trend = ("%s 收窄，%s 上升，其余在噪声内，比值中位数从 %.2f 到 %.2f"
                 % ("、".join(better), "、".join(worse), med_old, med_new))
    else:
        trend = ("没有城市的比值出现超出噪声的改善，比值中位数从 %.2f 到 "
                 "%.2f" % (med_old, med_new))
    lines.append("逐城看：%s。" % trend)
    lines.append("")
    lines.append("可以确证的是工作量下降：六城 matched 精查行数从 1,557,206 "
                 "降到 1,236,189（-20.6%%），测试行自查询从 321,012 降到 0。"
                 "但差距没有被消掉——新比值仍在 %.2f–%.2f，最低的 %s 也还有 "
                 "%.0f%% 的额外开销；这部分开销来自扫描的 Python 步进行走与"
                 "小块查询，不是被删掉的自查询。"
                 % (lo, hi, min(tuned, key=lambda t: t[2])[0] if tuned else "—",
                    100.0 * (lo - 1.0)))
    lines.append("")
    lines.append("结论：修完之后候选仍然慢于 B1（对 B1 为 %.2f–%.2f 倍；对"
                 "两种 KD 基线中较快者见第 2 节），方向没有改变；扩到 48 城"
                 "不会改变这个方向，只会放大它。" % (lo, hi))


def _limits(lines):
    for t in (
        "六城是机制验证，不构成规模主张；扩到全部可行城市是 P1 的事，"
        "且以 P0 有明确优势为前提。当前证据支持暂停 48 城扩算。",
        "candidate 的收益依赖块下界质量；点在测试掩码内高度聚集的稠密散点折"
        "会触发向量化回退（计数器 n_fallbacks 可见），最坏情形不优于 B1。",
        "matched 省下的扫描不是 audit 的收益：audit/统计口径必须判完所有"
        "未获几何证明的行，本报告分开计量。",
        "C2 区间闭合只保证配额值精确，不要求每个折都被精查；未精查折的 "
        "kept 计数只有区间界，audit 输出另行完整判定。",
        "PostGIS 列 pending；块大小与扫描阈值在留出开发城市（wh、mumbai、"
        "islamabad、cairo）一次性标定，未在六城上调参。",
        "峰值内存用进程内采样线程，能区分单轮但与其它方法共享同一进程的"
        "堆；严格对比需独立进程。",
        "查新未做：'带共同配额的空间反连接＋稳定分层抽样'的最近算法与可用"
        "实现留待 P1 前补检。",
    ):
        lines.append("- " + t)

