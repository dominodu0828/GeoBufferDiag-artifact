# -*- coding: utf-8 -*-
"""Gate B isolated-memory child (06 work order sec. 9.4.4).

Runs ONE (dataset, city, method, mode) cold matched pass in its own
process and prints a single JSON line:

    baseline_rss_mb   -- interpreter + stdlib only, BEFORE importing
                         splitbench/numpy/scipy (the "empty process")
    pre_rss_mb        -- after frozen inputs are loaded and the engine is
                         constructed, before run_city
    peak_rss_mb       -- 2 ms sampling thread over run_city + writers
    pre_exit_rss_mb   -- after everything, before exit
    interval_ms       -- sampling interval
    samples           -- number of samples taken

Never run this inside the shared bench process: the whole point is that a
method's peak must not inherit another method's heap (9.4.4).
"""
from __future__ import annotations

import argparse
import ctypes
import json
import sys
import time


def _rss_mb():
    from ctypes import wintypes

    class _PMC(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD),
                    ("PageFaultCount", wintypes.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t)]

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    fn = k32.K32GetProcessMemoryInfo
    cur = k32.GetCurrentProcess
    cur.argtypes = []
    cur.restype = wintypes.HANDLE
    fn.argtypes = [wintypes.HANDLE, ctypes.POINTER(_PMC), wintypes.DWORD]
    fn.restype = wintypes.BOOL
    pmc = _PMC()
    pmc.cb = ctypes.sizeof(_PMC)
    if not fn(cur(), ctypes.byref(pmc), pmc.cb):
        return None
    return pmc.WorkingSetSize / (1024.0 * 1024.0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--city", required=True)
    ap.add_argument("--method", required=True)
    ap.add_argument("--mode", default="single", choices=("single", "batch"))
    ap.add_argument("--radii-json", default=None,
                    help="exact JSON radius list for the workload")
    ap.add_argument("--writer", choices=("production", "split"),
                    default="production")
    ap.add_argument("--output-dir", default=None)
    ap.add_argument("--synthetic", default=None,
                    help="n,geometry -- generate a Gate D city instead of "
                         "loading a frozen one")
    a = ap.parse_args()

    baseline = _rss_mb()                      # empty-process baseline

    t0 = time.perf_counter()
    from pathlib import Path

    # script mode does not put the project root on sys.path (the same
    # reason splitbench_cli.py exists); insert it portably
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

    from splitbench.candidate import CandidateEngine
    from splitbench.baseline_b1 import B1Engine
    from splitbench.rss import PeakSampler
    from splitbench.settings import ROOT, load_config
    from splitbench.verifylib import load_city_inputs
    from splitbench.writers import write_outputs, write_status
    import_time = (time.perf_counter() - t0) * 1000.0

    run_dir = Path(a.run)
    cfg = load_config(ROOT / "configs" / "paper_primary.yaml")
    if a.synthetic:
        import numpy as np
        from splitbench.gate_d import DESIGN_SEED, make_city
        n_s, geo_s = a.synthetic.split(",")
        ct, folds = make_city(int(n_s), geo_s,
                              np.random.default_rng(DESIGN_SEED))
    else:
        ct, folds = load_city_inputs(run_dir, a.dataset, a.city)
    if a.method == "b1":
        eng = B1Engine()
    elif a.method == "b1b":
        eng = B1Engine(bounded=True)
    else:
        eng = CandidateEngine(arm=a.method, side=1000.0, margin=1e-6,
                              batch_rows=4096, policy="priority")
    if a.radii_json is not None:
        radii = [float(r) for r in json.loads(a.radii_json)]
    elif a.synthetic:
        from splitbench.gate_d import reference_radii
        p50 = reference_radii()["p50"]
        radii = [p50] if a.mode == "single" else [0.0, p50]
    else:
        radii = ([float(cfg["radii"]["primary"][a.dataset])]
                 if a.mode == "single"
                 else [float(r) for r in cfg["radii"]["sweep"]])
    out_dir = Path(a.output_dir) if a.output_dir else run_dir
    if a.writer == "split":
        from splitbench.profile import write_payload_split
    from threadpoolctl import threadpool_limits
    pre = _rss_mb()
    sampler = PeakSampler(interval=0.002).start()
    t0 = time.perf_counter()
    with threadpool_limits(limits=1):
        res, _ = eng.run_city(ct, folds, radii, "matched")
        if a.writer == "split":
            out_path = out_dir / "out" / eng.name / (
                "%s__%s__matched.csv.gz" % (ct.dataset, ct.city))
            rows, bytes_out, _, _ = write_payload_split(
                out_path, ct, folds, res, "matched")
        else:
            rows, bytes_out, _ = write_outputs(out_dir, eng.name, ct, folds,
                                               res, "matched")
        write_status(out_dir, eng.name, ct, folds, res, radii, "matched")
    ms_total = (time.perf_counter() - t0) * 1000.0
    peak, samples = sampler.stop()
    pre_exit = _rss_mb()

    print(json.dumps({
        "baseline_rss_mb": baseline, "pre_rss_mb": pre,
        "peak_rss_mb": peak, "pre_exit_rss_mb": pre_exit,
        "interval_ms": 2, "samples": samples, "ms_total": round(ms_total, 1),
        "import_ms": round(import_time, 1), "rows_out": rows,
        "mode": a.mode, "radii_json": json.dumps(radii),
        "writer": a.writer, "output_dir": str(out_dir),
        "bytes_out": bytes_out,
        "counters": {k: v for k, v in res.counters.items()
                     if isinstance(v, (int, float))}}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
