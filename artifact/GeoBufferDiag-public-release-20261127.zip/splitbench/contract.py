# -*- coding: utf-8 -*-
"""Exact query contract (work order sec. 3) shared by every engine.

Semantics, pinned to the frozen implementation:

* Pool.  For a fold with test mask T the candidate pool is R = ~T.  Radius
  r = 0 is the unbuffered arm and keeps every candidate, even coincident
  coordinates.  Radius r > 0 deletes every candidate whose nearest test-point
  distance (projected float64 Euclidean metres) is <= r; the kept pool is
  R_r = {i in R : d(i, T) > r}.  Negative radii, non-finite values, wrong
  dimensions and unknown units are invalid inputs (inputs.InvalidInput).

* Common quota.  For one repeat, q_y = min over the repeat's usable scattered
  folds and the fixed contiguous folds of the class-y count of the *buffered*
  pool (the unbuffered pool is a superset, so it never binds; the frozen
  ``common_budget`` takes the min over both kinds and this is provably the
  same value).  Floor: q_y >= 5 per class, else the repeat is infeasible and
  the whole city-radius grid is rejected (frozen ``city_L``).  Quotas are per
  repeat -- never per fold, never one min across repeats.

* Selection.  Both arms of a comparison use the same quota.  Per class take
  the q_y smallest common random keys among *available* rows, ties broken by
  original row order; output positives first, then negatives (frozen
  ``subsample``).  With the quota fixed: if every row the unbuffered arm
  selected also survives the buffer, the buffered selection is identical --
  a fixed total order means deleted rows can neither squeeze into nor out of
  the prefix.  This fast path may only be used after the common quota is
  fixed, never as a substitute for computing it.
"""
from __future__ import annotations

import numpy as np

from .inputs import InvalidInput, _validate_radius  # noqa: F401  (re-export)


FLOAT64_ROUND_OFF_ULPS = 16


def roundoff_margin(scale, absolute: float):
    """Absolute floor plus a scale-dependent float64 guard."""
    return np.maximum(float(absolute), FLOAT64_ROUND_OFF_ULPS
                      * np.finfo(np.float64).eps * np.abs(scale))


# ---------------------------------------------------------------------------
# class orders: (key, original row) total order, precomputed once per city
# ---------------------------------------------------------------------------
def class_orders(y: np.ndarray, keys: np.ndarray):
    """Return (order_pos, order_neg): candidate indices per class sorted by
    (key, original row).  ``np.argsort`` with kind='stable' over the class
    member list in ascending row order reproduces the frozen subsample's
    stable sort exactly."""
    idx_pos = np.flatnonzero(y == 1)
    idx_neg = np.flatnonzero(y == 0)
    order_pos = idx_pos[np.argsort(keys[idx_pos], kind="stable")]
    order_neg = idx_neg[np.argsort(keys[idx_neg], kind="stable")]
    return order_pos, order_neg


def select_prefix(order: np.ndarray, pool: np.ndarray, q: int) -> np.ndarray:
    """First q members of ``order`` that are in ``pool`` (boolean over rows)."""
    if q == 0:
        return order[:0]
    avail = pool[order]
    picked = np.flatnonzero(avail)
    return order[picked[:q]]


def select_arms(y: np.ndarray, orders, pool_unbuf: np.ndarray,
                pool_buf: np.ndarray, q_pos: int, q_neg: int):
    """Both arms' ordered training indices for one comparison.

    Returns (unbuffered_ids, buffered_ids, fast_path_used).  Each id list is
    positives-then-negatives, each class ascending by (key, row)."""
    order_pos, order_neg = orders
    unbuf = np.concatenate([select_prefix(order_pos, pool_unbuf, q_pos),
                            select_prefix(order_neg, pool_unbuf, q_neg)])
    # Fast path: with the quota fixed, an unbuffered selection whose rows all
    # survive the buffer IS the buffered selection.
    prefix_ok = bool(pool_buf[unbuf].all()) if len(unbuf) else True
    if prefix_ok:
        return unbuf, unbuf.copy(), True
    buf = np.concatenate([select_prefix(order_pos, pool_buf, q_pos),
                          select_prefix(order_neg, pool_buf, q_neg)])
    return unbuf, buf, False


# ---------------------------------------------------------------------------
# quota
# ---------------------------------------------------------------------------
def kept_counts(y: np.ndarray, cand_idx: np.ndarray,
                kept_mask: np.ndarray) -> tuple[int, int]:
    """(n_pos, n_neg) kept among candidates given a kept boolean over rows."""
    kept_labels = y[cand_idx[kept_mask[cand_idx]]] if len(cand_idx) else y[:0]
    return int((kept_labels == 1).sum()), int((kept_labels == 0).sum())


def quota_for_repeat(y: np.ndarray, fold_cand: list[np.ndarray],
                     fold_kept: list[np.ndarray], floor: int):
    """Common quota of one repeat from per-fold kept boolean masks.

    fold_cand[k] are the candidate indices of fold k (~test); fold_kept[k] is
    a boolean over rows (True = survives the buffer).  Returns
    ((q_pos, q_neg), feasible).  This reproduces the frozen common_budget's
    value: the min over the unbuffered pools is redundant because each
    buffered pool is a subset of its own unbuffered pool.
    """
    q_pos = q_neg = None
    for cand, kept in zip(fold_cand, fold_kept):
        p, n = kept_counts(y, cand, kept)
        q_pos = p if q_pos is None else min(q_pos, p)
        q_neg = n if q_neg is None else min(q_neg, n)
    if q_pos is None:                    # no usable fold: infeasible repeat
        return (0, 0), False
    feasible = q_pos >= floor and q_neg >= floor
    return (q_pos, q_neg), feasible


# ---------------------------------------------------------------------------
# fold bookkeeping
# ---------------------------------------------------------------------------
class CityFolds:
    """Frozen folds of one city: fixed contiguous blocks + scattered repeats.

    Single-class folds are already dropped by the frozen unit builders; a
    repeat with no usable fold, or a city with no usable block, is the frozen
    'no usable units' state (whole city rejected)."""
    __slots__ = ("blocks", "scatter", "n_repeats", "usable")

    def __init__(self, blocks: list[np.ndarray],
                 scatter: list[list[np.ndarray]]):
        self.blocks = blocks
        self.scatter = scatter
        self.n_repeats = len(scatter)
        self.usable = bool(blocks) and all(us for us in scatter)

    def repeat_folds(self, rep: int):
        """[(geometry_code, fold_idx, test_mask)] for one repeat.

        geometry_code 0 = contiguous block (fixed across repeats), 1 =
        scattered fold.  Order: contiguous first, then scattered, fixed."""
        out = [(0, k, te) for k, te in enumerate(self.blocks)]
        out += [(1, k, te) for k, te in enumerate(self.scatter[rep])]
        return out


def build_folds(C, ct, n_repeats: int) -> CityFolds:
    """Frozen fold construction via the frozen builders (K=5, SEED=20260801
    are hardwired inside the old functions and are not parametrised)."""
    cd = ct.to_city_data()
    blocks = C.contiguous_units(cd)
    scatter = C.scattered_repeats(cd, n_rep=n_repeats)
    return CityFolds(blocks, scatter)


# ---------------------------------------------------------------------------
# brute-force nearest-test distance (B0 reference kernel; no cKDTree)
# ---------------------------------------------------------------------------
def nn_distance_bruteforce(xy: np.ndarray, test_mask: np.ndarray,
                           cand_idx: np.ndarray,
                           chunk: int = 256) -> np.ndarray:
    """Nearest-test distance for each candidate, explicit per-point math.

    No cKDTree, no candidate pruning: for each chunk of candidates the full
    pairwise distance matrix to the test set is formed and reduced.  This is
    the reference kernel every faster engine is checked against."""
    test_xy = xy[test_mask]
    out = np.empty(len(cand_idx), dtype=np.float64)
    for s in range(0, len(cand_idx), chunk):
        c = cand_idx[s:s + chunk]
        diff = xy[c][:, None, :] - test_xy[None, :, :]
        out[s:s + len(c)] = np.sqrt((diff * diff).sum(-1)).min(1)
    return out


def buffered_keep_mask(y: np.ndarray, xy: np.ndarray, test_mask: np.ndarray,
                       r: float, cand_idx: np.ndarray) -> np.ndarray:
    """Boolean over rows: candidate survives the buffer at radius r.

    r = 0 keeps everything (the unbuffered arm), matching the frozen
    buffered_pool's r <= 0 branch; r < 0 is invalid and rejected."""
    r = _validate_radius(r)
    keep = np.zeros(len(y), dtype=bool)
    if r == 0:
        keep[cand_idx] = True
        return keep
    d = nn_distance_bruteforce(xy, test_mask, cand_idx)
    keep[cand_idx[d > r]] = True
    return keep
