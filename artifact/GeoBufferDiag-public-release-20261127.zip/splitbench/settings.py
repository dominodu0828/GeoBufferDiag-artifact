# -*- coding: utf-8 -*-
"""Fixed settings: a restricted YAML reader plus suite/config access.

PyYAML is not installed in the frozen interpreter, and P0 must run with the
old environment untouched.  The config file is written in the small YAML
subset below (nested mappings, block lists, inline lists/dicts, scalars) and
``load_config`` parses exactly that -- a malformed file is an error, not a
fallback.  No semantic value (seed, quota floor, folds) may be overridden
from the CLI; only scopes and repetition counts are per-call arguments.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs" / "paper_primary.yaml"

_INT = re.compile(r"^[+-]?\d+$")
_FLOAT = re.compile(r"^[+-]?(\d+\.\d*|\.\d+|\d+[eE][+-]?\d+)$")


def _scalar(tok: str):
    tok = tok.strip()
    if tok in ("", "~", "null"):
        return None
    if len(tok) >= 2 and tok[0] == tok[-1] and tok[0] in "'\"":
        return tok[1:-1]
    if tok in ("true", "True"):
        return True
    if tok in ("false", "False"):
        return False
    if _INT.match(tok):
        return int(tok)
    if _FLOAT.match(tok):
        return float(tok)
    return tok


def _split_top(s: str):
    """Split on commas that are not inside brackets or quotes."""
    out, depth, quote, cur = [], 0, "", ""
    for ch in s:
        if quote:
            cur += ch
            if ch == quote:
                quote = ""
        elif ch in "'\"":
            quote = ch
            cur += ch
        elif ch in "[{":
            depth += 1
            cur += ch
        elif ch in "]}":
            depth -= 1
            cur += ch
        elif ch == "," and depth == 0:
            out.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur)
    return out


def _inline(s: str):
    s = s.strip()
    if s.startswith("[") and s.endswith("]"):
        return [_scalar(t) for t in _split_top(s[1:-1])]
    if s.startswith("{") and s.endswith("}"):
        out = {}
        for item in _split_top(s[1:-1]):
            k, _, v = item.partition(":")
            out[_scalar(k)] = _inline(v)
        return out
    return _scalar(s)


def _strip_comment(line: str) -> str:
    out, quote = "", ""
    for ch in line:
        if quote:
            out += ch
            if ch == quote:
                quote = ""
        elif ch in "'\"":
            quote = ch
            out += ch
        elif ch == "#":
            break
        else:
            out += ch
    return out.rstrip()


def load_config(path: Path = DEFAULT_CONFIG) -> dict:
    """Parse configs/*.yaml (restricted subset) and validate the schema."""
    lines = [_strip_comment(l) for l in path.read_text(encoding="utf-8").splitlines()]
    cfg = _parse_sections(lines)
    _validate(cfg)
    return cfg


def _parse_sections(lines: list[str]) -> dict:
    cfg: dict = {}
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        indent = len(line) - len(line.lstrip(" "))
        if indent == 0 and line.strip().endswith(":"):
            cfg[line.strip()[:-1]] = _parse_block(lines, i + 1, 2)
        i += 1
    return cfg


def _parse_block(lines: list[str], start: int, indent: int) -> dict:
    out: dict = {}
    i = start
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        cur = len(line) - len(line.lstrip(" "))
        if cur < indent:
            break
        if cur > indent:
            raise ValueError("unexpected indent: %r" % line)
        text = line.strip()
        key, _, value = text.partition(":")
        key, value = key.strip(), value.strip()
        if value:
            out[key] = _inline(value)
            i += 1
            continue
        # "key:" -- nested mapping or block list on the following lines
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j < len(lines):
            nxt = lines[j]
            nind = len(nxt) - len(nxt.lstrip(" "))
            if nind > indent and nxt.strip().startswith("- "):
                out[key] = _parse_list(lines, j, nind)
                i = j
                while i < len(lines):
                    ln = lines[i]
                    if not ln.strip():
                        i += 1
                        continue
                    c = len(ln) - len(ln.lstrip(" "))
                    if c >= nind and ln.strip().startswith("- "):
                        i += 1
                        continue
                    break
                continue
            if nind > indent:
                out[key] = _parse_block(lines, j, nind)
                i = j
                while i < len(lines):
                    ln = lines[i]
                    if not ln.strip():
                        i += 1
                        continue
                    c = len(ln) - len(ln.lstrip(" "))
                    if c > indent:
                        i += 1
                        continue
                    break
                continue
        out[key] = {}
        i += 1
    return out


def _parse_list(lines: list[str], start: int, indent: int) -> list:
    out = []
    i = start
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        cur = len(line) - len(line.lstrip(" "))
        if cur < indent or not line.strip().startswith("- "):
            break
        if cur > indent:
            raise ValueError("unexpected indent in list: %r" % line)
        out.append(_inline(line.strip()[2:].strip()))
        i += 1
    return out


def _validate(cfg: dict):
    for sec, keys in (("run", ("seed", "quota_floor", "k_blocks", "threads")),
                      ("datasets", None), ("suites", None), ("radii", None),
                      ("bench", None), ("engine", None)):
        if sec not in cfg:
            raise ValueError("config missing section %r" % sec)
        for k in keys or ():
            if k not in cfg[sec]:
                raise ValueError("config %s.%s missing" % (sec, k))
    for ds in ("streetview", "so2sat10", "so2sat43"):
        if ds not in cfg["datasets"]:
            raise ValueError("config datasets.%s missing" % ds)
    for suite in ("six-city", "dev-calibration"):
        if suite not in cfg["suites"]:
            raise ValueError("config suites.%s missing" % suite)


def suite_cities(cfg: dict, suite: str) -> list[tuple[str, str]]:
    """[(dataset, city), ...] in fixed suite order."""
    out = []
    for entry in cfg["suites"][suite]:
        for city in entry["cities"]:
            out.append((entry["dataset"], city))
    return out


def primary_radius(cfg: dict, dataset: str) -> float:
    return float(cfg["radii"]["primary"][dataset])


def dumps(obj) -> str:
    return json.dumps(obj, indent=1, ensure_ascii=False, default=str)

