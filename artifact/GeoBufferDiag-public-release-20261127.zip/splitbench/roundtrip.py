# -*- coding: utf-8 -*-
"""roundtrip: read every deliverable file back from disk and compare it
against the engine result that produced it (closeout plan sec. 4/5).

In-memory equality (verify) never exercises the writer; the Moscow ``%g``
collapse proved that a byte-perfect memory result can still land on disk
with 40 duplicate status keys and 640 duplicate payload keys.  This module
closes that gap:

* every file the writer produces -- matched / audit / stats payloads and
  their ``__status.csv`` companions -- is parsed back from disk;
* radius strings must round-trip to the exact float64 identity of the
  request (``float(repr(r)) == r``), so near-adjacent radii stay distinct;
* (radius, repeat) status keys and payload fold keys (radius, repeat,
  geometry, fold, arm) must be complete and unique; a duplicated-radius
  request saves one block per distinct radius while the full request list
  (duplicates included) is carried in the bench ``radii`` column;
* both arms' ordered original row numbers, multiplicities, quotas, audit
  pools (candidate / kept / deleted), feasibility flags and rejection
  reasons are compared against the in-memory result;
* stats rows are re-checked for conservation **from the CSV**:
  ``n_kept + n_deleted == n_cand`` and ``kept_pos + kept_neg == n_kept``
  (the zero-radius defect had to be catchable on disk, not only in memory);
* infeasible city-radius cells must have status records with a rejection
  reason even though no payload rows exist for them.

Missing records and inconsistent records are two different counters; the
first difference of either kind is saved with its reproduction input.
Fault injection (default on) mutates *copies* of the delivered files -- a
deleted status record, a deleted payload file, a duplicated status key, a
tampered radius string, a tampered sample ID -- and asserts the reader
detects each one; mutated copies live under the run's ``review/`` tree,
never in the delivered ``out/`` tree.
"""
from __future__ import annotations

import csv as _csv
import gzip
import json
import sys
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

from .baseline_b1 import B1Engine
from .candidate import CandidateEngine
from .settings import suite_cities
from .verifylib import load_city_inputs
from .writers import GEOM_NAMES, STATUS_COLS, fmt_radius, write_outputs, \
    write_status

BOUNDARY_OFFSET = 5e-9       # same half-margin the bounded query uses
INFEASIBLE_RADIUS_M = 1e6    # 1000 km: every candidate inside the buffer
GEOM_CODE = {v: k for k, v in GEOM_NAMES.items()}


def _radius_sets(cfg, ds):
    primary = float(cfg["radii"]["primary"][ds])
    return {
        "primary": [primary],
        "boundary": [primary - BOUNDARY_OFFSET, primary,
                     primary + BOUNDARY_OFFSET],
        "dup": [float(r) for r in cfg["radii"]["batch_with_duplicate"]],
        "infeasible": [INFEASIBLE_RADIUS_M],
    }


class _FirstDiff:
    """Collects the first missing and the first inconsistent finding."""

    def __init__(self):
        self.missing = None
        self.inconsistent = None

    def miss(self, **kw):
        if self.missing is None:
            self.missing = kw

    def bad(self, **kw):
        if self.inconsistent is None:
            self.inconsistent = kw


def _ids(s: str) -> np.ndarray:
    return (np.array([int(v) for v in s.split("|")], dtype=np.int64)
            if s else np.zeros(0, dtype=np.int64))


def _eq(a, b) -> bool:
    return len(a) == len(b) and bool(np.array_equal(a, b))


def _read_status(path: Path, folds, res, radii_req, fd, where):
    """Read one __status.csv back; returns (rows, missing, bad, dup)."""
    n_missing = n_bad = n_dup = 0
    with open(path, encoding="utf-8") as fh:
        reader = _csv.DictReader(fh)
        header = reader.fieldnames
        rows = list(reader)
    if header != STATUS_COLS:
        fd.bad(where=where, what="status_header", detail=str(header))
        n_bad += 1
    uniq = set(float(r) for r in radii_req)
    seen = set()
    have = set()
    for row in rows:
        key = (row["radius"], row["repeat"])
        if key in seen:
            fd.bad(where=where, what="duplicate_status_key", detail=str(key))
            n_dup += 1
        seen.add(key)
        try:
            r = float(row["radius"])
            rep = int(row["repeat"])
        except ValueError:
            fd.bad(where=where, what="key_unparseable", detail=str(key))
            n_bad += 1
            continue
        have.add((r, rep))
        st = res.status.get(r)
        if st is None:
            fd.bad(where=where, what="status_radius_not_requested",
                   detail=repr(r))
            n_bad += 1
            continue
        feasible = st["feasible"]
        if row["feasible"] != str(feasible):
            fd.bad(where=where, what="status_feasible", radius=repr(r),
                   repeat=rep, disk=row["feasible"], memory=str(feasible))
            n_bad += 1
        quotas = list(res.quota.get(r) or [])
        if feasible:
            q = quotas[rep] if rep < len(quotas) else None
            if q is None or int(row["budget_pos"]) != int(q[0]) or \
                    int(row["budget_neg"]) != int(q[1]):
                fd.bad(where=where, what="status_budget", radius=repr(r),
                       repeat=rep, disk=(row["budget_pos"], row["budget_neg"]),
                       memory=str(q))
                n_bad += 1
        else:
            if int(row["budget_pos"]) != -1 or int(row["budget_neg"]) != -1:
                fd.bad(where=where, what="status_budget_infeasible",
                       radius=repr(r), repeat=rep,
                       disk=(row["budget_pos"], row["budget_neg"]))
                n_bad += 1
            if not row["note"]:
                fd.bad(where=where, what="rejection_without_reason",
                       radius=repr(r), repeat=rep)
                n_bad += 1
    want = {(r, rep) for r in uniq for rep in range(folds.n_repeats)}
    for key in sorted(want - have):
        fd.miss(where=where, what="status_record_missing",
                radius=repr(key[0]), repeat=key[1])
        n_missing += 1
    return len(rows), n_missing, n_bad, n_dup


def _read_payload(path: Path, ct, folds, res, radii_req, output, fd, where):
    """Read one matched/audit/stats payload back and compare it to memory.

    Returns (rows, missing, bad, dup)."""
    n_missing = n_bad = n_dup = 0
    with gzip.open(path, "rt", encoding="utf-8") as fh:
        reader = _csv.DictReader(fh)
        header = reader.fieldnames
        rows = list(reader)
    uniq = set(float(r) for r in radii_req)

    # ---- expected values straight from the in-memory result -------------
    # mem keys: matched/audit -> (r, rep, geom, fold, arm)
    #           stats         -> (r, rep, geom, fold)
    mem = {}
    if output in ("matched", "audit"):
        for r in uniq:
            feasible = bool((res.status.get(r) or {}).get("feasible"))
            comp_list = res.matched.get(r) or []
            if not feasible:
                if comp_list:
                    fd.bad(where=where, what="infeasible_radius_has_rows",
                           radius=repr(r))
                    n_bad += 1
                continue
            aud = {(a["rep"], a["geom"], a["fold"]): a
                   for a in (res.audit.get(r) or [])}
            for c in comp_list:
                fkey = (c["rep"], c["geom"], c["fold"])
                for arm, idp, idn in (("unbuffered", c["unbuf_pos"],
                                       c["unbuf_neg"]),
                                      ("buffered", c["buf_pos"],
                                       c["buf_neg"])):
                    entry = {"quota": (int(c["quota"][0]),
                                       int(c["quota"][1])),
                             "ids_pos": ct.orig_row[idp],
                             "ids_neg": ct.orig_row[idn]}
                    if output == "audit":
                        a = aud.get(fkey)
                        if a is None:
                            fd.miss(where=where, what="audit_pool_missing",
                                    radius=repr(r), detail=str(fkey))
                            n_missing += 1
                        else:
                            if arm == "unbuffered":
                                # the writer's unbuffered audit row carries
                                # the whole candidate pool as its kept list
                                entry.update(
                                    n_kept=len(a["cand_idx"]), n_deleted=0,
                                    kept_ids=ct.orig_row[a["cand_idx"]],
                                    deleted_ids=np.zeros(0, dtype=np.int64))
                            else:
                                entry.update(
                                    n_kept=len(a["kept_idx"]),
                                    n_deleted=len(a["del_idx"]),
                                    kept_ids=ct.orig_row[a["kept_idx"]],
                                    deleted_ids=ct.orig_row[a["del_idx"]])
                    mem[(r,) + fkey + (arm,)] = entry
    elif output == "stats":
        for r in uniq:
            feasible = bool((res.status.get(r) or {}).get("feasible"))
            stats = res.stats.get(r) or []
            if not feasible and stats:
                fd.bad(where=where, what="infeasible_radius_has_rows",
                       radius=repr(r))
                n_bad += 1
            for s in stats:
                mem[(r, s["rep"], s["geom"], s["fold"])] = {
                    "n_cand": int(s["n_cand"]), "n_kept": int(s["n_kept"]),
                    "n_deleted": int(s["n_deleted"]),
                    "kept_pos": int(s["kept_pos"]),
                    "kept_neg": int(s["kept_neg"]),
                    "quota": (int(s["quota"][0]), int(s["quota"][1]))}

    # ---- disk side -------------------------------------------------------
    seen = set()
    if output in ("matched", "audit"):
        for row in rows:
            try:
                r = float(row["radius"])
                key = (r, int(row["repeat"]),
                       GEOM_CODE[row["geometry"]], int(row["fold"]),
                       row["arm"])
            except (ValueError, KeyError):
                fd.bad(where=where, what="key_unparseable",
                       detail=str({k: row.get(k) for k in
                                   ("radius", "repeat", "geometry", "fold",
                                    "arm")}))
                n_bad += 1
                continue
            if key in seen:
                fd.bad(where=where, what="duplicate_payload_key",
                       detail=str(key))
                n_dup += 1
            seen.add(key)
            m = mem.get(key)
            if m is None:
                fd.bad(where=where, what="payload_key_not_in_memory",
                       detail=str(key))
                n_bad += 1
                continue
            if (int(row["n_pos"]), int(row["n_neg"])) != m["quota"]:
                fd.bad(where=where, what="quota", detail=str(key),
                       disk=(row["n_pos"], row["n_neg"]),
                       memory=str(m["quota"]))
                n_bad += 1
            if not _eq(_ids(row["ids_pos"]), m["ids_pos"]):
                fd.bad(where=where, what="ids_pos_ordered", detail=str(key))
                n_bad += 1
            if not _eq(_ids(row["ids_neg"]), m["ids_neg"]):
                fd.bad(where=where, what="ids_neg_ordered", detail=str(key))
                n_bad += 1
            if output == "audit":
                if (int(row["n_kept"]), int(row["n_deleted"])) != \
                        (m["n_kept"], m["n_deleted"]):
                    fd.bad(where=where, what="pool_counts", detail=str(key),
                           disk=(row["n_kept"], row["n_deleted"]),
                           memory=(m["n_kept"], m["n_deleted"]))
                    n_bad += 1
                if not _eq(_ids(row["kept_ids"]), m["kept_ids"]):
                    fd.bad(where=where, what="kept_ids", detail=str(key))
                    n_bad += 1
                if not _eq(_ids(row["deleted_ids"]), m["deleted_ids"]):
                    fd.bad(where=where, what="deleted_ids", detail=str(key))
                    n_bad += 1
    elif output == "stats":
        for row in rows:
            try:
                r = float(row["radius"])
                key = (r, int(row["repeat"]),
                       GEOM_CODE[row["geometry"]], int(row["fold"]))
            except (ValueError, KeyError):
                fd.bad(where=where, what="key_unparseable",
                       detail=str({k: row.get(k) for k in
                                   ("radius", "repeat", "geometry", "fold")}))
                n_bad += 1
                continue
            if key in seen:
                fd.bad(where=where, what="duplicate_stats_key",
                       detail=str(key))
                n_dup += 1
            seen.add(key)
            nc, nk, nd = (int(row["n_cand"]), int(row["n_kept"]),
                          int(row["n_deleted"]))
            kp, kn = int(row["kept_pos"]), int(row["kept_neg"])
            # conservation straight from the CSV values, before any memory
            # lookup: this is the check that must catch a writer-side bug
            if nk + nd != nc:
                fd.bad(where=where, what="conservation_kept_del",
                       detail=str(key), disk=(nk, nd, nc))
                n_bad += 1
            if kp + kn != nk:
                fd.bad(where=where, what="conservation_class",
                       detail=str(key), disk=(kp, kn, nk))
                n_bad += 1
            m = mem.get(key)
            if m is None:
                fd.bad(where=where, what="stats_key_not_in_memory",
                       detail=str(key))
                n_bad += 1
                continue
            if (nc, nk, nd, kp, kn) != (m["n_cand"], m["n_kept"],
                                        m["n_deleted"], m["kept_pos"],
                                        m["kept_neg"]):
                fd.bad(where=where, what="stats_counts", detail=str(key),
                       disk=(nc, nk, nd, kp, kn),
                       memory=(m["n_cand"], m["n_kept"], m["n_deleted"],
                               m["kept_pos"], m["kept_neg"]))
                n_bad += 1
            if (int(row["quota_pos"]), int(row["quota_neg"])) != m["quota"]:
                fd.bad(where=where, what="stats_quota", detail=str(key),
                       disk=(row["quota_pos"], row["quota_neg"]),
                       memory=str(m["quota"]))
                n_bad += 1
    else:
        raise ValueError("unknown output %r" % output)

    for key in sorted(k for k in mem if k not in seen):
        fd.miss(where=where, what="payload_record_missing", detail=str(key))
        n_missing += 1
    return len(rows), n_missing, n_bad, n_dup


def _mk_engine(method):
    if method == "b1":
        return B1Engine()
    if method == "b1b":
        return B1Engine(bounded=True)
    return CandidateEngine(arm="c", side=1000.0, margin=1e-6, batch_rows=4096)


def run_roundtrip(cfg, run_dir: Path, cities=None, fault_injection=True,
                  suite="six-city"):
    """Full disk round-trip pass; writes roundtrip_summary.json (+ faults).

    Request sets per city: the primary radius, the near-boundary trio
    (primary -+ 5e-9), the duplicated-radius batch request (5 requested ->
    4 unique radii in the payload), and one guaranteed-infeasible radius.
    matched runs cold *and* warm (state reused); audit and stats run cold.
    Every written file is read back and compared against the in-memory
    result that produced it."""
    city_list = [c for c in suite_cities(cfg, suite)
                 if cities is None or ("%s/%s" % c) in cities]
    methods_ma = ("b1", "b1b", "c")          # matched + audit
    methods_st = ("b1", "c")                 # stats
    outputs_plan = []
    for tag in ("primary", "boundary", "dup", "infeasible"):
        outputs_plan.append((tag, "matched", ("cold", "warm")))
        outputs_plan.append((tag, "audit", ("cold",)))
        outputs_plan.append((tag, "stats", ("cold",)))

    summary = {"run_id": run_dir.name,
               "cities": ["%s/%s" % c for c in city_list],
               "request_sets": ["primary", "boundary", "dup",
                                "infeasible"],
               "dup_request_note": "dup requests 5 radii, payload/status "
                                   "carry the 4 unique numeric results; "
                                   "the full list stays in bench.csv",
               "n_files_read": 0, "n_status_rows": 0, "n_payload_rows": 0,
               "n_missing": 0, "n_inconsistent": 0, "n_duplicate_keys": 0,
               "n_requests_checked": 0,
               "first_diff": None, "faults": {}}
    fd = _FirstDiff()
    fault_ref = None
    out_root = run_dir / "out" / "rt"

    for ds, city in city_list:
        ct, folds = load_city_inputs(run_dir, ds, city)
        sets = _radius_sets(cfg, ds)
        with threadpool_limits(limits=1):
            for tag, output, states in outputs_plan:
                radii = sets[tag]
                methods = methods_st if output == "stats" else methods_ma
                for method in methods:
                    eng = _mk_engine(method)
                    state = None
                    for st_tag in states:
                        base = out_root / ("%s__%s" % (tag, st_tag))
                        res, state = eng.run_city(ct, folds, radii, output,
                                                  state=state)
                        write_status(base, eng.name, ct, folds, res, radii,
                                     output)
                        write_outputs(base, eng.name, ct, folds, res, output)
                        if st_tag == "cold" and fault_ref is None:
                            fault_ref = (ct, folds, res, radii, method, tag,
                                         base, output)
                        mdir = base / "out" / method
                        where = "%s/%s %s %s %s/%s" % (ds, city, method,
                                                       tag, output, st_tag)
                        summary["n_requests_checked"] += 1
                        spath = mdir / ("%s__%s__%s__status.csv"
                                        % (ds, city, output))
                        ns, ms, bs, dup = _read_status(spath, folds, res,
                                                       radii, fd, where)
                        summary["n_files_read"] += 1
                        summary["n_status_rows"] += ns
                        summary["n_missing"] += ms
                        summary["n_inconsistent"] += bs
                        summary["n_duplicate_keys"] += dup
                        ppath = mdir / ("%s__%s__%s.csv.gz"
                                        % (ds, city, output))
                        nr, mr, br, dup = _read_payload(ppath, ct, folds,
                                                        res, radii, output,
                                                        fd, where)
                        summary["n_files_read"] += 1
                        summary["n_payload_rows"] += nr
                        summary["n_missing"] += mr
                        summary["n_inconsistent"] += br
                        summary["n_duplicate_keys"] += dup
        print("  roundtrip: %s/%s done (%d files so far, %d missing, "
              "%d inconsistent)"
              % (ds, city, summary["n_files_read"], summary["n_missing"],
                 summary["n_inconsistent"]), flush=True)

    if fault_injection and fault_ref is not None:
        summary["faults"] = _fault_injection(run_dir, fault_ref)

    if fd.missing is not None:
        summary["first_diff"] = {"kind": "missing", **fd.missing}
    elif fd.inconsistent is not None:
        summary["first_diff"] = {"kind": "inconsistent", **fd.inconsistent}
    summary["all_roundtrip_ok"] = (summary["n_missing"] == 0
                                   and summary["n_inconsistent"] == 0
                                   and summary["n_duplicate_keys"] == 0)
    summary["all_faults_detected"] = (
        all(v.get("detected") for v in summary["faults"].values())
        if summary["faults"] else None)
    (run_dir / "roundtrip_summary.json").write_text(
        json.dumps(summary, indent=1, ensure_ascii=False), encoding="utf-8")
    return summary


# ---------------------------------------------------------------------------
# fault injection: mutated copies under review/, detected by the same reader
# ---------------------------------------------------------------------------
def _fault_injection(run_dir, fault_ref):
    """Five file-level faults; the reader must catch every one of them."""
    ct, folds, res, radii, method, tag, base, output = fault_ref
    ds, city = ct.dataset, ct.city
    rev = run_dir / "review" / "fault_injection"
    rev.mkdir(parents=True, exist_ok=True)
    sname = "%s__%s__%s__status.csv" % (ds, city, output)
    pname = "%s__%s__%s.csv.gz" % (ds, city, output)
    faults = {}

    def copy_tree(dest):
        """Copy this fault reference's delivered method dir, keeping the
        ``out/<method>/`` layout the writer produces."""
        import shutil
        src, dst = base / "out" / method, dest / "out" / method
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(src, dst)
        return dest

    def run_reader(dest, note):
        fd = _FirstDiff()
        mdir = dest / "out" / method
        try:
            _, a, b, c = _read_status(mdir / sname, folds, res,
                                      radii, fd, note)
        except (FileNotFoundError, OSError):
            return {"n_missing": 1, "n_inconsistent": 0,
                    "n_duplicate_keys": 0, "detected": True,
                    "first_diff": {"what": "status_file_unreadable"}}
        try:
            _, a2, b2, c2 = _read_payload(mdir / pname, ct, folds,
                                          res, radii, output, fd, note)
        except (FileNotFoundError, OSError):
            a2 = b2 = c2 = 0
            fd.miss(where=note, what="payload_file_unreadable")
        first = fd.missing or fd.inconsistent
        return {"n_missing": a + a2, "n_inconsistent": b + b2,
                "n_duplicate_keys": c + c2,
                "detected": (a + a2 + b + b2 + c + c2) > 0,
                "first_diff": first}

    # 1. one status record deleted -> missing
    d1 = copy_tree(rev / "missing_status")
    with open(d1 / "out" / method / sname, encoding="utf-8") as fh:
        rows = list(_csv.DictReader(fh))
    drop = len(rows) // 2
    with open(d1 / "out" / method / sname, "w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=STATUS_COLS)
        w.writeheader()
        for i, r in enumerate(rows):
            if i != drop:
                w.writerow(r)
    faults["missing_status"] = run_reader(d1, "fault: status row deleted")

    # 2. the payload file itself gone -> missing
    d2 = copy_tree(rev / "missing_file")
    (d2 / "out" / method / pname).unlink()
    fd = _FirstDiff()
    detected = False
    first = None
    try:
        _read_payload(d2 / method / pname, ct, folds, res, radii, output,
                      fd, "fault: payload file deleted")
        first = fd.missing or fd.inconsistent
        detected = first is not None
    except (FileNotFoundError, OSError):
        detected = True
        first = {"what": "payload_file_unreadable"}
    faults["missing_file"] = {"n_missing": 1 if detected else 0,
                              "n_inconsistent": 0, "n_duplicate_keys": 0,
                              "detected": detected, "first_diff": first}

    # 3. a duplicated status key -> duplicate
    d3 = copy_tree(rev / "duplicate_status_key")
    with open(d3 / "out" / method / sname, encoding="utf-8") as fh:
        rows = list(_csv.DictReader(fh))
    with open(d3 / "out" / method / sname, "w", newline="", encoding="utf-8") as fh:
        w = _csv.DictWriter(fh, fieldnames=STATUS_COLS)
        w.writeheader()
        for i, r in enumerate(rows):
            w.writerow(r)
            if i == 0:
                w.writerow(rows[0])
    faults["duplicate_status_key"] = run_reader(
        d3, "fault: status row duplicated")

    # 4. a tampered radius string -> inconsistent
    d4 = copy_tree(rev / "tamper_radius")
    with gzip.open(d4 / "out" / method / pname, "rt", encoding="utf-8") as fh:
        reader = _csv.DictReader(fh)
        pcols = reader.fieldnames
        prows = list(reader)
    uniq = sorted(set(float(r) for r in radii))
    victim = prows[0]
    old = float(victim["radius"])
    new = next((r for r in uniq if r != old), old + 1.0)
    victim["radius"] = fmt_radius(new)
    with gzip.open(d4 / "out" / method / pname, "wt", encoding="utf-8",
                   newline="\n") as fh:
        w = _csv.DictWriter(fh, fieldnames=pcols, lineterminator="\n")
        w.writeheader()
        w.writerows(prows)
    faults["tamper_radius"] = run_reader(d4, "fault: radius string replaced")

    # 5. a tampered sample ID -> inconsistent
    d5 = copy_tree(rev / "tamper_id")
    with gzip.open(d5 / "out" / method / pname, "rt", encoding="utf-8") as fh:
        reader = _csv.DictReader(fh)
        pcols = reader.fieldnames
        prows = list(reader)
    idcol = "ids_pos" if "ids_pos" in pcols else "kept_ids"
    for row in prows:
        if row[idcol]:
            ids = row[idcol].split("|")
            ids[0] = str(int(ids[0]) + 1)      # flip the first ID
            row[idcol] = "|".join(ids)
            break
    with gzip.open(d5 / "out" / method / pname, "wt", encoding="utf-8",
                   newline="\n") as fh:
        w = _csv.DictWriter(fh, fieldnames=pcols, lineterminator="\n")
        w.writeheader()
        w.writerows(prows)
    faults["tamper_id"] = run_reader(d5, "fault: sample ID flipped")

    return faults


def main(argv=None) -> int:
    """CLI entry (wired from splitbench_cli.py)."""
    import argparse
    from .settings import DEFAULT_CONFIG, load_config, ROOT

    ap = argparse.ArgumentParser(prog="splitbench roundtrip")
    ap.add_argument("--config", default=None)
    ap.add_argument("--cities", default=None,
                    help="comma list dataset/city; default all six-city")
    ap.add_argument("--no-faults", action="store_true")
    ap.add_argument("--run", required=True)
    args = ap.parse_args(argv)
    path = Path(args.config) if args.config else DEFAULT_CONFIG
    if not path.is_absolute():
        path = ROOT / path
    cfg = load_config(path)
    run_dir = ROOT / "runs" / args.run
    if not run_dir.is_dir():
        print("run directory not found: %s" % run_dir)
        return 2
    cities = args.cities.split(",") if args.cities else None
    summary = run_roundtrip(cfg, run_dir, cities=cities,
                            fault_injection=not args.no_faults)
    print("roundtrip: %d files, %d status rows, %d payload rows, "
          "missing=%d inconsistent=%d duplicate=%d"
          % (summary["n_files_read"], summary["n_status_rows"],
             summary["n_payload_rows"], summary["n_missing"],
             summary["n_inconsistent"], summary["n_duplicate_keys"]))
    for name, f in summary["faults"].items():
        print("  fault %-22s detected=%s (missing=%d inconsistent=%d dup=%d)"
              % (name, f.get("detected"), f.get("n_missing", 0),
                 f.get("n_inconsistent", 0), f.get("n_duplicate_keys", 0)))
    ok = summary["all_roundtrip_ok"] and \
        summary["all_faults_detected"] is not False
    print("  %s" % ("all round-trip checks passed" if ok
                    else "ROUNDTRIP FAILED -- see roundtrip_summary.json"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
